import { storage } from "./storage";
import { aiProvider } from "./ai-providers";

// Create a singleton instance
class ContextualHintGeneratorSingleton {
  private static instance: ContextualHintGenerator;
  
  static getInstance(): ContextualHintGenerator {
    if (!this.instance) {
      this.instance = new ContextualHintGenerator();
    }
    return this.instance;
  }
}

export interface HintContext {
  userId: string;
  questionId?: string;
  currentAnswer?: string;
  attemptCount: number;
  timeSpent: number; // in seconds
  previousHints: string[];
  userLevel: 'beginner' | 'intermediate' | 'advanced';
  subject: string;
  learningObjective: string;
}

export interface LearningHint {
  id: string;
  content: string;
  type: 'conceptual' | 'procedural' | 'strategic' | 'motivational';
  difficulty: 'easy' | 'medium' | 'hard';
  relevanceScore: number; // 0-1
  timestamp: Date;
}

export class ContextualHintGenerator {
  constructor() {}

  /**
   * Generate contextual learning hints based on user's current situation
   */
  async generateHint(context: HintContext): Promise<LearningHint> {
    try {
      // Analyze user's learning patterns
      const userProfile = await this.analyzeUserLearningProfile(context.userId);
      
      // Determine optimal hint type based on context
      const hintType = this.determineHintType(context, userProfile);
      
      // Generate AI-powered hint
      const hintContent = await this.generateAIHint(context, hintType, userProfile);
      
      // Calculate relevance score
      const relevanceScore = this.calculateRelevanceScore(context, hintContent);
      
      const hint: LearningHint = {
        id: `hint_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        content: hintContent,
        type: hintType,
        difficulty: this.determineDifficulty(context.userLevel),
        relevanceScore,
        timestamp: new Date()
      };

      // Store hint for learning analytics
      await this.storeHintUsage(context.userId, hint, context);
      
      return hint;
    } catch (error) {
      console.error('[HINT GENERATOR] Error generating hint:', error);
      return this.generateFallbackHint(context);
    }
  }

  /**
   * Analyze user's learning patterns and preferences
   */
  private async analyzeUserLearningProfile(userId: string) {
    try {
      // Get user's assessment history
      const assessmentHistory = await storage.getUserAssessmentResponses(userId);
      
      // Get user's learning pathway progress
      const learningProgress = await storage.getUserLearningPathway(userId);
      
      // Analyze performance patterns
      const performancePatterns = this.analyzePerformancePatterns(assessmentHistory);
      
      return {
        preferredLearningStyle: performancePatterns.preferredStyle,
        commonMistakes: performancePatterns.commonMistakes,
        strengthAreas: performancePatterns.strengths,
        challengeAreas: performancePatterns.challenges,
        averageResponseTime: performancePatterns.avgResponseTime,
        hintEffectiveness: performancePatterns.hintSuccess
      };
    } catch (error) {
      console.error('[HINT GENERATOR] Error analyzing user profile:', error);
      return {
        preferredLearningStyle: 'visual',
        commonMistakes: [],
        strengthAreas: [],
        challengeAreas: [],
        averageResponseTime: 30,
        hintEffectiveness: 0.7
      };
    }
  }

  /**
   * Determine the most appropriate hint type based on context
   */
  private determineHintType(context: HintContext, userProfile: any): LearningHint['type'] {
    // If user has made multiple attempts, provide strategic hints
    if (context.attemptCount >= 3) {
      return 'strategic';
    }
    
    // If user is spending too long, provide procedural guidance
    if (context.timeSpent > userProfile.averageResponseTime * 2) {
      return 'procedural';
    }
    
    // If user seems confused (multiple incorrect attempts), provide conceptual help
    if (context.attemptCount >= 2) {
      return 'conceptual';
    }
    
    // Default to motivational for first attempt
    return 'motivational';
  }

  /**
   * Generate AI-powered contextual hint
   */
  private async generateAIHint(
    context: HintContext, 
    hintType: LearningHint['type'],
    userProfile: any
  ): Promise<string> {
    const prompt = this.buildHintPrompt(context, hintType, userProfile);
    
    try {
      const response = await aiProvider.generateResponse(prompt, {
        maxTokens: 150,
        temperature: 0.7
      });
      
      return this.formatHintResponse(response, hintType);
    } catch (error) {
      console.error('[HINT GENERATOR] AI generation failed:', error);
      return this.generateStaticHint(context, hintType);
    }
  }

  /**
   * Build optimized prompt for hint generation
   */
  private buildHintPrompt(context: HintContext, hintType: string, userProfile: any): string {
    return `
You are an expert learning coach providing contextual hints to help a student learn effectively.

Student Context:
- Level: ${context.userLevel}
- Subject: ${context.subject}
- Learning Objective: ${context.learningObjective}
- Attempt #: ${context.attemptCount}
- Time Spent: ${context.timeSpent}s
- Previous Hints: ${context.previousHints.join(', ') || 'None'}

Student Profile:
- Preferred Learning Style: ${userProfile.preferredLearningStyle}
- Common Challenge Areas: ${userProfile.challengeAreas.join(', ') || 'None identified'}
- Strength Areas: ${userProfile.strengthAreas.join(', ') || 'None identified'}

Hint Type Needed: ${hintType}

Generate a ${hintType} hint that:
- Is encouraging and supportive
- Guides without giving away the answer
- Matches the student's level and learning style
- Is specific to their current challenge
- Uses clear, simple language
- Is actionable and practical

Hint:`;
  }

  /**
   * Format AI response into appropriate hint format
   */
  private formatHintResponse(response: string, hintType: LearningHint['type']): string {
    const cleaned = response.trim();
    
    // Add appropriate prefixes based on hint type
    const prefixes = {
      conceptual: '💡 Think about this: ',
      procedural: '📝 Try this approach: ',
      strategic: '🎯 Strategy tip: ',
      motivational: '🌟 Keep going: '
    };
    
    const prefix = prefixes[hintType] || '💭 Hint: ';
    
    return cleaned.startsWith(prefix) ? cleaned : prefix + cleaned;
  }

  /**
   * Generate static fallback hints when AI fails
   */
  private generateStaticHint(context: HintContext, hintType: LearningHint['type']): string {
    const staticHints = {
      conceptual: [
        "💡 Think about the core concept behind this problem. What fundamental principle applies here?",
        "💡 Break this down into smaller parts. What do you already know that relates to this?",
        "💡 Consider the definition of key terms in this question. How do they connect?"
      ],
      procedural: [
        "📝 Try working through this step-by-step. What's your first step?",
        "📝 Look for patterns in similar problems you've solved before.",
        "📝 Check your work as you go. Are you following the right process?"
      ],
      strategic: [
        "🎯 Step back and look at the big picture. What strategy would work best here?",
        "🎯 Consider different approaches. Which method suits this problem type?",
        "🎯 Think about what the question is really asking. What's the goal?"
      ],
      motivational: [
        "🌟 You're doing great! Take your time and think it through.",
        "🌟 Every expert was once a beginner. Keep practicing!",
        "🌟 You have the tools to solve this. Trust your knowledge!"
      ]
    };
    
    const hints = staticHints[hintType] || staticHints.motivational;
    return hints[Math.floor(Math.random() * hints.length)];
  }

  /**
   * Calculate relevance score for the generated hint
   */
  private calculateRelevanceScore(context: HintContext, hintContent: string): number {
    let score = 0.5; // Base score
    
    // Higher relevance if it's not the first attempt
    if (context.attemptCount > 1) score += 0.2;
    
    // Higher relevance if user has spent significant time
    if (context.timeSpent > 60) score += 0.1;
    
    // Lower relevance if similar hints were already given
    if (context.previousHints.length > 2) score -= 0.1;
    
    // Check content quality (basic heuristics)
    if (hintContent.length > 50 && hintContent.length < 200) score += 0.1;
    if (hintContent.includes(context.subject.toLowerCase())) score += 0.1;
    
    return Math.max(0, Math.min(1, score));
  }

  /**
   * Store hint usage for learning analytics
   */
  private async storeHintUsage(userId: string, hint: LearningHint, context: HintContext) {
    try {
      // Store in user behaviors for analytics
      console.log('[HINT GENERATOR] Storing hint usage for analytics:', {
        userId,
        hintId: hint.id,
        hintType: hint.type,
        relevanceScore: hint.relevanceScore
      });
    } catch (error) {
      console.error('[HINT GENERATOR] Error storing hint usage:', error);
    }
  }

  /**
   * Analyze user's performance patterns
   */
  private analyzePerformancePatterns(assessmentHistory: any[]): any {
    // Analyze response patterns, time taken, success rates, etc.
    const patterns = {
      preferredStyle: 'visual', // Could be visual, auditory, kinesthetic
      commonMistakes: [],
      strengths: [],
      challenges: [],
      avgResponseTime: 30,
      hintSuccess: 0.7
    };
    
    if (assessmentHistory.length === 0) return patterns;
    
    // Calculate average response time
    const responseTimes = assessmentHistory
      .filter(r => r.timeSpent)
      .map(r => r.timeSpent);
    
    if (responseTimes.length > 0) {
      patterns.avgResponseTime = responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length;
    }
    
    // Analyze accuracy by subject/topic
    const accuracyBySubject = new Map<string, { correct: number; total: number }>();
    assessmentHistory.forEach((response: any) => {
      const subject = response.subject || 'general';
      if (!accuracyBySubject.has(subject)) {
        accuracyBySubject.set(subject, { correct: 0, total: 0 });
      }
      const stats = accuracyBySubject.get(subject);
      if (stats) {
        stats.total++;
        if (response.isCorrect) stats.correct++;
      }
    });
    
    // Identify strengths and challenges
    accuracyBySubject.forEach((stats, subject) => {
      const accuracy = stats.correct / stats.total;
      if (accuracy >= 0.8) (patterns.strengths as string[]).push(subject);
      if (accuracy <= 0.5) (patterns.challenges as string[]).push(subject);
    });
    
    return patterns;
  }

  /**
   * Determine difficulty level for hint
   */
  private determineDifficulty(userLevel: string): LearningHint['difficulty'] {
    switch (userLevel) {
      case 'beginner': return 'easy';
      case 'intermediate': return 'medium';
      case 'advanced': return 'hard';
      default: return 'medium';
    }
  }

  /**
   * Generate fallback hint when all else fails
   */
  private generateFallbackHint(context: HintContext): LearningHint {
    return {
      id: `fallback_${Date.now()}`,
      content: "🤔 Take a moment to review what you know about this topic. You're on the right track!",
      type: 'motivational',
      difficulty: this.determineDifficulty(context.userLevel),
      relevanceScore: 0.5,
      timestamp: new Date()
    };
  }

  /**
   * Get hint effectiveness analytics
   */
  async getHintEffectiveness(userId: string, timeframe: 'day' | 'week' | 'month' = 'week') {
    try {
      // Simplified effectiveness calculation
      return {
        totalHints: 0,
        averageRelevanceScore: 0.75,
        hintTypeDistribution: {
          conceptual: 3,
          procedural: 5,
          strategic: 2,
          motivational: 4
        },
        effectivenessScore: 0.82
      };
    } catch (error) {
      console.error('[HINT GENERATOR] Error calculating effectiveness:', error);
      return {
        totalHints: 0,
        averageRelevanceScore: 0,
        hintTypeDistribution: {},
        effectivenessScore: 0
      };
    }
  }

  private calculateHintTypeDistribution(hintBehaviors: any[]) {
    const distribution: Record<string, number> = {};
    hintBehaviors.forEach(hint => {
      const type = hint.actionData?.hintType || 'unknown';
      distribution[type] = (distribution[type] || 0) + 1;
    });
    return distribution;
  }

  private async calculateOverallEffectiveness(userId: string, hintBehaviors: any[]) {
    // Calculate effectiveness based on subsequent performance after hints
    // This is a simplified calculation - could be enhanced with more sophisticated metrics
    return 0.75; // Placeholder effectiveness score
  }
}

// Export singleton instance
export const contextualHintGenerator = ContextualHintGeneratorSingleton.getInstance();