// Multi-Provider OAuth Authentication System
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { storage } from './storage';

// OAuth Configuration
const OAUTH_CONFIGS = {
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID || '623987475110-h3ou9h5scth36emh7v1s9bl3oj14hsh5.apps.googleusercontent.com',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || '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',
    redirectUri: process.env.GOOGLE_REDIRECT_URI || 'http://localhost:5000/api/auth/google/callback',
    authUrl: 'https://accounts.google.com/oauth2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    userInfoUrl: 'https://www.googleapis.com/oauth2/v2/userinfo',
    scopes: ['openid', 'email', 'profile']
  },
  apple: {
    clientId: process.env.APPLE_CLIENT_ID || 'com.eiq.academy.signin',
    teamId: process.env.APPLE_TEAM_ID || 'TEMP_TEAM',
    keyId: process.env.APPLE_KEY_ID || 'TEMP_KEY',
    privateKey: process.env.APPLE_PRIVATE_KEY || 'TEMP_PRIVATE_KEY',
    redirectUri: process.env.APPLE_REDIRECT_URI || 'http://localhost:5000/api/auth/apple/callback',
    authUrl: 'https://appleid.apple.com/auth/authorize',
    tokenUrl: 'https://appleid.apple.com/auth/token',
    scopes: ['name', 'email']
  }
};

// Generate OAuth authorization URL
export const generateOAuthUrl = (provider: 'google' | 'apple', state?: string): string => {
  const config = OAUTH_CONFIGS[provider];
  if (!config) throw new Error(`OAuth provider ${provider} not supported`);
  
  const params = new URLSearchParams({
    client_id: config.clientId!,
    redirect_uri: config.redirectUri,
    response_type: 'code',
    scope: config.scopes.join(' '),
    state: state || generateRandomState(),
    ...(provider === 'apple' && { response_mode: 'form_post' })
  });
  
  return `${config.authUrl}?${params.toString()}`;
};

// Exchange OAuth code for tokens
export const exchangeOAuthCode = async (
  provider: 'google' | 'apple',
  code: string,
  state?: string
): Promise<any> => {
  const config = OAUTH_CONFIGS[provider];
  if (!config) throw new Error(`OAuth provider ${provider} not supported`);
  
  try {
    const tokenResponse = await fetch(config.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        client_id: config.clientId!,
        client_secret: provider === 'google' ? (config as any).clientSecret! : '',
        code,
        redirect_uri: config.redirectUri
      })
    });
    
    if (!tokenResponse.ok) {
      throw new Error(`Token exchange failed: ${tokenResponse.statusText}`);
    }
    
    return await tokenResponse.json();
  } catch (error) {
    console.error(`OAuth token exchange error for ${provider}:`, error);
    throw error;
  }
};

// Get user info from OAuth provider
export const getOAuthUserInfo = async (
  provider: 'google' | 'apple',
  accessToken: string
): Promise<any> => {
  const config = OAUTH_CONFIGS[provider];
  if (!config || !(config as any).userInfoUrl) {
    throw new Error(`User info not available for ${provider}`);
  }
  
  try {
    const userResponse = await fetch((config as any).userInfoUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json'
      }
    });
    
    if (!userResponse.ok) {
      throw new Error(`User info fetch failed: ${userResponse.statusText}`);
    }
    
    return await userResponse.json();
  } catch (error) {
    console.error(`OAuth user info error for ${provider}:`, error);
    throw error;
  }
};

// Link OAuth account to existing user or create new user
export const linkOAuthAccount = async (
  provider: 'google' | 'apple',
  oauthUser: any,
  tokens: any,
  existingUserId?: string
): Promise<{ user: any; token: string; isNewUser: boolean }> => {
  try {
    let user;
    let isNewUser = false;
    
    // Check if OAuth account already exists
    const existingOAuthAccount = await storage.getOAuthProvider(oauthUser.id, provider);
    
    if (existingOAuthAccount) {
      // OAuth account exists, get the user
      user = await storage.getUser(existingOAuthAccount.userId);
      if (!user) throw new Error('User not found for OAuth account');
      
      // Update OAuth tokens
      await storage.updateOAuthProvider(existingOAuthAccount.userId, provider, {
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
        tokenExpiry: tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000) : undefined
      });
    } else if (existingUserId) {
      // Link to existing user account
      user = await storage.getUser(existingUserId);
      if (!user) throw new Error('Existing user not found');
      
      // Create OAuth provider link
      await storage.createOAuthProvider({
        userId: existingUserId,
        provider,
        providerId: oauthUser.id,
        email: oauthUser.email,
        name: oauthUser.name || `${oauthUser.given_name || ''} ${oauthUser.family_name || ''}`.trim(),
        profileImageUrl: oauthUser.picture,
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
        tokenExpiry: tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000) : undefined
      });
      
      // Update user's linked providers
      const linkedProviders = user.linkedProviders || [];
      if (!linkedProviders.includes(provider)) {
        await storage.updateUser(existingUserId, {
          linkedProviders: [...linkedProviders, provider],
          lastLoginAt: new Date()
        });
      }
    } else {
      // Check if user with this email exists
      const existingUser = await storage.getUserByEmail(oauthUser.email);
      
      if (existingUser) {
        // Link OAuth to existing email-based account
        user = existingUser;
        
        await storage.createOAuthProvider({
          userId: existingUser.id,
          provider,
          providerId: oauthUser.id,
          email: oauthUser.email,
          name: oauthUser.name || `${oauthUser.given_name || ''} ${oauthUser.family_name || ''}`.trim(),
          profileImageUrl: oauthUser.picture,
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          tokenExpiry: tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000) : undefined
        });
        
        // Update user's auth provider and linked providers
        const linkedProviders = user.linkedProviders || [];
        await storage.updateUser(existingUser.id, {
          authProvider: provider,
          providerId: oauthUser.id,
          linkedProviders: [...linkedProviders, provider].filter((p, i, arr) => arr.indexOf(p) === i),
          emailVerified: true,
          profileImageUrl: oauthUser.picture || user.profileImageUrl,
          lastLoginAt: new Date()
        });
      } else {
        // Create new user account
        const newUser = await storage.createUser({
          email: oauthUser.email,
          firstName: oauthUser.given_name || oauthUser.name?.split(' ')[0] || 'User',
          lastName: oauthUser.family_name || oauthUser.name?.split(' ').slice(1).join(' ') || '',
          profileImageUrl: oauthUser.picture,
          authProvider: provider,
          providerId: oauthUser.id,
          linkedProviders: [provider],
          emailVerified: true,
          lastLoginAt: new Date()
        });
        
        user = newUser;
        isNewUser = true;
        
        // Create OAuth provider record
        await storage.createOAuthProvider({
          userId: user.id,
          provider,
          providerId: oauthUser.id,
          email: oauthUser.email,
          name: oauthUser.name || `${oauthUser.given_name || ''} ${oauthUser.family_name || ''}`.trim(),
          profileImageUrl: oauthUser.picture,
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          tokenExpiry: tokens.expires_in ? new Date(Date.now() + tokens.expires_in * 1000) : undefined
        });
      }
    }
    
    // Generate JWT token
    const jwtToken = jwt.sign(
      { 
        userId: user.id, 
        email: user.email,
        provider: provider 
      },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    );
    
    return { user, token: jwtToken, isNewUser };
  } catch (error) {
    console.error('OAuth account linking error:', error);
    throw error;
  }
};

// Generate random state for CSRF protection
const generateRandomState = (): string => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

// OAuth route handlers
export const handleGoogleAuth = async (req: Request, res: Response) => {
  try {
    const authUrl = generateOAuthUrl('google');
    res.redirect(authUrl);
  } catch (error) {
    console.error('Google auth initiation error:', error);
    res.status(500).json({ error: 'Failed to initiate Google authentication' });
  }
};

export const handleGoogleCallback = async (req: Request, res: Response) => {
  try {
    const { code, state } = req.query;
    
    if (!code) {
      return res.status(400).json({ error: 'Authorization code not provided' });
    }
    
    // Exchange code for tokens
    const tokens = await exchangeOAuthCode('google', code as string);
    
    // Get user info
    const googleUser = await getOAuthUserInfo('google', tokens.access_token);
    
    // Link account or create user
    const result = await linkOAuthAccount('google', googleUser, tokens);
    
    // Redirect to frontend with token
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5000'}?token=${result.token}&new_user=${result.isNewUser}`);
  } catch (error) {
    console.error('Google callback error:', error);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5000'}?error=google_auth_failed`);
  }
};

export const handleAppleAuth = async (req: Request, res: Response) => {
  try {
    const authUrl = generateOAuthUrl('apple');
    res.redirect(authUrl);
  } catch (error) {
    console.error('Apple auth initiation error:', error);
    res.status(500).json({ error: 'Failed to initiate Apple authentication' });
  }
};

export const handleAppleCallback = async (req: Request, res: Response) => {
  try {
    const { code, state, user } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: 'Authorization code not provided' });
    }
    
    // Exchange code for tokens
    const tokens = await exchangeOAuthCode('apple', code);
    
    // Apple provides user data only on first authentication
    let appleUser = user ? JSON.parse(user) : null;
    
    if (!appleUser) {
      // For subsequent logins, we need to decode the ID token
      // This is a simplified version - in production, you'd properly verify the JWT
      const idTokenPayload = tokens.id_token ? JSON.parse(
        Buffer.from(tokens.id_token.split('.')[1], 'base64').toString()
      ) : {};
      
      appleUser = {
        id: idTokenPayload.sub,
        email: idTokenPayload.email,
        name: idTokenPayload.name
      };
    }
    
    // Link account or create user
    const result = await linkOAuthAccount('apple', appleUser, tokens);
    
    // Redirect to frontend with token
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5000'}?token=${result.token}&new_user=${result.isNewUser}`);
  } catch (error) {
    console.error('Apple callback error:', error);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:5000'}?error=apple_auth_failed`);
  }
};