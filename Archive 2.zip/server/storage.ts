import { 
  users, 
  oauthProviders,
  assessments,
  learningPaths,
  documents,
  aiConversations,
  studyGroups,
  studyGroupMembers,
  courseFeed,
  aiTutoringSessions,
  vrCompetitions,
  vrCompetitionParticipants,
  universityPartners,
  universityApplications,
  corporatePartners,
  talentProfile,
  recruitmentMatches,
  userOnboarding,
  skillRecommendations,
  industryTracks,
  curriculumModules,
  questionBank,
  assessmentResponses,
  learningPathways,
  videoLessons,
  videoProgress,
  practiceExercises,
  exerciseAttempts,
  aiMentorSessions,
  userBehaviorTracking,
  institutions,
  staffStudentAssignments,
  staffObservations,
  studentProgressAnalytics,
  customQuestions,
  customQuestionResponses,
  aiQuestionSessions,
  questionAssignments,
  aiLearningData,
  type User, 
  type InsertUser,
  type UpsertUser,
  type UserOnboarding,
  type InsertUserOnboarding,
  type SkillRecommendation,
  type InsertSkillRecommendation,
  type AiMentorSession,
  type InsertAiMentorSession,
  type Institution,
  type InsertInstitution,
  type StaffStudentAssignment,
  type InsertStaffStudentAssignment,
  type StaffObservation,
  type InsertStaffObservation,
  type StudentProgressAnalytics,
  type InsertStudentProgressAnalytics,

  type Assessment,
  type InsertAssessment,
  type LearningPath,
  type InsertLearningPath,
  type Document,
  type InsertDocument,
  type AiConversation,
  type InsertAiConversation,
  type StudyGroup,
  type InsertStudyGroup,
  type StudyGroupMember,
  type InsertStudyGroupMember,
  type CourseFeed,
  type InsertCourseFeed,
  type AiTutoringSession,
  type InsertAiTutoringSession,
  type VrCompetition,
  type InsertVrCompetition,
  type VrCompetitionParticipant,
  type InsertVrCompetitionParticipant,
  type UniversityPartner,
  type UniversityApplication,
  type InsertUniversityApplication,
  type CorporatePartner,
  type TalentProfile,
  type InsertTalentProfile,
  type RecruitmentMatch,
  type InsertRecruitmentMatch,
  type CustomQuestion,
  type InsertCustomQuestion,
  type CustomQuestionResponse,
  type InsertCustomQuestionResponse,
  type AiQuestionSession,
  type InsertAiQuestionSession,
  type QuestionAssignment,
  type InsertQuestionAssignment,
  type AiLearningData,
  type InsertAiLearningData,
  type QuestionBank,
  knowledgeNodes,
  knowledgeConnections,
  knowledgeVisualizations,
  type KnowledgeNode,
  type InsertKnowledgeNode,
  type KnowledgeConnection,
  type InsertKnowledgeConnection,
  type KnowledgeVisualization,
  type InsertKnowledgeVisualization,
  type ChatSession,
  type ChatMessage,
  type InsertChatSession,
  type InsertChatMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Multi-role functionality
  getUsersByRole(role: string): Promise<User[]>;
  updateUserRole(userId: string, role: string, institutionId?: string): Promise<User>;
  createStaffStudentAssignment(assignment: InsertStaffStudentAssignment): Promise<StaffStudentAssignment>;
  getStaffAssignedStudents(staffId: string): Promise<User[]>;
  createStaffObservation(observation: InsertStaffObservation): Promise<StaffObservation>;
  getStaffObservations(staffId: string): Promise<StaffObservation[]>;
  createStudentProgressAnalytics(analytics: InsertStudentProgressAnalytics): Promise<StudentProgressAnalytics>;
  getStudentProgressAnalytics(studentId: string): Promise<StudentProgressAnalytics[]>;
  
  // Institution management
  createInstitution(institution: InsertInstitution): Promise<Institution>;
  getInstitutions(): Promise<Institution[]>;
  getInstitution(id: string): Promise<Institution | undefined>;
  updateInstitution(id: string, updates: Partial<Institution>): Promise<Institution>;
  
  // Extended user management for multi-role functionality
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  
  // Custom Questions System
  createCustomQuestion(question: InsertCustomQuestion): Promise<CustomQuestion>;
  getCustomQuestion(id: string): Promise<CustomQuestion | undefined>;
  getCustomQuestionsByStaff(staffId: string): Promise<CustomQuestion[]>;
  getCustomQuestionsForStudent(studentId: string): Promise<CustomQuestion[]>;
  updateCustomQuestion(id: string, updates: Partial<CustomQuestion>): Promise<CustomQuestion>;
  deleteCustomQuestion(id: string): Promise<void>;
  
  // Custom Question Responses
  createCustomQuestionResponse(response: InsertCustomQuestionResponse): Promise<CustomQuestionResponse>;
  getCustomQuestionResponses(questionId: string): Promise<CustomQuestionResponse[]>;
  getStudentCustomQuestionResponses(studentId: string): Promise<CustomQuestionResponse[]>;
  updateCustomQuestionResponse(id: string, updates: Partial<CustomQuestionResponse>): Promise<CustomQuestionResponse>;
  
  // AI Question Sessions
  createAiQuestionSession(session: InsertAiQuestionSession): Promise<AiQuestionSession>;
  getAiQuestionSession(id: string): Promise<AiQuestionSession | undefined>;
  getAiQuestionSessions(staffId: string): Promise<AiQuestionSession[]>;
  updateAiQuestionSession(id: string, updates: Partial<AiQuestionSession>): Promise<AiQuestionSession>;
  
  // Question Assignments
  createQuestionAssignment(assignment: InsertQuestionAssignment): Promise<QuestionAssignment>;
  getQuestionAssignment(id: string): Promise<QuestionAssignment | undefined>;
  getStudentQuestionAssignments(studentId: string): Promise<QuestionAssignment[]>;
  getStaffQuestionAssignments(staffId: string): Promise<QuestionAssignment[]>;
  updateQuestionAssignment(id: string, updates: Partial<QuestionAssignment>): Promise<QuestionAssignment>;

  // Question Bank methods for adaptive assessment  
  getAllQuestions(): Promise<QuestionBank[]>;
  getQuestionsByDomain(domain: string): Promise<QuestionBank[]>;
  getQuestionsByDifficulty(minDifficulty: number, maxDifficulty: number): Promise<QuestionBank[]>;

  // Knowledge Visualization functions
  createKnowledgeNode(node: InsertKnowledgeNode): Promise<KnowledgeNode>;
  getKnowledgeNodesByUser(userId: string): Promise<KnowledgeNode[]>;
  createKnowledgeConnection(connection: InsertKnowledgeConnection): Promise<KnowledgeConnection>;
  getKnowledgeConnectionsByUser(userId: string): Promise<KnowledgeConnection[]>;
  createKnowledgeVisualization(viz: InsertKnowledgeVisualization): Promise<KnowledgeVisualization>;
  getKnowledgeVisualizationsByUser(userId: string): Promise<KnowledgeVisualization[]>;
  getAssessmentsByUser(userId: string): Promise<Assessment[]>;
  getSkillRecommendationsByUser(userId: string): Promise<SkillRecommendation[]>;

  // Industry Titan Tracks
  upsertIndustryTrack(track: any): Promise<any>;
  getIndustryTrack(trackId: string): Promise<any | undefined>;
  getAllIndustryTracks(): Promise<any[]>;
  
  // Learning Pathways
  createLearningPathway(pathway: any): Promise<any>;
  upsertLearningPathway(pathway: any): Promise<any>;
  getUserLearningPathway(userId: string): Promise<any | undefined>;
  
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  upsertUser(userData: UpsertUser): Promise<User>;
  
  // OAuth provider management
  getOAuthProvider(userId: string, provider: string): Promise<any>;
  createOAuthProvider(data: any): Promise<any>;
  updateOAuthProvider(userId: string, provider: string, data: any): Promise<any>;

  // Assessment system
  createAssessment(insertAssessment: InsertAssessment): Promise<Assessment>;
  getAssessment(id: string): Promise<Assessment | undefined>;
  getUserAssessments(userId: string): Promise<Assessment[]>;
  updateAssessment(id: string, updates: Partial<Assessment>): Promise<Assessment>;

  // Learning paths
  createLearningPath(insertLearningPath: InsertLearningPath): Promise<LearningPath>;
  getUserLearningPaths(userId: string): Promise<LearningPath[]>;
  updateLearningPath(id: string, updates: Partial<LearningPath>): Promise<LearningPath>;

  // Document handling
  createDocument(insertDocument: InsertDocument): Promise<Document>;
  getUserDocuments(userId: string): Promise<Document[]>;
  updateDocument(id: string, updates: Partial<Document>): Promise<Document>;

  // AI conversations
  createAiConversation(insertAiConversation: InsertAiConversation): Promise<AiConversation>;
  getUserAiConversations(userId: string): Promise<AiConversation[]>;
  updateAiConversation(id: string, updates: Partial<AiConversation>): Promise<AiConversation>;

  // Study groups
  createStudyGroup(insertStudyGroup: InsertStudyGroup): Promise<StudyGroup>;
  getAllStudyGroups(): Promise<StudyGroup[]>;
  joinStudyGroup(groupId: string, userId: string): Promise<StudyGroupMember>;
  getUserStudyGroups(userId: string): Promise<StudyGroup[]>;

  // Course feed
  getAllCourseFeed(): Promise<CourseFeed[]>;
  createCourseFeedItem(insertCourseFeed: InsertCourseFeed): Promise<CourseFeed>;

  // Advanced AI Tutoring
  createAiTutoringSession(insertSession: InsertAiTutoringSession): Promise<AiTutoringSession>;
  getUserAiTutoringSessions(userId: string): Promise<AiTutoringSession[]>;
  updateAiTutoringSession(id: string, updates: Partial<AiTutoringSession>): Promise<AiTutoringSession>;
  getActiveAiTutoringSession(userId: string): Promise<AiTutoringSession | undefined>;

  // VR Competition System
  createVrCompetition(insertCompetition: InsertVrCompetition): Promise<VrCompetition>;
  getAllVrCompetitions(): Promise<VrCompetition[]>;
  getActiveVrCompetitions(): Promise<VrCompetition[]>;
  joinVrCompetition(competitionId: string, userId: string, entryEiQScore: string): Promise<VrCompetitionParticipant>;
  getUserVrCompetitions(userId: string): Promise<VrCompetitionParticipant[]>;
  updateVrCompetitionParticipant(id: string, updates: Partial<VrCompetitionParticipant>): Promise<VrCompetitionParticipant>;

  // University Partnership System
  getAllUniversityPartners(): Promise<UniversityPartner[]>;
  getEligibleUniversities(eiqScore: number): Promise<UniversityPartner[]>;
  createUniversityApplication(insertApplication: InsertUniversityApplication): Promise<UniversityApplication>;
  getUserUniversityApplications(userId: string): Promise<UniversityApplication[]>;
  updateUniversityApplication(id: string, updates: Partial<UniversityApplication>): Promise<UniversityApplication>;

  // Corporate Partnership & Talent Recruitment
  getAllCorporatePartners(): Promise<CorporatePartner[]>;
  createTalentProfile(insertProfile: InsertTalentProfile): Promise<TalentProfile>;
  getUserTalentProfile(userId: string): Promise<TalentProfile | undefined>;
  updateTalentProfile(id: string, updates: Partial<TalentProfile>): Promise<TalentProfile>;
  getRecruitmentMatches(talentProfileId: string): Promise<RecruitmentMatch[]>;
  createRecruitmentMatch(insertMatch: InsertRecruitmentMatch): Promise<RecruitmentMatch>;

  // User Onboarding
  createUserOnboarding(data: InsertUserOnboarding): Promise<UserOnboarding>;
  getUserOnboarding(userId: string): Promise<UserOnboarding | undefined>;
  updateUserOnboarding(id: string, updates: Partial<UserOnboarding>): Promise<UserOnboarding>;

  // Skill Recommendations
  createSkillRecommendation(recommendation: InsertSkillRecommendation): Promise<SkillRecommendation>;
  getUserSkillRecommendations(userId: string): Promise<SkillRecommendation[]>;
  updateSkillRecommendationProgress(id: string, progress: number): Promise<SkillRecommendation>;
  completeSkillRecommendation(id: string): Promise<SkillRecommendation>;
  getActiveSkillRecommendations(userId: string): Promise<SkillRecommendation[]>;

  // AI Mentor Sessions
  createAiMentorSession(data: InsertAiMentorSession): Promise<AiMentorSession>;
  getUserAiMentorSessions(userId: string): Promise<AiMentorSession[]>;
  updateAiMentorSession(id: string, updates: Partial<AiMentorSession>): Promise<AiMentorSession>;
  getActiveAiMentorSession(userId: string): Promise<AiMentorSession | undefined>;

  // K-12 Education System
  createIndustryTrack(data: any): Promise<any>;
  getAllIndustryTracks(): Promise<any[]>;
  getIndustryTrack(id: string): Promise<any>;
  createCurriculumModule(data: any): Promise<any>;
  getModulesByTrack(trackId: string): Promise<any[]>;
  createQuestion(data: any): Promise<any>;
  getQuestionsByModule(moduleId: string): Promise<any[]>;
  createAssessmentResponse(data: any): Promise<any>;
  getUserAssessmentResponses(userId: string): Promise<any[]>;
  createLearningPathway(data: any): Promise<any>;
  getUserLearningPathway(userId: string): Promise<any>;
  updateLearningPathway(id: string, updates: any): Promise<any>;

  // Seeder support methods
  createQuestionBankEntry(question: any): Promise<any>;
  createAILearningData(data: any): Promise<any>;
  getAILearningDataByUser(userId: string): Promise<any[]>;
  getAllAILearningData(): Promise<any[]>;
  createCustomQuestion(question: any): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // Multi-role functionality
  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  async updateUserRole(userId: string, role: string, institutionId?: string): Promise<User> {
    const updates: Partial<User> = { role };
    if (institutionId) {
      updates.institutionId = institutionId;
    }
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }

  async createStaffStudentAssignment(assignment: InsertStaffStudentAssignment): Promise<StaffStudentAssignment> {
    const [newAssignment] = await db
      .insert(staffStudentAssignments)
      .values(assignment)
      .returning();
    return newAssignment;
  }

  async getStaffAssignedStudents(staffId: string): Promise<User[]> {
    const assignments = await db
      .select()
      .from(staffStudentAssignments)
      .innerJoin(users, eq(staffStudentAssignments.studentId, users.id))
      .where(and(
        eq(staffStudentAssignments.staffId, staffId),
        eq(staffStudentAssignments.isActive, true)
      ));
    
    return assignments.map(assignment => assignment.users);
  }

  async createStaffObservation(observation: InsertStaffObservation): Promise<StaffObservation> {
    const [newObservation] = await db
      .insert(staffObservations)
      .values(observation)
      .returning();
    return newObservation;
  }

  async getStaffObservations(staffId: string): Promise<StaffObservation[]> {
    return await db
      .select()
      .from(staffObservations)
      .where(eq(staffObservations.staffId, staffId))
      .orderBy(desc(staffObservations.createdAt));
  }

  async createStudentProgressAnalytics(analytics: InsertStudentProgressAnalytics): Promise<StudentProgressAnalytics> {
    const [newAnalytics] = await db
      .insert(studentProgressAnalytics)
      .values(analytics)
      .returning();
    return newAnalytics;
  }

  async getStudentProgressAnalytics(studentId: string): Promise<StudentProgressAnalytics[]> {
    return await db
      .select()
      .from(studentProgressAnalytics)
      .where(eq(studentProgressAnalytics.studentId, studentId))
      .orderBy(desc(studentProgressAnalytics.analysisDate));
  }

  // Institution management
  async createInstitution(institution: InsertInstitution): Promise<Institution> {
    const [newInstitution] = await db
      .insert(institutions)
      .values(institution)
      .returning();
    return newInstitution;
  }

  async getInstitutions(): Promise<Institution[]> {
    return await db.select().from(institutions).orderBy(institutions.name);
  }

  async getInstitution(id: string): Promise<Institution | undefined> {
    const [institution] = await db
      .select()
      .from(institutions)
      .where(eq(institutions.id, id));
    return institution;
  }

  async updateInstitution(id: string, updates: Partial<Institution>): Promise<Institution> {
    const [updatedInstitution] = await db
      .update(institutions)
      .set(updates)
      .where(eq(institutions.id, id))
      .returning();
    return updatedInstitution;
  }

  // Extended user management for multi-role functionality
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // User management
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // OAuth provider management
  async getOAuthProvider(userId: string, provider: string): Promise<any> {
    const [oauthProvider] = await db
      .select()
      .from(oauthProviders)
      .where(and(eq(oauthProviders.userId, userId), eq(oauthProviders.provider, provider)));
    return oauthProvider || undefined;
  }

  async createOAuthProvider(data: any): Promise<any> {
    const [oauthProvider] = await db
      .insert(oauthProviders)
      .values(data)
      .returning();
    return oauthProvider;
  }

  async updateOAuthProvider(userId: string, provider: string, data: any): Promise<any> {
    const [oauthProvider] = await db
      .update(oauthProviders)
      .set({ ...data, updatedAt: new Date() })
      .where(and(eq(oauthProviders.userId, userId), eq(oauthProviders.provider, provider)))
      .returning();
    return oauthProvider;
  }

  // Assessment system
  async createAssessment(insertAssessment: InsertAssessment): Promise<Assessment> {
    const [assessment] = await db
      .insert(assessments)
      .values(insertAssessment)
      .returning();
    return assessment;
  }

  async getAssessment(id: string): Promise<Assessment | undefined> {
    const [assessment] = await db.select().from(assessments).where(eq(assessments.id, id));
    return assessment || undefined;
  }

  async getUserAssessments(userId: string): Promise<Assessment[]> {
    return await db.select().from(assessments).where(eq(assessments.userId, userId));
  }

  async updateAssessment(id: string, updates: Partial<Assessment>): Promise<Assessment> {
    const [assessment] = await db
      .update(assessments)
      .set(updates)
      .where(eq(assessments.id, id))
      .returning();
    return assessment;
  }

  // Learning paths
  async createLearningPath(insertLearningPath: InsertLearningPath): Promise<LearningPath> {
    const [learningPath] = await db
      .insert(learningPaths)
      .values(insertLearningPath)
      .returning();
    return learningPath;
  }

  async getUserLearningPaths(userId: string): Promise<LearningPath[]> {
    return await db.select().from(learningPaths).where(eq(learningPaths.userId, userId));
  }

  async updateLearningPath(id: string, updates: Partial<LearningPath>): Promise<LearningPath> {
    const [learningPath] = await db
      .update(learningPaths)
      .set(updates)
      .where(eq(learningPaths.id, id))
      .returning();
    return learningPath;
  }

  // Document handling
  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const [document] = await db
      .insert(documents)
      .values(insertDocument)
      .returning();
    return document;
  }

  async getUserDocuments(userId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.userId, userId));
  }

  async updateDocument(id: string, updates: Partial<Document>): Promise<Document> {
    const [document] = await db
      .update(documents)
      .set(updates)
      .where(eq(documents.id, id))
      .returning();
    return document;
  }

  // AI conversations
  async createAiConversation(insertAiConversation: InsertAiConversation): Promise<AiConversation> {
    const [conversation] = await db
      .insert(aiConversations)
      .values(insertAiConversation)
      .returning();
    return conversation;
  }

  async getUserAiConversations(userId: string): Promise<AiConversation[]> {
    return await db.select().from(aiConversations).where(eq(aiConversations.userId, userId));
  }

  async updateAiConversation(id: string, updates: Partial<AiConversation>): Promise<AiConversation> {
    const [conversation] = await db
      .update(aiConversations)
      .set(updates)
      .where(eq(aiConversations.id, id))
      .returning();
    return conversation;
  }

  // Study groups
  async createStudyGroup(insertStudyGroup: InsertStudyGroup): Promise<StudyGroup> {
    const [studyGroup] = await db
      .insert(studyGroups)
      .values(insertStudyGroup)
      .returning();
    return studyGroup;
  }

  async getAllStudyGroups(): Promise<StudyGroup[]> {
    return await db.select().from(studyGroups).where(eq(studyGroups.isActive, true));
  }

  async joinStudyGroup(groupId: string, userId: string): Promise<StudyGroupMember> {
    const [member] = await db
      .insert(studyGroupMembers)
      .values({ groupId, userId })
      .returning();
    return member;
  }

  async getUserStudyGroups(userId: string): Promise<StudyGroup[]> {
    const userGroups = await db
      .select({
        id: studyGroups.id,
        name: studyGroups.name,
        description: studyGroups.description,
        topic: studyGroups.topic,
        maxMembers: studyGroups.maxMembers,
        isActive: studyGroups.isActive,
        createdBy: studyGroups.createdBy,
        createdAt: studyGroups.createdAt
      })
      .from(studyGroups)
      .innerJoin(studyGroupMembers, eq(studyGroups.id, studyGroupMembers.groupId))
      .where(eq(studyGroupMembers.userId, userId));
    return userGroups;
  }

  async getStudyGroup(groupId: string): Promise<StudyGroup | undefined> {
    const [group] = await db.select().from(studyGroups).where(eq(studyGroups.id, groupId));
    return group;
  }

  // Course feed
  async getAllCourseFeed(): Promise<CourseFeed[]> {
    return await db.select().from(courseFeed)
      .where(eq(courseFeed.isActive, true))
      .orderBy(desc(courseFeed.priority), desc(courseFeed.publishedAt));
  }

  async createCourseFeedItem(insertCourseFeed: InsertCourseFeed): Promise<CourseFeed> {
    const [feedItem] = await db
      .insert(courseFeed)
      .values(insertCourseFeed)
      .returning();
    return feedItem;
  }

  // Advanced AI Tutoring
  async createAiTutoringSession(insertSession: InsertAiTutoringSession): Promise<AiTutoringSession> {
    const [session] = await db
      .insert(aiTutoringSessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async getUserAiTutoringSessions(userId: string): Promise<AiTutoringSession[]> {
    return await db.select().from(aiTutoringSessions)
      .where(eq(aiTutoringSessions.userId, userId))
      .orderBy(desc(aiTutoringSessions.createdAt));
  }

  async updateAiTutoringSession(id: string, updates: Partial<AiTutoringSession>): Promise<AiTutoringSession> {
    const [session] = await db
      .update(aiTutoringSessions)
      .set(updates)
      .where(eq(aiTutoringSessions.id, id))
      .returning();
    return session;
  }

  async getActiveAiTutoringSession(userId: string): Promise<AiTutoringSession | undefined> {
    const [session] = await db.select().from(aiTutoringSessions)
      .where(and(
        eq(aiTutoringSessions.userId, userId),
        eq(aiTutoringSessions.status, 'active')
      ))
      .orderBy(desc(aiTutoringSessions.updatedAt))
      .limit(1);
    return session || undefined;
  }

  // VR Competition System
  async createVrCompetition(insertCompetition: InsertVrCompetition): Promise<VrCompetition> {
    const [competition] = await db
      .insert(vrCompetitions)
      .values(insertCompetition)
      .returning();
    return competition;
  }

  async getAllVrCompetitions(): Promise<VrCompetition[]> {
    return await db.select().from(vrCompetitions)
      .orderBy(desc(vrCompetitions.startDate));
  }

  async getActiveVrCompetitions(): Promise<VrCompetition[]> {
    return await db.select().from(vrCompetitions)
      .where(eq(vrCompetitions.status, 'active'))
      .orderBy(desc(vrCompetitions.startDate));
  }

  async joinVrCompetition(competitionId: string, userId: string, entryEiQScore: string): Promise<VrCompetitionParticipant> {
    const [participant] = await db
      .insert(vrCompetitionParticipants)
      .values({ competitionId, userId, entryEiQScore })
      .returning();
    return participant;
  }

  async getUserVrCompetitions(userId: string): Promise<VrCompetitionParticipant[]> {
    return await db.select().from(vrCompetitionParticipants)
      .where(eq(vrCompetitionParticipants.userId, userId))
      .orderBy(desc(vrCompetitionParticipants.joinedAt));
  }

  async updateVrCompetitionParticipant(id: string, updates: Partial<VrCompetitionParticipant>): Promise<VrCompetitionParticipant> {
    const [participant] = await db
      .update(vrCompetitionParticipants)
      .set(updates)
      .where(eq(vrCompetitionParticipants.id, id))
      .returning();
    return participant;
  }

  // University Partnership System
  async getAllUniversityPartners(): Promise<UniversityPartner[]> {
    return await db.select().from(universityPartners)
      .where(eq(universityPartners.partnershipStatus, 'active'))
      .orderBy(universityPartners.ranking);
  }

  async getEligibleUniversities(eiqScore: number): Promise<UniversityPartner[]> {
    return await db.select().from(universityPartners)
      .where(and(
        eq(universityPartners.partnershipStatus, 'active'),
        lte(universityPartners.minEiQScore, eiqScore.toString())
      ))
      .orderBy(universityPartners.ranking);
  }

  async createUniversityApplication(insertApplication: InsertUniversityApplication): Promise<UniversityApplication> {
    const [application] = await db
      .insert(universityApplications)
      .values(insertApplication)
      .returning();
    return application;
  }

  async getUserUniversityApplications(userId: string): Promise<UniversityApplication[]> {
    return await db.select().from(universityApplications)
      .where(eq(universityApplications.userId, userId))
      .orderBy(desc(universityApplications.createdAt));
  }

  async updateUniversityApplication(id: string, updates: Partial<UniversityApplication>): Promise<UniversityApplication> {
    const [application] = await db
      .update(universityApplications)
      .set(updates)
      .where(eq(universityApplications.id, id))
      .returning();
    return application;
  }

  // Corporate Partnership & Talent Recruitment
  async getAllCorporatePartners(): Promise<CorporatePartner[]> {
    return await db.select().from(corporatePartners)
      .where(eq(corporatePartners.partnershipStatus, 'active'))
      .orderBy(corporatePartners.name);
  }

  async createTalentProfile(insertProfile: InsertTalentProfile): Promise<TalentProfile> {
    const [profile] = await db
      .insert(talentProfile)
      .values(insertProfile)
      .returning();
    return profile;
  }

  async getUserTalentProfile(userId: string): Promise<TalentProfile | undefined> {
    const [profile] = await db.select().from(talentProfile)
      .where(eq(talentProfile.userId, userId));
    return profile || undefined;
  }

  async updateTalentProfile(id: string, updates: Partial<TalentProfile>): Promise<TalentProfile> {
    const [profile] = await db
      .update(talentProfile)
      .set(updates)
      .where(eq(talentProfile.id, id))
      .returning();
    return profile;
  }

  async getRecruitmentMatches(talentProfileId: string): Promise<RecruitmentMatch[]> {
    return await db.select().from(recruitmentMatches)
      .where(eq(recruitmentMatches.talentProfileId, talentProfileId))
      .orderBy(desc(recruitmentMatches.matchScore));
  }

  async createRecruitmentMatch(insertMatch: InsertRecruitmentMatch): Promise<RecruitmentMatch> {
    const [match] = await db
      .insert(recruitmentMatches)
      .values(insertMatch)
      .returning();
    return match;
  }

  async incrementAiInteractions(userId: string) {
    // Increment AI interaction count for user analytics
    console.log(`AI interaction count incremented for user ${userId}`);
    return true;
  }

  // User Onboarding Implementation
  async createUserOnboarding(data: InsertUserOnboarding): Promise<UserOnboarding> {
    const [onboarding] = await db
      .insert(userOnboarding)
      .values(data)
      .returning();
    return onboarding;
  }

  async getUserOnboarding(userId: string): Promise<UserOnboarding | undefined> {
    const [onboarding] = await db
      .select()
      .from(userOnboarding)
      .where(eq(userOnboarding.userId, userId));
    return onboarding || undefined;
  }

  async updateUserOnboarding(id: string, updates: Partial<UserOnboarding>): Promise<UserOnboarding> {
    const [onboarding] = await db
      .update(userOnboarding)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userOnboarding.id, id))
      .returning();
    return onboarding;
  }

  // K-12 Education System Implementation
  async createIndustryTrack(data: any) {
    const [track] = await db.insert(industryTracks).values(data).returning();
    return track;
  }

  async getAllIndustryTracks() {
    return await db.select().from(industryTracks).where(eq(industryTracks.isActive, true));
  }

  async getIndustryTrack(id: string) {
    const [track] = await db.select().from(industryTracks).where(eq(industryTracks.id, id));
    return track;
  }

  async createCurriculumModule(data: any) {
    const [module] = await db.insert(curriculumModules).values(data).returning();
    return module;
  }

  async getModulesByTrack(trackId: string) {
    return await db.select().from(curriculumModules).where(eq(curriculumModules.trackId, trackId));
  }

  async createQuestion(data: any) {
    const [question] = await db.insert(questionBank).values(data).returning();
    return question;
  }

  async getQuestionsByModule(moduleId: string) {
    return await db.select().from(questionBank).where(eq(questionBank.moduleId, moduleId));
  }

  async createAssessmentResponse(data: any) {
    const [response] = await db.insert(assessmentResponses).values(data).returning();
    return response;
  }

  async getUserAssessmentResponses(userId: string) {
    return await db.select().from(assessmentResponses).where(eq(assessmentResponses.userId, userId));
  }

  async createLearningPathway(data: any) {
    const [pathway] = await db.insert(learningPathways).values(data).returning();
    return pathway;
  }

  async getUserLearningPathway(userId: string) {
    const [pathway] = await db.select().from(learningPathways).where(eq(learningPathways.userId, userId));
    return pathway;
  }

  async updateLearningPathway(id: string, updates: any) {
    const [updated] = await db
      .update(learningPathways)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(learningPathways.id, id))
      .returning();
    return updated;
  }

  // Skill Recommendations Implementation
  async createSkillRecommendation(recommendation: InsertSkillRecommendation): Promise<SkillRecommendation> {
    const [created] = await db
      .insert(skillRecommendations)
      .values(recommendation)
      .returning();
    return created;
  }

  async getUserSkillRecommendations(userId: string): Promise<SkillRecommendation[]> {
    return await db
      .select()
      .from(skillRecommendations)
      .where(eq(skillRecommendations.userId, userId))
      .orderBy(desc(skillRecommendations.priority), desc(skillRecommendations.createdAt));
  }

  async updateSkillRecommendationProgress(id: string, progress: number): Promise<SkillRecommendation> {
    const [updated] = await db
      .update(skillRecommendations)
      .set({ 
        progress, 
        updatedAt: new Date(),
        completedAt: progress >= 100 ? new Date() : null
      })
      .where(eq(skillRecommendations.id, id))
      .returning();
    return updated;
  }

  async completeSkillRecommendation(id: string): Promise<SkillRecommendation> {
    const [completed] = await db
      .update(skillRecommendations)
      .set({ 
        progress: 100, 
        isActive: false,
        completedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(skillRecommendations.id, id))
      .returning();
    return completed;
  }

  async getActiveSkillRecommendations(userId: string): Promise<SkillRecommendation[]> {
    return await db
      .select()
      .from(skillRecommendations)
      .where(and(
        eq(skillRecommendations.userId, userId),
        eq(skillRecommendations.isActive, true)
      ))
      .orderBy(desc(skillRecommendations.priority));
  }

  // AI Mentor Sessions Implementation
  async createAiMentorSession(data: InsertAiMentorSession): Promise<AiMentorSession> {
    const [session] = await db
      .insert(aiMentorSessions)
      .values(data)
      .returning();
    return session;
  }

  async getUserAiMentorSessions(userId: string): Promise<AiMentorSession[]> {
    return await db
      .select()
      .from(aiMentorSessions)
      .where(eq(aiMentorSessions.userId, userId))
      .orderBy(desc(aiMentorSessions.createdAt));
  }

  async updateAiMentorSession(id: string, updates: Partial<AiMentorSession>): Promise<AiMentorSession> {
    const [session] = await db
      .update(aiMentorSessions)
      .set(updates)
      .where(eq(aiMentorSessions.id, id))
      .returning();
    return session;
  }

  async getActiveAiMentorSession(userId: string): Promise<AiMentorSession | undefined> {
    const [session] = await db
      .select()
      .from(aiMentorSessions)
      .where(and(
        eq(aiMentorSessions.userId, userId),
        eq(aiMentorSessions.completedAt, null as any)
      ))
      .orderBy(desc(aiMentorSessions.createdAt))
      .limit(1);
    
    return session || undefined;
  }




  // Live Testing Analytics Methods
  async getUserBehaviorAnalytics(userId: string, timeRange: string): Promise<any> {
    const endTime = new Date();
    const startTime = this.getTimeRangeStart(timeRange, endTime);

    const behaviors = await db.select()
      .from(userBehaviorTracking)
      .where(and(
        eq(userBehaviorTracking.userId, userId),
        gte(userBehaviorTracking.createdAt, startTime)
      ));

    return {
      totalEvents: behaviors.length,
      eventTypes: this.groupByEventType(behaviors),
      avgEngagement: this.calculateAvgEngagement(behaviors),
      topPages: this.getTopPages(behaviors),
      deviceUsage: this.getDeviceUsage(behaviors),
      timePatterns: this.getTimePatterns(behaviors)
    };
  }

  private getTimeRangeStart(timeRange: string, now: Date): Date {
    const start = new Date(now);
    switch (timeRange) {
      case '1h': start.setHours(start.getHours() - 1); break;
      case '24h': start.setDate(start.getDate() - 1); break;
      case '7d': start.setDate(start.getDate() - 7); break;
      case '30d': start.setDate(start.getDate() - 30); break;
      default: start.setDate(start.getDate() - 1);
    }
    return start;
  }

  private groupByEventType(behaviors: any[]): Record<string, number> {
    return behaviors.reduce((acc, b) => {
      acc[b.eventType] = (acc[b.eventType] || 0) + 1;
      return acc;
    }, {});
  }

  private calculateAvgEngagement(behaviors: any[]): number {
    if (behaviors.length === 0) return 0;
    const total = behaviors.reduce((sum, b) => sum + (b.interactionQuality || 5), 0);
    return total / behaviors.length;
  }

  private getTopPages(behaviors: any[]): [string, number][] {
    const pageCounts = behaviors.reduce((acc, b) => {
      acc[b.page] = (acc[b.page] || 0) + 1;
      return acc;
    }, {});
    
    return Object.entries(pageCounts)
      .sort(([,a], [,b]) => (b as number) - (a as number))
      .slice(0, 10) as [string, number][];
  }

  private getDeviceUsage(behaviors: any[]): Record<string, number> {
    return behaviors.reduce((acc, b) => {
      const device = b.deviceType || 'unknown';
      acc[device] = (acc[device] || 0) + 1;
      return acc;
    }, {});
  }

  private getTimePatterns(behaviors: any[]): any {
    // Analyze usage patterns by hour of day
    const hourCounts = new Array(24).fill(0);
    behaviors.forEach(b => {
      const hour = new Date(b.createdAt).getHours();
      hourCounts[hour]++;
    });
    
    return {
      byHour: hourCounts,
      peakHour: hourCounts.indexOf(Math.max(...hourCounts)),
      totalEvents: behaviors.length
    };
  }

  // Industry Titan Tracks Methods
  async upsertIndustryTrack(track: any) {
    try {
      // Try to find existing track first
      const [existing] = await db.select().from(industryTracks).where(eq(industryTracks.name, track.name));
      
      if (existing) {
        // Update existing track
        const [result] = await db.update(industryTracks)
          .set(track)
          .where(eq(industryTracks.name, track.name))
          .returning();
        return result;
      } else {
        // Insert new track
        const [result] = await db.insert(industryTracks).values(track).returning();
        return result;
      }
    } catch (error) {
      console.error('[STORAGE] Error upserting industry track:', error);
      return null;
    }
  }

  // Learning Pathways Methods

  async upsertLearningPathway(pathway: any) {
    try {
      // Try to find existing pathway for this user and track
      const [existing] = await db.select().from(learningPathways).where(
        and(
          eq(learningPathways.userId, pathway.userId),
          eq(learningPathways.trackId, pathway.trackId)
        )
      );
      
      if (existing) {
        // Update existing pathway
        const [result] = await db.update(learningPathways)
          .set({...pathway, updatedAt: new Date()})
          .where(eq(learningPathways.id, existing.id))
          .returning();
        return result;
      } else {
        // Insert new pathway
        const [result] = await db.insert(learningPathways).values(pathway).returning();
        return result;
      }
    } catch (error) {
      console.error('[STORAGE] Error upserting learning pathway:', error);
      return null;
    }
  }

  // Custom Questions System implementation
  async createCustomQuestion(question: InsertCustomQuestion): Promise<CustomQuestion> {
    const [newQuestion] = await db
      .insert(customQuestions)
      .values(question)
      .returning();
    return newQuestion;
  }

  async getCustomQuestion(id: string): Promise<CustomQuestion | undefined> {
    const [question] = await db.select().from(customQuestions)
      .where(eq(customQuestions.id, id));
    return question || undefined;
  }

  async getCustomQuestionsByStaff(staffId: string): Promise<CustomQuestion[]> {
    return await db.select().from(customQuestions)
      .where(eq(customQuestions.staffId, staffId))
      .orderBy(desc(customQuestions.createdAt));
  }

  async getCustomQuestionsForStudent(studentId: string): Promise<CustomQuestion[]> {
    return await db.select().from(customQuestions)
      .where(eq(customQuestions.studentId, studentId))
      .orderBy(desc(customQuestions.createdAt));
  }

  async updateCustomQuestion(id: string, updates: Partial<CustomQuestion>): Promise<CustomQuestion> {
    const [updated] = await db
      .update(customQuestions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(customQuestions.id, id))
      .returning();
    return updated;
  }

  async deleteCustomQuestion(id: string): Promise<void> {
    await db.delete(customQuestions)
      .where(eq(customQuestions.id, id));
  }

  // Custom Question Responses
  async createCustomQuestionResponse(response: InsertCustomQuestionResponse): Promise<CustomQuestionResponse> {
    const [newResponse] = await db
      .insert(customQuestionResponses)
      .values(response)
      .returning();
    return newResponse;
  }

  async getCustomQuestionResponses(questionId: string): Promise<CustomQuestionResponse[]> {
    return await db.select().from(customQuestionResponses)
      .where(eq(customQuestionResponses.customQuestionId, questionId))
      .orderBy(desc(customQuestionResponses.createdAt));
  }

  async getStudentCustomQuestionResponses(studentId: string): Promise<CustomQuestionResponse[]> {
    return await db.select().from(customQuestionResponses)
      .where(eq(customQuestionResponses.studentId, studentId))
      .orderBy(desc(customQuestionResponses.createdAt));
  }

  async updateCustomQuestionResponse(id: string, updates: Partial<CustomQuestionResponse>): Promise<CustomQuestionResponse> {
    const [updated] = await db
      .update(customQuestionResponses)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(customQuestionResponses.id, id))
      .returning();
    return updated;
  }

  // AI Question Sessions
  async createAiQuestionSession(session: InsertAiQuestionSession): Promise<AiQuestionSession> {
    const [newSession] = await db
      .insert(aiQuestionSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async getAiQuestionSession(id: string): Promise<AiQuestionSession | undefined> {
    const [session] = await db.select().from(aiQuestionSessions)
      .where(eq(aiQuestionSessions.id, id));
    return session || undefined;
  }

  async getAiQuestionSessions(staffId: string): Promise<AiQuestionSession[]> {
    return await db.select().from(aiQuestionSessions)
      .where(eq(aiQuestionSessions.staffId, staffId))
      .orderBy(desc(aiQuestionSessions.createdAt));
  }

  async updateAiQuestionSession(id: string, updates: Partial<AiQuestionSession>): Promise<AiQuestionSession> {
    const [updated] = await db
      .update(aiQuestionSessions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(aiQuestionSessions.id, id))
      .returning();
    return updated;
  }

  // Question Assignments
  async createQuestionAssignment(assignment: InsertQuestionAssignment): Promise<QuestionAssignment> {
    const [newAssignment] = await db
      .insert(questionAssignments)
      .values(assignment)
      .returning();
    return newAssignment;
  }

  async getQuestionAssignment(id: string): Promise<QuestionAssignment | undefined> {
    const [assignment] = await db.select().from(questionAssignments)
      .where(eq(questionAssignments.id, id));
    return assignment || undefined;
  }

  async getStudentQuestionAssignments(studentId: string): Promise<QuestionAssignment[]> {
    return await db.select().from(questionAssignments)
      .where(eq(questionAssignments.studentId, studentId))
      .orderBy(desc(questionAssignments.assignedAt));
  }

  async getStaffQuestionAssignments(staffId: string): Promise<QuestionAssignment[]> {
    return await db.select().from(questionAssignments)
      .where(eq(questionAssignments.staffId, staffId))
      .orderBy(desc(questionAssignments.assignedAt));
  }

  async updateQuestionAssignment(id: string, updates: Partial<QuestionAssignment>): Promise<QuestionAssignment> {
    const [updated] = await db
      .update(questionAssignments)
      .set(updates)
      .where(eq(questionAssignments.id, id))
      .returning();
    return updated;
  }
  // Knowledge visualization implementations
  async createKnowledgeNode(node: InsertKnowledgeNode): Promise<KnowledgeNode> {
    const [createdNode] = await db
      .insert(knowledgeNodes)
      .values(node)
      .returning();
    return createdNode;
  }

  async getKnowledgeNodesByUser(userId: string): Promise<KnowledgeNode[]> {
    return await db
      .select()
      .from(knowledgeNodes)
      .where(eq(knowledgeNodes.userId, userId))
      .orderBy(desc(knowledgeNodes.createdAt));
  }

  async createKnowledgeConnection(connection: InsertKnowledgeConnection): Promise<KnowledgeConnection> {
    const [createdConnection] = await db
      .insert(knowledgeConnections)
      .values(connection)
      .returning();
    return createdConnection;
  }

  async getKnowledgeConnectionsByUser(userId: string): Promise<KnowledgeConnection[]> {
    return await db
      .select()
      .from(knowledgeConnections)
      .where(eq(knowledgeConnections.userId, userId))
      .orderBy(desc(knowledgeConnections.createdAt));
  }

  async createKnowledgeVisualization(viz: InsertKnowledgeVisualization): Promise<KnowledgeVisualization> {
    const [createdViz] = await db
      .insert(knowledgeVisualizations)
      .values(viz)
      .returning();
    return createdViz;
  }

  async getKnowledgeVisualizationsByUser(userId: string): Promise<KnowledgeVisualization[]> {
    return await db
      .select()
      .from(knowledgeVisualizations)
      .where(eq(knowledgeVisualizations.userId, userId))
      .orderBy(desc(knowledgeVisualizations.createdAt));
  }

  async getAssessmentsByUser(userId: string): Promise<Assessment[]> {
    return await db
      .select()
      .from(assessments)
      .where(eq(assessments.userId, userId))
      .orderBy(desc(assessments.createdAt));
  }

  async getSkillRecommendationsByUser(userId: string): Promise<SkillRecommendation[]> {
    return await db
      .select()
      .from(skillRecommendations)
      .where(eq(skillRecommendations.userId, userId))
      .orderBy(desc(skillRecommendations.createdAt));
  }

  // Seeder support methods implementation
  async createQuestionBankEntry(question: any): Promise<any> {
    const [result] = await db.insert(questionBank).values(question).returning();
    return result;
  }

  async createAILearningData(data: any): Promise<any> {
    const [result] = await db.insert(aiLearningData).values(data).returning();
    return result;
  }

  async getAILearningDataByUser(userId: string): Promise<any[]> {
    return await db.select().from(aiLearningData).where(eq((aiLearningData as any).userId, userId));
  }

  async getAllAILearningData(): Promise<any[]> {
    return await db.select().from(aiLearningData);
  }

  async createSeederCustomQuestion(question: any): Promise<any> {
    const [result] = await db.insert(customQuestions).values(question).returning();
    return result;
  }

  // Chat operations
  async getChatSessions(userId: string): Promise<ChatSession[]> {
    return []; // Mock implementation for demo
  }

  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const newSession: ChatSession = {
      id: `session_${Date.now()}`,
      ...session,
      createdAt: new Date(),
      lastMessageAt: new Date(),
      messageCount: 0
    };
    return newSession;
  }

  async getChatSession(sessionId: string): Promise<ChatSession | undefined> {
    // Mock session for demo
    return {
      id: sessionId,
      userId: 'demo_user',
      title: 'Demo Chat Session',
      createdAt: new Date(),
      lastMessageAt: new Date(),
      messageCount: 0
    };
  }

  async deleteChatSession(sessionId: string): Promise<void> {
    console.log(`Mock: Deleted chat session ${sessionId}`);
  }

  async updateChatSession(sessionId: string, updates: Partial<ChatSession>): Promise<void> {
    console.log(`Mock: Updated chat session ${sessionId}`);
  }

  async getChatMessages(sessionId: string, limit?: number): Promise<ChatMessage[]> {
    return []; // Mock implementation returns empty array
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      ...message,
      timestamp: new Date(),
      metadata: {}
    };
    return newMessage;
  }

  async updateChatMessage(messageId: string, updates: Partial<ChatMessage>): Promise<void> {
    console.log(`Mock: Updated chat message ${messageId}`);
  }

  async deleteChatMessage(messageId: string): Promise<void> {
    console.log(`Mock: Deleted chat message ${messageId}`);
  }

  async getAiConversation(id: string): Promise<any> {
    const [conversation] = await db.select().from(aiConversations).where(eq(aiConversations.id, id));
    return conversation;
  }
  // Question Bank methods for adaptive assessment
  async getAllQuestions(): Promise<QuestionBank[]> {
    return await db.select().from(questionBank).where(eq(questionBank.isActive, true));
  }

  async getQuestionsByDomain(domain: string): Promise<QuestionBank[]> {
    return await db.select().from(questionBank)
      .where(and(eq(questionBank.subject, domain), eq(questionBank.isActive, true)));
  }

  async getQuestionsByDifficulty(minDifficulty: number, maxDifficulty: number): Promise<QuestionBank[]> {
    return await db.select().from(questionBank)
      .where(and(
        gte(questionBank.difficulty, minDifficulty.toString()),
        lte(questionBank.difficulty, maxDifficulty.toString()),
        eq(questionBank.isActive, true)
      ));
  }
}

export const storage = new DatabaseStorage();