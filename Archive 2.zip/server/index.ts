import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Enhanced request logging middleware with detailed debugging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`\n[${timestamp}] ==================== INCOMING REQUEST ====================`);
  console.log(`[REQUEST] ${req.method} ${req.path}`);
  console.log(`[HEADERS] Content-Type: ${req.headers['content-type'] || 'none'}`);
  console.log(`[HEADERS] User-Agent: ${req.headers['user-agent'] || 'none'}`);
  
  if (req.body && Object.keys(req.body).length > 0) {
    console.log(`[REQUEST BODY]:`, JSON.stringify(req.body, null, 2));
  }
  
  if (req.headers.authorization) {
    console.log(`[AUTH HEADER]: Bearer ${req.headers.authorization.substring(7, 37)}...`);
  } else {
    console.log(`[AUTH HEADER]: None provided`);
  }
  
  if (req.query && Object.keys(req.query).length > 0) {
    console.log(`[QUERY PARAMS]:`, JSON.stringify(req.query, null, 2));
  }
  
  console.log(`[COOKIES]:`, req.headers.cookie ? 'Present' : 'None');
  console.log(`================================================================\n`);
  next();
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  // Setup Vite only AFTER routes are registered to prevent API interception
  if (process.env.NODE_ENV !== "production") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    const timestamp = new Date().toISOString();

    // Comprehensive error logging
    console.error(`\n[${timestamp}] ******************** ERROR OCCURRED ********************`);
    console.error(`[ERROR] Status Code: ${status}`);
    console.error(`[ERROR] Message: ${message}`);
    console.error(`[ERROR] Request: ${req.method} ${req.path}`);
    console.error(`[ERROR] Request Body:`, JSON.stringify(req.body, null, 2));
    console.error(`[ERROR] Query Params:`, JSON.stringify(req.query, null, 2));
    console.error(`[ERROR] Headers:`, JSON.stringify({
      'content-type': req.headers['content-type'],
      'authorization': req.headers.authorization ? 'Bearer ***' : 'none',
      'user-agent': req.headers['user-agent']
    }, null, 2));
    console.error(`[ERROR] Full Stack Trace:`);
    console.error(err.stack);
    console.error(`[ERROR] Additional Info:`, {
      name: err.name,
      code: err.code,
      statusCode: err.statusCode,
      type: typeof err
    });
    console.error(`********************************************************\n`);

    res.status(status).json({ 
      success: false,
      message,
      timestamp,
      path: req.path,
      method: req.method,
      status,
      error: process.env.NODE_ENV === 'development' ? {
        stack: err.stack,
        name: err.name,
        code: err.code
      } : undefined
    });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  
  // Enhanced startup logging for deployment debugging
  const timestamp = new Date().toISOString();
  console.log(`\n[${timestamp}] ==================== SERVER STARTUP ====================`);
  console.log(`[STARTUP] Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`[STARTUP] Port: ${port}`);
  console.log(`[STARTUP] Host: 0.0.0.0`);
  console.log(`[STARTUP] Platform: ${process.platform}`);
  console.log(`[STARTUP] Node Version: ${process.version}`);
  console.log(`[STARTUP] Memory Usage:`, process.memoryUsage());
  console.log(`[STARTUP] Working Directory: ${process.cwd()}`);
  console.log(`[STARTUP] Process ID: ${process.pid}`);
  console.log(`[STARTUP] Available Environment Variables:`);
  console.log(`[STARTUP]   - DATABASE_URL: ${process.env.DATABASE_URL ? 'configured' : 'not set'}`);
  console.log(`[STARTUP]   - JWT_SECRET: ${process.env.JWT_SECRET ? 'configured' : 'not set'}`);
  console.log(`[STARTUP]   - FRONTEND_URL: ${process.env.FRONTEND_URL || 'not set'}`);
  console.log(`[STARTUP]   - NODE_ENV: ${process.env.NODE_ENV || 'not set'}`);
  console.log(`[STARTUP] Server configuration completed, starting listen...`);
  console.log(`================================================================\n`);
  
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    const startupTimestamp = new Date().toISOString();
    console.log(`\n[${startupTimestamp}] ==================== SERVER READY ====================`);
    console.log(`[SERVER READY] ✅ Server is now listening on http://0.0.0.0:${port}`);
    console.log(`[SERVER READY] ✅ Health check endpoint available at /health`);
    console.log(`[SERVER READY] ✅ Readiness check endpoint available at /ready`);
    console.log(`[SERVER READY] ✅ API endpoints available at /api/*`);
    console.log(`[SERVER READY] ✅ Frontend served from root path`);
    console.log(`[SERVER READY] ✅ WebSocket connections accepted`);
    console.log(`[SERVER READY] Server startup completed successfully`);
    console.log(`===============================================================\n`);
    log(`serving on port ${port}`);
  });
  
  // Handle graceful shutdown for deployment systems
  process.on('SIGTERM', () => {
    const shutdownTimestamp = new Date().toISOString();
    console.log(`\n[${shutdownTimestamp}] ==================== GRACEFUL SHUTDOWN ====================`);
    console.log(`[SHUTDOWN] SIGTERM received, initiating graceful shutdown...`);
    
    server.close((err) => {
      if (err) {
        console.error(`[SHUTDOWN] Error during server close:`, err);
        process.exit(1);
      }
      console.log(`[SHUTDOWN] ✅ Server closed gracefully`);
      console.log(`[SHUTDOWN] ✅ All connections terminated`);
      console.log(`===============================================================\n`);
      process.exit(0);
    });
  });
  
  process.on('SIGINT', () => {
    const shutdownTimestamp = new Date().toISOString();
    console.log(`\n[${shutdownTimestamp}] ==================== INTERRUPT SHUTDOWN ====================`);
    console.log(`[SHUTDOWN] SIGINT received, initiating shutdown...`);
    process.exit(0);
  });
})();
