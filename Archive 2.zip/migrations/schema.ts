import { pgTable, foreignKey, varchar, text, numeric, integer, boolean, jsonb, timestamp, unique, index } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const assessments = pgTable("assessments", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	type: text().notNull(),
	score: numeric({ precision: 5, scale:  2 }),
	progress: integer().default(0),
	completed: boolean().default(false),
	data: jsonb(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
	difficulty: text().default('adaptive'),
	adaptiveLevel: numeric("adaptive_level", { precision: 3, scale:  2 }).default('0.00'),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "assessments_user_id_users_id_fk"
		}),
]);

export const documents = pgTable("documents", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	fileName: text("file_name").notNull(),
	fileType: text("file_type").notNull(),
	fileSize: integer("file_size"),
	status: text().default('processing'),
	extractedData: jsonb("extracted_data"),
	uploadedAt: timestamp("uploaded_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "documents_user_id_users_id_fk"
		}),
]);

export const courseFeed = pgTable("course_feed", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	title: text().notNull(),
	content: text().notNull(),
	type: text().notNull(),
	category: text().notNull(),
	priority: integer().default(0),
	isActive: boolean("is_active").default(true),
	publishedAt: timestamp("published_at", { mode: 'string' }).defaultNow(),
});

export const aiConversations = pgTable("ai_conversations", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	messages: jsonb().notNull(),
	provider: text().notNull(),
	sessionId: varchar("session_id"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "ai_conversations_user_id_users_id_fk"
		}),
]);

export const corporatePartners = pgTable("corporate_partners", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	industry: text().notNull(),
	size: text(),
	logoUrl: text("logo_url"),
	website: text(),
	contactEmail: text("contact_email"),
	headquarters: text(),
	targetEiqRange: jsonb("target_eiq_range"),
	talentRequirements: jsonb("talent_requirements"),
	partnershipTier: text("partnership_tier"),
	partnershipStatus: text("partnership_status").default('active'),
	recruitmentQuota: integer("recruitment_quota"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
});

export const users = pgTable("users", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	username: text(),
	email: text().notNull(),
	password: text(),
	firstName: text("first_name"),
	lastName: text("last_name"),
	currentLevel: text("current_level").default('Foundation'),
	assessmentProgress: integer("assessment_progress").default(0),
	learningStreak: integer("learning_streak").default(0),
	aiInteractions: integer("ai_interactions").default(0),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
	profileImageUrl: text("profile_image_url"),
	authProvider: text("auth_provider").default('local'),
	providerId: text("provider_id"),
	linkedProviders: text("linked_providers").array().default([""]),
	emailVerified: boolean("email_verified").default(false),
	lastLoginAt: timestamp("last_login_at", { mode: 'string' }),
	role: text().default('student'),
	institutionId: varchar("institution_id"),
	staffCredentials: jsonb("staff_credentials"),
	isActive: boolean("is_active").default(true),
}, (table) => [
	unique("users_username_unique").on(table.username),
	unique("users_email_unique").on(table.email),
]);

export const learningPaths = pgTable("learning_paths", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	pathType: text("path_type").notNull(),
	currentStep: integer("current_step").default(0),
	progress: integer().default(0),
	completed: boolean().default(false),
	data: jsonb(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "learning_paths_user_id_users_id_fk"
		}),
]);

export const studyGroups = pgTable("study_groups", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	description: text(),
	topic: text().notNull(),
	maxMembers: integer("max_members").default(10),
	isActive: boolean("is_active").default(true),
	createdBy: varchar("created_by").notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.createdBy],
			foreignColumns: [users.id],
			name: "study_groups_created_by_users_id_fk"
		}),
]);

export const studyGroupMembers = pgTable("study_group_members", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	groupId: varchar("group_id").notNull(),
	userId: varchar("user_id").notNull(),
	role: text().default('member'),
	joinedAt: timestamp("joined_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.groupId],
			foreignColumns: [studyGroups.id],
			name: "study_group_members_group_id_study_groups_id_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "study_group_members_user_id_users_id_fk"
		}),
]);

export const talentProfiles = pgTable("talent_profiles", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	currentEiqScore: numeric("current_eiq_score", { precision: 5, scale:  2 }),
	peakEiqScore: numeric("peak_eiq_score", { precision: 5, scale:  2 }),
	skillsProfile: jsonb("skills_profile"),
	careerInterests: jsonb("career_interests"),
	availability: text(),
	resumeData: jsonb("resume_data"),
	portfolioLinks: jsonb("portfolio_links"),
	isOpenToRecruitment: boolean("is_open_to_recruitment").default(false),
	visibilitySettings: jsonb("visibility_settings"),
	lastProfileUpdate: timestamp("last_profile_update", { mode: 'string' }).defaultNow(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "talent_profiles_user_id_users_id_fk"
		}),
]);

export const universityApplications = pgTable("university_applications", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	universityId: varchar("university_id").notNull(),
	program: text().notNull(),
	applicationEiqScore: numeric("application_eiq_score", { precision: 5, scale:  2 }),
	transcriptAnalysis: jsonb("transcript_analysis"),
	recommendationStatus: text("recommendation_status"),
	applicationData: jsonb("application_data"),
	status: text().default('draft'),
	submittedAt: timestamp("submitted_at", { mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "university_applications_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.universityId],
			foreignColumns: [universityPartners.id],
			name: "university_applications_university_id_university_partners_id_fk"
		}),
]);

export const universityPartners = pgTable("university_partners", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	country: text().notNull(),
	ranking: integer(),
	logoUrl: text("logo_url"),
	website: text(),
	contactEmail: text("contact_email"),
	minEiqScore: numeric("min_eiq_score", { precision: 5, scale:  2 }),
	preferredEiqScore: numeric("preferred_eiq_score", { precision: 5, scale:  2 }),
	programs: jsonb(),
	admissionProcess: jsonb("admission_process"),
	partnershipStatus: text("partnership_status").default('active'),
	partnershipTier: text("partnership_tier"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
});

export const vrCompetitionParticipants = pgTable("vr_competition_participants", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	competitionId: varchar("competition_id").notNull(),
	userId: varchar("user_id").notNull(),
	entryEiqScore: numeric("entry_eiq_score", { precision: 5, scale:  2 }),
	currentScore: numeric("current_score", { precision: 8, scale:  2 }).default('0'),
	rank: integer(),
	completedChallenges: integer("completed_challenges").default(0),
	totalTimeSpent: integer("total_time_spent").default(0),
	vrSessionData: jsonb("vr_session_data"),
	achievements: jsonb(),
	joinedAt: timestamp("joined_at", { mode: 'string' }).defaultNow(),
	lastActiveAt: timestamp("last_active_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "vr_competition_participants_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.competitionId],
			foreignColumns: [vrCompetitions.id],
			name: "vr_competition_participants_competition_id_vr_competitions_id_f"
		}),
]);

export const aiTutoringSessions = pgTable("ai_tutoring_sessions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	sessionType: text("session_type").notNull(),
	subject: text().notNull(),
	currentEiqScore: numeric("current_eiq_score", { precision: 5, scale:  2 }),
	targetEiqScore: numeric("target_eiq_score", { precision: 5, scale:  2 }),
	improvementPlan: jsonb("improvement_plan"),
	conversationHistory: jsonb("conversation_history").notNull(),
	learningGaps: jsonb("learning_gaps"),
	progressMetrics: jsonb("progress_metrics"),
	aiProvider: text("ai_provider").default('openai').notNull(),
	status: text().default('active'),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
	gradeLevel: text("grade_level"),
	masteryLevel: text("mastery_level").default('attempted'),
	hintUsage: jsonb("hint_usage"),
	sessionDuration: integer("session_duration"),
	questionsAnswered: integer("questions_answered").default(0),
	correctAnswers: integer("correct_answers").default(0),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "ai_tutoring_sessions_user_id_users_id_fk"
		}),
]);

export const degreeAudits = pgTable("degree_audits", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	degreePlanId: varchar("degree_plan_id").notNull(),
	auditType: text("audit_type").notNull(),
	completedRequirements: jsonb("completed_requirements"),
	pendingRequirements: jsonb("pending_requirements"),
	missingRequirements: jsonb("missing_requirements"),
	excessCredits: jsonb("excess_credits"),
	substituteCredits: jsonb("substitute_credits"),
	waivedRequirements: jsonb("waived_requirements"),
	gpaCalculation: jsonb("gpa_calculation"),
	graduationEligibility: text("graduation_eligibility"),
	recommendedActions: jsonb("recommended_actions"),
	runDate: timestamp("run_date", { mode: 'string' }).defaultNow(),
	auditResults: jsonb("audit_results"),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "degree_audits_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.degreePlanId],
			foreignColumns: [studentDegreePlans.id],
			name: "degree_audits_degree_plan_id_student_degree_plans_id_fk"
		}),
]);

export const recruitmentMatches = pgTable("recruitment_matches", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	talentProfileId: varchar("talent_profile_id").notNull(),
	corporatePartnerId: varchar("corporate_partner_id").notNull(),
	jobTitle: text("job_title").notNull(),
	matchScore: numeric("match_score", { precision: 5, scale:  2 }),
	eiqRequirement: numeric("eiq_requirement", { precision: 5, scale:  2 }),
	jobDescription: text("job_description"),
	salary: jsonb(),
	status: text().default('matched'),
	contactedAt: timestamp("contacted_at", { mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.talentProfileId],
			foreignColumns: [talentProfiles.id],
			name: "recruitment_matches_talent_profile_id_talent_profiles_id_fk"
		}),
	foreignKey({
			columns: [table.corporatePartnerId],
			foreignColumns: [corporatePartners.id],
			name: "recruitment_matches_corporate_partner_id_corporate_partners_id_"
		}),
]);

export const vrCompetitions = pgTable("vr_competitions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	title: text().notNull(),
	description: text(),
	competitionType: text("competition_type").notNull(),
	subject: text().notNull(),
	difficulty: text().notNull(),
	vrEnvironment: text("vr_environment").notNull(),
	maxParticipants: integer("max_participants").default(100),
	entryRequirement: numeric("entry_requirement", { precision: 5, scale:  2 }),
	prizeStructure: jsonb("prize_structure"),
	startDate: timestamp("start_date", { mode: 'string' }),
	endDate: timestamp("end_date", { mode: 'string' }),
	status: text().default('upcoming'),
	leaderboard: jsonb(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
});

export const oauthProviders = pgTable("oauth_providers", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	provider: text().notNull(),
	providerId: text("provider_id").notNull(),
	email: text(),
	name: text(),
	profileImageUrl: text("profile_image_url"),
	accessToken: text("access_token"),
	refreshToken: text("refresh_token"),
	tokenExpiry: timestamp("token_expiry", { mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "oauth_providers_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const courses = pgTable("courses", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	courseCode: text("course_code").notNull(),
	title: text().notNull(),
	description: text(),
	credits: integer().notNull(),
	department: text().notNull(),
	level: text().notNull(),
	prerequisites: jsonb(),
	corequisites: jsonb(),
	difficulty: text(),
	averageWorkload: integer("average_workload"),
	passRate: numeric("pass_rate", { precision: 5, scale:  2 }),
	recommendedEiqScore: numeric("recommended_eiq_score", { precision: 5, scale:  2 }),
	offerings: jsonb(),
	maxEnrollment: integer("max_enrollment"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	unique("courses_course_code_unique").on(table.courseCode),
]);

export const courseDemandAnalytics = pgTable("course_demand_analytics", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	courseId: varchar("course_id").notNull(),
	semester: text().notNull(),
	year: integer().notNull(),
	plannedEnrollment: integer("planned_enrollment"),
	actualEnrollment: integer("actual_enrollment"),
	waitlistSize: integer("waitlist_size"),
	demandScore: numeric("demand_score", { precision: 5, scale:  2 }),
	shortageRisk: text("shortage_risk"),
	recommendedSections: integer("recommended_sections"),
	eiqDrivenDemand: jsonb("eiq_driven_demand"),
	generatedAt: timestamp("generated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.courseId],
			foreignColumns: [courses.id],
			name: "course_demand_analytics_course_id_courses_id_fk"
		}),
]);

export const studentDegreePlans = pgTable("student_degree_plans", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	degreeProgramId: varchar("degree_program_id").notNull(),
	planName: text("plan_name").notNull(),
	isActive: boolean("is_active").default(true),
	isPrimary: boolean("is_primary").default(false),
	currentGpa: numeric("current_gpa", { precision: 3, scale:  2 }),
	completedCredits: integer("completed_credits").default(0),
	remainingCredits: integer("remaining_credits"),
	projectedGraduationDate: timestamp("projected_graduation_date", { mode: 'string' }),
	actualGraduationDate: timestamp("actual_graduation_date", { mode: 'string' }),
	planStatus: text("plan_status").default('active'),
	riskFactors: jsonb("risk_factors"),
	interventionRecommendations: jsonb("intervention_recommendations"),
	eiqBasedRecommendations: jsonb("eiq_based_recommendations"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "student_degree_plans_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.degreeProgramId],
			foreignColumns: [degreePrograms.id],
			name: "student_degree_plans_degree_program_id_degree_programs_id_fk"
		}),
]);

export const degreePrograms = pgTable("degree_programs", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	universityId: varchar("university_id").notNull(),
	name: text().notNull(),
	degreeType: text("degree_type").notNull(),
	department: text().notNull(),
	totalCredits: integer("total_credits").notNull(),
	estimatedDuration: integer("estimated_duration").notNull(),
	minEiqScore: numeric("min_eiq_score", { precision: 5, scale:  2 }),
	recommendedEiqScore: numeric("recommended_eiq_score", { precision: 5, scale:  2 }),
	prerequisites: jsonb(),
	coreRequirements: jsonb("core_requirements"),
	electiveRequirements: jsonb("elective_requirements"),
	specializations: jsonb(),
	careerOutcomes: jsonb("career_outcomes"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.universityId],
			foreignColumns: [universityPartners.id],
			name: "degree_programs_university_id_university_partners_id_fk"
		}),
]);

export const plannedCourses = pgTable("planned_courses", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	degreePlanId: varchar("degree_plan_id").notNull(),
	courseId: varchar("course_id").notNull(),
	plannedSemester: text("planned_semester").notNull(),
	plannedYear: integer("planned_year").notNull(),
	semesterOrder: integer("semester_order"),
	status: text().default('planned'),
	actualGrade: text("actual_grade"),
	gradePoints: numeric("grade_points", { precision: 3, scale:  2 }),
	isRequired: boolean("is_required").default(true),
	requirementType: text("requirement_type"),
	alternativeCourses: jsonb("alternative_courses"),
	eiqRecommendationScore: numeric("eiq_recommendation_score", { precision: 3, scale:  2 }),
	difficultyPrediction: text("difficulty_prediction"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.degreePlanId],
			foreignColumns: [studentDegreePlans.id],
			name: "planned_courses_degree_plan_id_student_degree_plans_id_fk"
		}),
	foreignKey({
			columns: [table.courseId],
			foreignColumns: [courses.id],
			name: "planned_courses_course_id_courses_id_fk"
		}),
]);

export const userOnboarding = pgTable("user_onboarding", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	personalInfo: jsonb("personal_info").notNull(),
	educationalBackground: jsonb("educational_background").notNull(),
	careerGoals: jsonb("career_goals").notNull(),
	learningPreferences: jsonb("learning_preferences").notNull(),
	assessmentReadiness: jsonb("assessment_readiness").notNull(),
	completed: boolean().default(true),
	recommendedTrack: text("recommended_track"),
	estimatedEiqRange: text("estimated_eiq_range"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
	educationalLevel: text("educational_level").notNull(),
	gradeLevel: text("grade_level"),
	age: integer(),
	pathwayType: text("pathway_type").notNull(),
	parentEmail: text("parent_email"),
	schoolName: text("school_name"),
	preferredSubjects: text("preferred_subjects").array(),
	mentorPersonality: text("mentor_personality").default('supportive'),
	aiConversationHistory: jsonb("ai_conversation_history"),
	personalizedInsights: jsonb("personalized_insights"),
	adaptiveSuggestions: jsonb("adaptive_suggestions"),
	engagementLevel: integer("engagement_level").default(5),
	mentorFeedbackRating: integer("mentor_feedback_rating"),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_onboarding_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const assessmentResponses = pgTable("assessment_responses", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	questionId: varchar("question_id").notNull(),
	sessionId: varchar("session_id"),
	userAnswer: jsonb("user_answer").notNull(),
	isCorrect: boolean("is_correct").notNull(),
	timeSpent: integer("time_spent").notNull(),
	hintsUsed: integer("hints_used").default(0),
	attemptsCount: integer("attempts_count").default(1),
	masteryLevel: text("mastery_level"),
	aiExplanation: text("ai_explanation"),
	responseDate: timestamp("response_date", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "assessment_responses_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.questionId],
			foreignColumns: [questionBank.id],
			name: "assessment_responses_question_id_question_bank_id_fk"
		}),
	foreignKey({
			columns: [table.sessionId],
			foreignColumns: [aiTutoringSessions.id],
			name: "assessment_responses_session_id_ai_tutoring_sessions_id_fk"
		}),
]);

export const skillRecommendations = pgTable("skill_recommendations", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	skillCategory: text("skill_category").notNull(),
	skillName: text("skill_name").notNull(),
	currentLevel: text("current_level").notNull(),
	targetLevel: text("target_level").notNull(),
	priority: integer().default(1),
	estimatedHours: integer("estimated_hours").default(0),
	prerequisiteSkills: text("prerequisite_skills").array().default([""]),
	learningPath: jsonb("learning_path").notNull(),
	aiReasoning: text("ai_reasoning"),
	progress: integer().default(0),
	isActive: boolean("is_active").default(true),
	completedAt: timestamp("completed_at", { mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "skill_recommendations_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const exerciseAttempts = pgTable("exercise_attempts", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	exerciseId: varchar("exercise_id").notNull(),
	attemptNumber: integer("attempt_number").default(1),
	startTime: timestamp("start_time", { mode: 'string' }).defaultNow(),
	endTime: timestamp("end_time", { mode: 'string' }),
	timeSpent: integer("time_spent"),
	userResponse: jsonb("user_response").notNull(),
	score: numeric({ precision: 5, scale:  2 }),
	masteryLevel: text("mastery_level"),
	feedback: text(),
	hintsUsed: integer("hints_used").default(0),
	isCompleted: boolean("is_completed").default(false),
	aiAnalysis: jsonb("ai_analysis"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "exercise_attempts_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.exerciseId],
			foreignColumns: [practiceExercises.id],
			name: "exercise_attempts_exercise_id_practice_exercises_id_fk"
		}),
]);

export const questionBank = pgTable("question_bank", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	moduleId: varchar("module_id").notNull(),
	questionType: text("question_type").notNull(),
	subject: text().notNull(),
	topic: text().notNull(),
	difficulty: numeric({ precision: 3, scale:  2 }).notNull(),
	questionText: text("question_text").notNull(),
	questionData: jsonb("question_data").notNull(),
	explanation: text().notNull(),
	hints: jsonb(),
	tags: jsonb(),
	aiGenerated: boolean("ai_generated").default(false),
	validatedBy: varchar("validated_by"),
	usageCount: integer("usage_count").default(0),
	successRate: numeric("success_rate", { precision: 5, scale:  2 }),
	averageTime: integer("average_time"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.moduleId],
			foreignColumns: [curriculumModules.id],
			name: "question_bank_module_id_curriculum_modules_id_fk"
		}),
]);

export const industryTracks = pgTable("industry_tracks", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	displayName: text("display_name").notNull(),
	description: text().notNull(),
	focusAreas: jsonb("focus_areas").notNull(),
	ageRanges: jsonb("age_ranges").notNull(),
	prerequisites: jsonb(),
	learningObjectives: jsonb("learning_objectives").notNull(),
	industryPartners: jsonb("industry_partners"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
});

export const curriculumModules = pgTable("curriculum_modules", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	trackId: varchar("track_id").notNull(),
	name: text().notNull(),
	description: text().notNull(),
	gradeLevel: text("grade_level").notNull(),
	subject: text().notNull(),
	difficulty: text().notNull(),
	estimatedDuration: integer("estimated_duration").notNull(),
	prerequisites: jsonb(),
	learningObjectives: jsonb("learning_objectives").notNull(),
	assessmentCriteria: jsonb("assessment_criteria").notNull(),
	contentStructure: jsonb("content_structure").notNull(),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.trackId],
			foreignColumns: [industryTracks.id],
			name: "curriculum_modules_track_id_industry_tracks_id_fk"
		}),
]);

export const practiceExercises = pgTable("practice_exercises", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	moduleId: varchar("module_id").notNull(),
	title: text().notNull(),
	description: text(),
	exerciseType: text("exercise_type").notNull(),
	difficulty: numeric({ precision: 3, scale:  2 }).notNull(),
	estimatedTime: integer("estimated_time").notNull(),
	instructions: text().notNull(),
	exerciseData: jsonb("exercise_data").notNull(),
	solutionData: jsonb("solution_data"),
	hints: jsonb(),
	prerequisites: jsonb(),
	learningObjectives: jsonb("learning_objectives"),
	isAdaptive: boolean("is_adaptive").default(false),
	adaptiveParameters: jsonb("adaptive_parameters"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.moduleId],
			foreignColumns: [curriculumModules.id],
			name: "practice_exercises_module_id_curriculum_modules_id_fk"
		}),
]);

export const learningPathways = pgTable("learning_pathways", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	trackId: varchar("track_id").notNull(),
	pathwayType: text("pathway_type").notNull(),
	currentModule: varchar("current_module"),
	completedModules: jsonb("completed_modules").default([]),
	progressMap: jsonb("progress_map").notNull(),
	adaptiveRecommendations: jsonb("adaptive_recommendations"),
	difficultyProfile: jsonb("difficulty_profile"),
	learningStyle: text("learning_style"),
	weeklyGoals: jsonb("weekly_goals"),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "learning_pathways_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.trackId],
			foreignColumns: [industryTracks.id],
			name: "learning_pathways_track_id_industry_tracks_id_fk"
		}),
	foreignKey({
			columns: [table.currentModule],
			foreignColumns: [curriculumModules.id],
			name: "learning_pathways_current_module_curriculum_modules_id_fk"
		}),
]);

export const videoLessons = pgTable("video_lessons", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	moduleId: varchar("module_id").notNull(),
	title: text().notNull(),
	description: text(),
	videoUrl: text("video_url"),
	duration: integer().notNull(),
	transcript: text(),
	lessonOrder: integer("lesson_order").notNull(),
	prerequisites: jsonb(),
	keyConceptsIntroduced: jsonb("key_concepts_introduced"),
	practiceExercises: jsonb("practice_exercises"),
	isInteractive: boolean("is_interactive").default(false),
	interactiveElements: jsonb("interactive_elements"),
	viewCount: integer("view_count").default(0),
	averageRating: numeric("average_rating", { precision: 3, scale:  2 }),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.moduleId],
			foreignColumns: [curriculumModules.id],
			name: "video_lessons_module_id_curriculum_modules_id_fk"
		}),
]);

export const videoProgress = pgTable("video_progress", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	videoId: varchar("video_id").notNull(),
	watchedDuration: integer("watched_duration").default(0),
	completionPercentage: numeric("completion_percentage", { precision: 5, scale:  2 }).default('0'),
	lastWatchedPosition: integer("last_watched_position").default(0),
	isCompleted: boolean("is_completed").default(false),
	notesCount: integer("notes_count").default(0),
	questionsAsked: integer("questions_asked").default(0),
	userRating: integer("user_rating"),
	watchHistory: jsonb("watch_history"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "video_progress_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.videoId],
			foreignColumns: [videoLessons.id],
			name: "video_progress_video_id_video_lessons_id_fk"
		}),
]);

export const aiMentorSessions = pgTable("ai_mentor_sessions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	sessionType: text("session_type").notNull(),
	startedAt: timestamp("started_at", { mode: 'string' }).defaultNow(),
	completedAt: timestamp("completed_at", { mode: 'string' }),
	conversationLog: jsonb("conversation_log").notNull(),
	insights: jsonb(),
	actionItems: jsonb("action_items"),
	userSatisfaction: integer("user_satisfaction"),
	mentorPersonality: text("mentor_personality").notNull(),
	aiProvider: text("ai_provider").default('anthropic'),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "ai_mentor_sessions_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const aiLearningData = pgTable("ai_learning_data", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	dataType: text("data_type").notNull(),
	sourceUserId: varchar("source_user_id"),
	sourceSessionId: varchar("source_session_id"),
	rawData: jsonb("raw_data").notNull(),
	processedData: jsonb("processed_data"),
	patterns: jsonb(),
	correlations: jsonb(),
	featureVector: jsonb("feature_vector"),
	labels: text().array(),
	confidence: numeric({ precision: 3, scale:  2 }),
	modelVersion: text("model_version"),
	processingAlgorithm: text("processing_algorithm"),
	validationStatus: text("validation_status").default('pending'),
	learningImpact: jsonb("learning_impact"),
	predictionAccuracy: numeric("prediction_accuracy", { precision: 3, scale:  2 }),
	improvementMetrics: jsonb("improvement_metrics"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.sourceUserId],
			foreignColumns: [users.id],
			name: "ai_learning_data_source_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.sourceSessionId],
			foreignColumns: [liveTestingSessions.id],
			name: "ai_learning_data_source_session_id_live_testing_sessions_id_fk"
		}),
]);

export const realTimeAnalytics = pgTable("real_time_analytics", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	timeWindow: text("time_window").notNull(),
	timestamp: timestamp({ mode: 'string' }).defaultNow().notNull(),
	activeUsers: integer("active_users").default(0),
	newRegistrations: integer("new_registrations").default(0),
	assessmentSessions: integer("assessment_sessions").default(0),
	completionRate: numeric("completion_rate", { precision: 3, scale:  2 }),
	avgResponseTime: integer("avg_response_time"),
	errorRate: numeric("error_rate", { precision: 3, scale:  2 }),
	serverLoad: numeric("server_load", { precision: 3, scale:  2 }),
	databaseConnections: integer("database_connections"),
	avgSessionDuration: integer("avg_session_duration"),
	pagesPerSession: numeric("pages_per_session", { precision: 3, scale:  2 }),
	bounceRate: numeric("bounce_rate", { precision: 3, scale:  2 }),
	conversionRate: numeric("conversion_rate", { precision: 3, scale:  2 }),
	aiInteractions: integer("ai_interactions").default(0),
	hintsGenerated: integer("hints_generated").default(0),
	adaptiveAdjustments: integer("adaptive_adjustments").default(0),
	learningEfficiency: numeric("learning_efficiency", { precision: 3, scale:  2 }),
	testResults: jsonb("test_results"),
	statSigResults: jsonb("stat_sig_results"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
});

export const liveTestingSessions = pgTable("live_testing_sessions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id"),
	sessionType: text("session_type").notNull(),
	startedAt: timestamp("started_at", { mode: 'string' }).defaultNow(),
	endedAt: timestamp("ended_at", { mode: 'string' }),
	duration: integer(),
	isActive: boolean("is_active").default(true),
	testGroup: text("test_group"),
	testVariant: text("test_variant"),
	goalMetrics: jsonb("goal_metrics"),
	interactionCount: integer("interaction_count").default(0),
	errorCount: integer("error_count").default(0),
	completionRate: numeric("completion_rate", { precision: 3, scale:  2 }),
	satisfactionScore: integer("satisfaction_score"),
	learningObjectives: text("learning_objectives").array(),
	achievedObjectives: text("achieved_objectives").array().default([""]),
	adaptiveAdjustments: jsonb("adaptive_adjustments"),
	aiInsights: jsonb("ai_insights"),
	behaviorPatterns: jsonb("behavior_patterns"),
	performanceMetrics: jsonb("performance_metrics"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "live_testing_sessions_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const userBehaviorTracking = pgTable("user_behavior_tracking", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	sessionId: varchar("session_id").notNull(),
	eventType: text("event_type").notNull(),
	eventData: jsonb("event_data").notNull(),
	page: text().notNull(),
	component: text(),
	responseTime: integer("response_time"),
	timeOnPage: integer("time_on_page"),
	scrollDepth: integer("scroll_depth"),
	clickPath: text("click_path").array().default([""]),
	interactionQuality: integer("interaction_quality"),
	focusTime: integer("focus_time"),
	idleTime: integer("idle_time"),
	userAgent: text("user_agent"),
	ipAddress: text("ip_address"),
	deviceType: text("device_type"),
	browserType: text("browser_type"),
	viewport: jsonb(),
	connectionSpeed: text("connection_speed"),
	experimentGroup: text("experiment_group"),
	featureFlags: text("feature_flags").array().default([""]),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_behavior_tracking_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const sessions = pgTable("sessions", {
	sid: varchar().primaryKey().notNull(),
	sess: jsonb().notNull(),
	expire: timestamp({ mode: 'string' }).notNull(),
}, (table) => [
	index("IDX_session_expire").using("btree", table.expire.asc().nullsLast().op("timestamp_ops")),
]);

export const achievementProgress = pgTable("achievement_progress", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	badgeId: varchar("badge_id").notNull(),
	currentProgress: integer("current_progress").default(0),
	targetValue: integer("target_value").notNull(),
	progressData: jsonb("progress_data"),
	lastUpdated: timestamp("last_updated", { mode: 'string' }).defaultNow(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	index("idx_achievement_progress_badge").using("btree", table.badgeId.asc().nullsLast().op("text_ops")),
	index("idx_achievement_progress_user").using("btree", table.userId.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "achievement_progress_user_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.badgeId],
			foreignColumns: [achievementBadges.id],
			name: "achievement_progress_badge_id_achievement_badges_id_fk"
		}).onDelete("cascade"),
]);

export const achievementBadges = pgTable("achievement_badges", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	category: text().notNull(),
	tier: text().notNull(),
	title: text().notNull(),
	description: text().notNull(),
	iconPath: text("icon_path").notNull(),
	colorScheme: text("color_scheme").notNull(),
	criteria: jsonb().notNull(),
	points: integer().default(0).notNull(),
	rarity: text().default('common').notNull(),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	unique("achievement_badges_name_unique").on(table.name),
]);

export const userBadges = pgTable("user_badges", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	badgeId: varchar("badge_id").notNull(),
	earnedAt: timestamp("earned_at", { mode: 'string' }).defaultNow(),
	progress: jsonb(),
	isDisplayed: boolean("is_displayed").default(true),
	notificationSent: boolean("notification_sent").default(false),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	index("idx_user_badges_badge_id").using("btree", table.badgeId.asc().nullsLast().op("text_ops")),
	index("idx_user_badges_user_id").using("btree", table.userId.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "user_badges_user_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.badgeId],
			foreignColumns: [achievementBadges.id],
			name: "user_badges_badge_id_achievement_badges_id_fk"
		}).onDelete("cascade"),
]);

export const learningHints = pgTable("learning_hints", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	questionId: varchar("question_id"),
	content: text().notNull(),
	type: text().notNull(),
	difficulty: text().notNull(),
	relevanceScore: numeric("relevance_score", { precision: 3, scale:  2 }).default('0.50'),
	context: jsonb(),
	isUseful: boolean("is_useful"),
	wasFollowed: boolean("was_followed"),
	timeToShow: integer("time_to_show"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "learning_hints_user_id_users_id_fk"
		}),
]);

export const hintEffectiveness = pgTable("hint_effectiveness", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	hintId: varchar("hint_id").notNull(),
	performanceBefore: numeric("performance_before", { precision: 3, scale:  2 }),
	performanceAfter: numeric("performance_after", { precision: 3, scale:  2 }),
	improvementScore: numeric("improvement_score", { precision: 3, scale:  2 }),
	contextSimilarity: numeric("context_similarity", { precision: 3, scale:  2 }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "hint_effectiveness_user_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.hintId],
			foreignColumns: [learningHints.id],
			name: "hint_effectiveness_hint_id_learning_hints_id_fk"
		}),
]);

export const chatMessages = pgTable("chat_messages", {
	id: varchar().primaryKey().notNull(),
	sessionId: varchar("session_id").notNull(),
	role: varchar().notNull(),
	content: text().notNull(),
	timestamp: timestamp({ mode: 'string' }).defaultNow().notNull(),
	metadata: jsonb().default({}).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.sessionId],
			foreignColumns: [chatSessions.id],
			name: "chat_messages_session_id_chat_sessions_id_fk"
		}).onDelete("cascade"),
]);

export const chatSessions = pgTable("chat_sessions", {
	id: varchar().primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	title: varchar().notNull(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow().notNull(),
	lastMessageAt: timestamp("last_message_at", { mode: 'string' }).defaultNow().notNull(),
	messageCount: integer("message_count").default(0).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "chat_sessions_user_id_users_id_fk"
		}),
]);

export const institutions = pgTable("institutions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	name: text().notNull(),
	type: text().notNull(),
	accreditation: text(),
	website: text(),
	contactEmail: text("contact_email"),
	address: text(),
	isActive: boolean("is_active").default(true),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
});

export const staffObservations = pgTable("staff_observations", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	staffId: varchar("staff_id").notNull(),
	studentId: varchar("student_id").notNull(),
	observationType: text("observation_type").notNull(),
	title: text().notNull(),
	content: text().notNull(),
	priority: text().default('medium'),
	tags: text().array().default([""]),
	isPrivate: boolean("is_private").default(false),
	parentNotification: boolean("parent_notification").default(false),
	followUpRequired: boolean("follow_up_required").default(false),
	followUpDate: timestamp("follow_up_date", { mode: 'string' }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.staffId],
			foreignColumns: [users.id],
			name: "staff_observations_staff_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "staff_observations_student_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const staffStudentAssignments = pgTable("staff_student_assignments", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	staffId: varchar("staff_id").notNull(),
	studentId: varchar("student_id").notNull(),
	assignedBy: varchar("assigned_by").notNull(),
	assignedAt: timestamp("assigned_at", { mode: 'string' }).defaultNow(),
	isActive: boolean("is_active").default(true),
	notes: text(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.staffId],
			foreignColumns: [users.id],
			name: "staff_student_assignments_staff_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "staff_student_assignments_student_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.assignedBy],
			foreignColumns: [users.id],
			name: "staff_student_assignments_assigned_by_users_id_fk"
		}),
]);

export const studentProgressAnalytics = pgTable("student_progress_analytics", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	studentId: varchar("student_id").notNull(),
	analysisDate: timestamp("analysis_date", { mode: 'string' }).defaultNow(),
	cognitiveStrengths: jsonb("cognitive_strengths"),
	improvementAreas: jsonb("improvement_areas"),
	learningVelocity: numeric("learning_velocity", { precision: 5, scale:  2 }),
	engagementScore: numeric("engagement_score", { precision: 3, scale:  2 }),
	riskFactors: jsonb("risk_factors"),
	interventionSuggestions: jsonb("intervention_suggestions"),
	nextMilestones: jsonb("next_milestones"),
	parentReportGenerated: boolean("parent_report_generated").default(false),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "student_progress_analytics_student_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const customQuestionResponses = pgTable("custom_question_responses", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	customQuestionId: varchar("custom_question_id").notNull(),
	studentId: varchar("student_id").notNull(),
	responseText: text("response_text"),
	responseTime: integer("response_time"),
	isCorrect: boolean("is_correct"),
	staffFeedback: text("staff_feedback"),
	score: numeric({ precision: 5, scale:  2 }),
	followUpNeeded: boolean("follow_up_needed").default(false),
	responseMetadata: jsonb("response_metadata"),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "custom_question_responses_student_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.customQuestionId],
			foreignColumns: [customQuestions.id],
			name: "custom_question_responses_custom_question_id_custom_questions_i"
		}).onDelete("cascade"),
]);

export const knowledgeNodes = pgTable("knowledge_nodes", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	title: text().notNull(),
	type: text().notNull(),
	category: text(),
	description: text(),
	masteryLevel: numeric("mastery_level", { precision: 3, scale:  2 }).default('0.00'),
	connections: jsonb().default([]),
	position: jsonb(),
	metadata: jsonb(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "knowledge_nodes_user_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const aiQuestionSessions = pgTable("ai_question_sessions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	staffId: varchar("staff_id").notNull(),
	studentAssessmentData: jsonb("student_assessment_data"),
	aiProviderUsed: text("ai_provider_used"),
	generationParameters: jsonb("generation_parameters"),
	generatedQuestions: jsonb("generated_questions"),
	selectedQuestionIds: text("selected_question_ids").array().default([""]),
	sessionMetadata: jsonb("session_metadata"),
	effectiveness: numeric({ precision: 3, scale:  2 }),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.staffId],
			foreignColumns: [users.id],
			name: "ai_question_sessions_staff_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const customQuestions = pgTable("custom_questions", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	staffId: varchar("staff_id").notNull(),
	studentId: varchar("student_id"),
	title: text().notNull(),
	questionText: text("question_text").notNull(),
	questionType: text("question_type").notNull(),
	options: jsonb(),
	correctAnswer: text("correct_answer"),
	difficultyEstimate: integer("difficulty_estimate"),
	cognitiveDomains: text("cognitive_domains").array().default([""]),
	createdFromAssessmentId: varchar("created_from_assessment_id"),
	aiAssistanceUsed: boolean("ai_assistance_used").default(false),
	aiGenerationPrompt: text("ai_generation_prompt"),
	status: text().default('draft'),
	tags: text().array().default([""]),
	metadata: jsonb(),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.staffId],
			foreignColumns: [users.id],
			name: "custom_questions_staff_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "custom_questions_student_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.createdFromAssessmentId],
			foreignColumns: [assessments.id],
			name: "custom_questions_created_from_assessment_id_assessments_id_fk"
		}),
]);

export const questionAssignments = pgTable("question_assignments", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	customQuestionId: varchar("custom_question_id").notNull(),
	studentId: varchar("student_id").notNull(),
	staffId: varchar("staff_id").notNull(),
	assignedAt: timestamp("assigned_at", { mode: 'string' }).defaultNow(),
	dueDate: timestamp("due_date", { mode: 'string' }),
	priority: text().default('medium'),
	instructions: text(),
	status: text().default('assigned'),
	completedAt: timestamp("completed_at", { mode: 'string' }),
	assignmentMetadata: jsonb("assignment_metadata"),
}, (table) => [
	foreignKey({
			columns: [table.customQuestionId],
			foreignColumns: [customQuestions.id],
			name: "question_assignments_custom_question_id_custom_questions_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.studentId],
			foreignColumns: [users.id],
			name: "question_assignments_student_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.staffId],
			foreignColumns: [users.id],
			name: "question_assignments_staff_id_users_id_fk"
		}).onDelete("cascade"),
]);

export const knowledgeConnections = pgTable("knowledge_connections", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	fromNodeId: varchar("from_node_id").notNull(),
	toNodeId: varchar("to_node_id").notNull(),
	connectionType: text("connection_type").default('prerequisite'),
	strength: numeric({ precision: 3, scale:  2 }).default('1.00'),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "knowledge_connections_user_id_users_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.fromNodeId],
			foreignColumns: [knowledgeNodes.id],
			name: "knowledge_connections_from_node_id_knowledge_nodes_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.toNodeId],
			foreignColumns: [knowledgeNodes.id],
			name: "knowledge_connections_to_node_id_knowledge_nodes_id_fk"
		}).onDelete("cascade"),
]);

export const knowledgeVisualizations = pgTable("knowledge_visualizations", {
	id: varchar().default(gen_random_uuid()).primaryKey().notNull(),
	userId: varchar("user_id").notNull(),
	name: text().notNull(),
	type: text().notNull(),
	config: jsonb(),
	nodes: jsonb(),
	connections: jsonb(),
	layout: jsonb(),
	isPublic: boolean("is_public").default(false),
	createdAt: timestamp("created_at", { mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { mode: 'string' }).defaultNow(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "knowledge_visualizations_user_id_users_id_fk"
		}).onDelete("cascade"),
]);
