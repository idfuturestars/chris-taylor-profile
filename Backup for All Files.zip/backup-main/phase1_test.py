#!/usr/bin/env python3
"""
StarGuide Phase 1 Advanced AI Features Test Suite
This script specifically tests the Phase 1 Advanced AI features of the StarGuide educational platform.
"""

import requests
import json
import time
import random
import uuid
import os
import base64
import io
from typing import Dict, List, Optional, Any

# Configuration
# BACKEND_URL = "https://d73ba72f-94e1-44fd-965d-f5b7e2b9e939.preview.emergentagent.com/api"
# For local testing
BACKEND_URL = "http://0.0.0.0:8001/api"
TEST_USER = {
    "username": f"testuser_{uuid.uuid4().hex[:8]}",
    "email": f"testuser_{uuid.uuid4().hex[:8]}@example.com",
    "password": "TestPassword123!",
    "full_name": "Test User"
}

# Test results tracking
test_results = {
    "total": 0,
    "passed": 0,
    "failed": 0,
    "skipped": 0,
    "details": []
}

# Test token
token = None
user_id = None

def log_test(name: str, passed: bool, details: str = ""):
    """Log test result"""
    status = "PASSED" if passed else "FAILED"
    print(f"[{status}] {name}")
    if details:
        print(f"  Details: {details}")
    
    test_results["total"] += 1
    if passed:
        test_results["passed"] += 1
    else:
        test_results["failed"] += 1
    
    test_results["details"].append({
        "name": name,
        "status": status,
        "details": details
    })

def make_request(method: str, endpoint: str, data: Optional[Dict] = None, 
                token: Optional[str] = None, expected_status: int = 200,
                files: Optional[Dict] = None) -> Dict:
    """Make an API request with proper error handling"""
    url = f"{BACKEND_URL}{endpoint}"
    headers = {}
    
    if token:
        headers["Authorization"] = f"Bearer {token}"
    
    try:
        if method.lower() == "get":
            response = requests.get(url, headers=headers)
        elif method.lower() == "post":
            if files:
                response = requests.post(url, files=files, headers=headers)
            else:
                response = requests.post(url, json=data, headers=headers)
        elif method.lower() == "put":
            response = requests.put(url, json=data, headers=headers)
        elif method.lower() == "delete":
            response = requests.delete(url, headers=headers)
        else:
            return {"error": f"Unsupported method: {method}"}
        
        # For this test, we want to check if the endpoint exists, not necessarily if it returns the expected status
        if response.status_code == 404:
            return {
                "error": f"Endpoint not found (404)",
                "response": response.text,
                "status_code": response.status_code
            }
        
        try:
            return response.json()
        except:
            return {"response": response.text, "status_code": response.status_code}
            
    except Exception as e:
        return {"error": str(e)}

def test_user_registration() -> Optional[str]:
    """Test user registration endpoint"""
    global user_id
    
    response = make_request("post", "/auth/register", TEST_USER)
    
    if "error" in response:
        log_test("User Registration", False, str(response))
        return None
    
    passed = "access_token" in response and "user" in response
    if passed:
        log_test("User Registration", passed, f"Created user: {response['user']['username']}")
        user_id = response['user']['id']
        return response["access_token"]
    else:
        log_test("User Registration", False, f"Failed to create user: {response}")
        return None

def test_user_login() -> Optional[str]:
    """Test user login endpoint"""
    global user_id
    
    response = make_request("post", "/auth/login", {"email": TEST_USER["email"], "password": TEST_USER["password"]})
    
    if "error" in response:
        log_test("User Login", False, str(response))
        return None
    
    passed = "access_token" in response and "user" in response
    if passed:
        log_test("User Login", passed, f"Logged in as: {response['user']['username']}")
        user_id = response['user']['id']
        return response["access_token"]
    else:
        log_test("User Login", False, f"Failed to login: {response}")
        return None

def test_enhanced_ai_chat(token: str):
    """Test enhanced AI chat with emotional intelligence"""
    message = "I'm feeling a bit frustrated with this calculus problem. Can you help me understand derivatives better?"
    emotional_context = "frustrated"
    learning_style = "visual"
    
    endpoint = f"/ai/enhanced-chat?message={message}&emotional_context={emotional_context}&learning_style={learning_style}"
    
    response = make_request("post", endpoint, {}, token)
    
    if "error" in response and "404" in response.get("error", ""):
        log_test("Enhanced AI Chat", False, "Endpoint not found (404)")
        return
    
    passed = "response" in response and "emotional_state_detected" in response
    log_test("Enhanced AI Chat", passed, 
            f"AI response received with emotional intelligence, length: {len(response.get('response', ''))}")

def test_personalized_learning_path(token: str):
    """Test generating a personalized learning path"""
    data = {
        "subject": "mathematics",
        "learning_goals": ["Master calculus", "Understand linear algebra"],
        "target_completion_weeks": 8,
        "preferred_learning_style": "visual"
    }
    
    response = make_request("post", "/ai/personalized-learning-path", data, token)
    
    if "error" in response and "404" in response.get("error", ""):
        log_test("Personalized Learning Path", False, "Endpoint not found (404)")
        return
    
    passed = "learning_path_id" in response and "personalized_curriculum" in response
    log_test("Personalized Learning Path", passed, 
            f"Learning path generated with {len(response.get('personalized_curriculum', []))} modules")

def test_learning_style_assessment(token: str):
    """Test learning style assessment"""
    response = make_request("post", "/ai/learning-style-assessment", {}, token)
    
    if "error" in response and "404" in response.get("error", ""):
        log_test("Learning Style Assessment", False, "Endpoint not found (404)")
        return
    
    passed = "primary_learning_style" in response and "recommendations" in response
    log_test("Learning Style Assessment", passed, 
            f"Learning style detected: {response.get('primary_learning_style', 'unknown')}")

def test_emotional_analytics(token: str, user_id: str):
    """Test emotional analytics"""
    response = make_request("get", f"/ai/emotional-analytics/{user_id}?days=30", token=token)
    
    if "error" in response and "404" in response.get("error", ""):
        log_test("Emotional Analytics", False, "Endpoint not found (404)")
        return
    
    passed = "emotion_distribution" in response and "insights" in response
    log_test("Emotional Analytics", passed, 
            f"Emotional analytics generated with {len(response.get('insights', []))} insights")

def test_voice_to_text(token: str):
    """Test voice-to-text processing capabilities"""
    # Create a dummy audio file for testing
    dummy_audio_data = b"dummy audio data"
    files = {
        'audio_file': ('test_audio.wav', dummy_audio_data, 'audio/wav')
    }
    
    response = make_request("post", "/ai/voice-to-text", {}, token, files=files)
    
    if "error" in response and "404" in response.get("error", ""):
        log_test("Voice-to-Text Processing", False, "Endpoint not found (404)")
        return
    
    # For this test, we're just checking if the endpoint exists and responds
    # We don't expect it to process our dummy data successfully
    passed = "status_code" in response and response["status_code"] != 404
    log_test("Voice-to-Text Processing", passed, 
            "Endpoint exists and responds (may return error due to invalid audio data)")

def run_phase1_tests():
    """Run all Phase 1 Advanced AI features tests"""
    global token, user_id
    
    print("\n===== STARGUIDE PHASE 1 ADVANCED AI FEATURES TEST SUITE =====\n")
    
    # User authentication
    print("\n----- Authentication -----")
    token = test_user_registration()
    if not token:
        token = test_user_login()
    
    # For testing purposes, if we can't authenticate, we'll create a dummy token
    if not token:
        print("Warning: Failed to authenticate. Using dummy token for testing.")
        token = "dummy_token"
        user_id = "dummy_user_id"
    
    # Phase 1 Advanced AI features tests
    print("\n----- Phase 1: Advanced AI Features Tests -----")
    test_enhanced_ai_chat(token)
    test_personalized_learning_path(token)
    test_learning_style_assessment(token)
    test_emotional_analytics(token, user_id if user_id else "dummy_user_id")
    test_voice_to_text(token)
    
    # Print summary
    print("\n===== TEST SUMMARY =====")
    print(f"Total tests: {test_results['total']}")
    print(f"Passed: {test_results['passed']}")
    print(f"Failed: {test_results['failed']}")
    print(f"Success rate: {(test_results['passed'] / test_results['total'] * 100) if test_results['total'] > 0 else 0:.1f}%")
    
    # Print failed tests
    if test_results["failed"] > 0:
        print("\nFailed tests:")
        for test in test_results["details"]:
            if test["status"] == "FAILED":
                print(f"- {test['name']}: {test['details']}")
    
    # Print Phase 1 success rate
    phase1_tests = [test for test in test_results["details"] if test.get("name") in [
        "Enhanced AI Chat", "Personalized Learning Path", "Learning Style Assessment", 
        "Emotional Analytics", "Voice-to-Text Processing"
    ]]
    
    phase1_total = len(phase1_tests)
    phase1_passed = sum(1 for test in phase1_tests if test["status"] == "PASSED")
    
    print(f"\nPhase 1 Advanced AI Features success rate: {(phase1_passed / phase1_total * 100) if phase1_total > 0 else 0:.1f}%")
    
    # Detailed analysis of Phase 1 features
    print("\nPhase 1 Advanced AI Features Analysis:")
    for feature in ["Enhanced AI Chat", "Personalized Learning Path", "Learning Style Assessment", 
                   "Emotional Analytics", "Voice-to-Text Processing"]:
        test = next((t for t in test_results["details"] if t["name"] == feature), None)
        if test:
            print(f"- {feature}: {test['status']}")

if __name__ == "__main__":
    run_phase1_tests()