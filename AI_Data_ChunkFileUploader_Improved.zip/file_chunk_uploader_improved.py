
import os
import platform
import subprocess

def split_into_chunks(text, max_tokens=3000):
    words = text.split()
    chunks = []
    current = []

    for word in words:
        current.append(word)
        if len(current) >= max_tokens:
            chunks.append(" ".join(current))
            current = []
    if current:
        chunks.append(" ".join(current))
    return chunks

# Detect the directory of this script
base_dir = os.path.dirname(os.path.abspath(__file__))

# Read prepared_data.txt from same folder
input_file = os.path.join(base_dir, "prepared_data.txt")
if not os.path.exists(input_file):
    print("❗ ERROR: prepared_data.txt not found in the same folder.")
    exit(1)

with open(input_file, "r", encoding="utf-8") as file:
    full_text = file.read()

chunks = split_into_chunks(full_text)

# Create output folder
output_folder = os.path.join(base_dir, "chunks_output")
os.makedirs(output_folder, exist_ok=True)

# Save each chunk
for idx, chunk in enumerate(chunks):
    chunk_filename = os.path.join(output_folder, f"chunk_{idx + 1}.txt")
    with open(chunk_filename, "w", encoding="utf-8") as chunk_file:
        chunk_file.write(chunk)

print(f"✅ Done! {len(chunks)} chunk files saved in '{output_folder}' folder.")

# Automatically open the output folder
def open_folder(path):
    if platform.system() == "Darwin":  # macOS
        subprocess.run(["open", path])
    elif platform.system() == "Windows":
        subprocess.run(["explorer", path])
    elif platform.system() == "Linux":
        subprocess.run(["xdg-open", path])

open_folder(output_folder)
