
FILE-BASED CONTEXT UPLOADER TOOL (IMPROVED VERSION)

✅ How to use:

1. Place 'prepared_data.txt' in this folder.
2. Run 'file_chunk_uploader_improved.py' (double click or run via terminal).
3. It will automatically create a 'chunks_output' folder in the SAME location.
4. It will AUTO OPEN the folder so you can instantly see the chunk files.

Each file (chunk_1.txt, chunk_2.txt, etc) will be small enough for Gemini and Claude uploads.

Enjoy effortless uploading! 🚀
