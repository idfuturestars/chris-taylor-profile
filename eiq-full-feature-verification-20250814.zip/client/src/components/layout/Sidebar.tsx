import { 
  Calculator, 
  Brain, 
  Upload, 
  Sprout, 
  Rocket, 
  Crown, 
  BarChart3, 
  Clock,
  GraduationCap, 
  Briefcase,
  Users,
  MessageSquare,
  Zap,
  Settings,
  Award,
  Lightbulb
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export default function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const mainNavigation = [
    { id: "dashboard", icon: BarChart3, label: "Dashboard" },
    { id: "baseline-test", icon: Rocket, label: "Quick Test" },
    { id: "comprehensive-test", icon: Brain, label: "Full Test" },
    { id: "talent-match", icon: Calculator, label: "My Scores" },
    { id: "achievements", icon: Award, label: "Achievements" },
    { id: "hint-demo", icon: Lightbulb, label: "AI Hints" },
    { id: "ml-insights", icon: BarChart3, label: "Global" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  const eiqDomains = [
    { icon: Brain, label: "Logical Reasoning", href: "#", score: 142 },
    { icon: Zap, label: "Working Memory", href: "#", score: 156 },
    { icon: MessageSquare, label: "Verbal Comprehension", href: "#", score: 134 },
    { icon: Calculator, label: "Perceptual Reasoning", href: "#", score: 148 },
    { icon: Clock, label: "Processing Speed", href: "#", score: 163 },
    { icon: Users, label: "Emotional Intelligence", href: "#", score: 145 },
  ];

  const scoreTargets = [
    { icon: Sprout, label: "Good (500-600)", href: "#", color: "text-green-500" },
    { icon: Rocket, label: "Excellent (600-700)", href: "#", color: "text-primary" },
    { icon: Crown, label: "Elite (700+)", href: "#", color: "text-purple-500" },
  ];

  return (
    <aside className="hidden lg:block w-64 bg-secondary border-r border-border">
      <div className="p-6">
        <div className="space-y-6">
          {/* Main Navigation */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Main
            </h3>
            <nav className="space-y-2">
              {mainNavigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "flex items-center space-x-3 rounded-lg px-3 py-2 transition-colors w-full text-left",
                    activeSection === item.id
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Assessment Domains */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              EiQ Domains
            </h3>
            <nav className="space-y-2">
              {eiqDomains.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg px-3 py-2 transition-colors"
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                  <span className="ml-auto text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                    {item.score}
                  </span>
                </a>
              ))}
            </nav>
          </div>

          {/* Score Ranges */}
          <div>
            <nav className="space-y-2">
              {scoreTargets.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg px-3 py-2 transition-colors"
                >
                  <item.icon className={cn("w-5 h-5", item.color)} />
                  <span>{item.label}</span>
                </a>
              ))}
            </nav>
          </div>
        </div>
      </div>
    </aside>
  );
}
