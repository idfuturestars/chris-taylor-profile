import { eq, and, sql } from "drizzle-orm";
import { db } from "./db";
import { 
  achievementBadges, 
  userBadges, 
  achievementProgress,
  users,
  assessments,
  type AchievementBadge,
  type UserBadge,
  type AchievementProgress as AchievementProgressType
} from "@shared/schema";

export interface BadgeCriteria {
  type: 'assessment' | 'learning' | 'streak' | 'ai' | 'social' | 'mastery';
  metric: string;
  threshold: number;
  timeframe?: 'daily' | 'weekly' | 'monthly' | 'all_time';
  conditions?: Record<string, any>;
}

export interface BadgeProgress {
  badgeId: string;
  currentValue: number;
  targetValue: number;
  percentage: number;
  isComplete: boolean;
}

export class AchievementEngine {
  
  // Initialize default badges system
  async initializeDefaultBadges(): Promise<void> {
    const defaultBadges = [
      // Assessment Badges
      {
        name: "first_assessment",
        category: "assessment",
        tier: "bronze",
        title: "First Steps",
        description: "Complete your first assessment",
        iconPath: "/badges/first-steps.svg",
        colorScheme: "bronze",
        criteria: { type: 'assessment', metric: 'completed', threshold: 1 },
        points: 10,
        rarity: "common"
      },
      {
        name: "assessment_streak_7",
        category: "streak",
        tier: "silver", 
        title: "Week Warrior",
        description: "Complete assessments for 7 consecutive days",
        iconPath: "/badges/week-warrior.svg",
        colorScheme: "silver",
        criteria: { type: 'streak', metric: 'daily_assessment', threshold: 7, timeframe: 'daily' },
        points: 50,
        rarity: "uncommon"
      },
      {
        name: "high_scorer",
        category: "assessment",
        tier: "gold",
        title: "High Achiever",
        description: "Score above 120 EiQ in any assessment",
        iconPath: "/badges/high-achiever.svg",
        colorScheme: "gold",
        criteria: { type: 'assessment', metric: 'max_score', threshold: 120 },
        points: 100,
        rarity: "rare"
      },
      {
        name: "perfect_score",
        category: "mastery",
        tier: "platinum",
        title: "Perfectionist",
        description: "Achieve a perfect score in any domain",
        iconPath: "/badges/perfectionist.svg",
        colorScheme: "platinum",
        criteria: { type: 'mastery', metric: 'perfect_domain', threshold: 1 },
        points: 200,
        rarity: "epic"
      },
      
      // Learning Badges
      {
        name: "fast_learner",
        category: "learning",
        tier: "silver",
        title: "Speed Demon",
        description: "Complete 10 questions in under 30 seconds each",
        iconPath: "/badges/speed-demon.svg",
        colorScheme: "silver",
        criteria: { type: 'learning', metric: 'fast_responses', threshold: 10, conditions: { max_time: 30 } },
        points: 75,
        rarity: "uncommon"
      },
      
      // AI Interaction Badges  
      {
        name: "ai_mentor_novice",
        category: "ai",
        tier: "bronze",
        title: "AI Assistant",
        description: "Have 10 conversations with AI mentor",
        iconPath: "/badges/ai-assistant.svg",
        colorScheme: "bronze",
        criteria: { type: 'ai', metric: 'conversations', threshold: 10 },
        points: 25,
        rarity: "common"
      },
      {
        name: "ai_mentor_expert",
        category: "ai",
        tier: "gold",
        title: "AI Whisperer",
        description: "Complete 100 AI-guided learning sessions",
        iconPath: "/badges/ai-whisperer.svg",
        colorScheme: "gold",
        criteria: { type: 'ai', metric: 'sessions', threshold: 100 },
        points: 150,
        rarity: "rare"
      },
      
      // Social Badges
      {
        name: "team_player",
        category: "social",
        tier: "silver",
        title: "Team Player",
        description: "Join 3 study groups",
        iconPath: "/badges/team-player.svg",
        colorScheme: "silver",
        criteria: { type: 'social', metric: 'study_groups', threshold: 3 },
        points: 40,
        rarity: "uncommon"
      },
      
      // Mastery Badges
      {
        name: "domain_master",
        category: "mastery",
        tier: "diamond",
        title: "Domain Master",
        description: "Master all 6 cognitive domains",
        iconPath: "/badges/domain-master.svg",
        colorScheme: "rainbow",
        criteria: { type: 'mastery', metric: 'domains_mastered', threshold: 6 },
        points: 500,
        rarity: "legendary"
      }
    ];

    // Insert badges that don't already exist
    for (const badge of defaultBadges) {
      const existing = await db.select().from(achievementBadges).where(eq(achievementBadges.name, badge.name)).limit(1);
      if (existing.length === 0) {
        await db.insert(achievementBadges).values(badge);
      }
    }
  }

  // Check and award badges for a user
  async checkAndAwardBadges(userId: string): Promise<UserBadge[]> {
    const awardedBadges: UserBadge[] = [];
    
    // Get all active badges
    const badges = await db.select().from(achievementBadges).where(eq(achievementBadges.isActive, true));
    
    // Get user's existing badges
    const existingBadges = await db.select().from(userBadges).where(eq(userBadges.userId, userId));
    const existingBadgeIds = new Set(existingBadges.map(b => b.badgeId));
    
    for (const badge of badges) {
      // Skip if user already has this badge
      if (existingBadgeIds.has(badge.id)) continue;
      
      const criteria = badge.criteria as BadgeCriteria;
      const isEarned = await this.checkBadgeCriteria(userId, criteria);
      
      if (isEarned) {
        const userBadge = await db.insert(userBadges).values({
          userId,
          badgeId: badge.id,
          isDisplayed: true,
          notificationSent: false
        }).returning();
        
        if (userBadge.length > 0) {
          awardedBadges.push(userBadge[0]);
        }
      }
    }
    
    return awardedBadges;
  }

  // Check if user meets badge criteria
  private async checkBadgeCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    try {
      switch (criteria.type) {
        case 'assessment':
          return await this.checkAssessmentCriteria(userId, criteria);
        case 'learning':
          return await this.checkLearningCriteria(userId, criteria);
        case 'streak':
          return await this.checkStreakCriteria(userId, criteria);
        case 'ai':
          return await this.checkAiCriteria(userId, criteria);
        case 'social':
          return await this.checkSocialCriteria(userId, criteria);
        case 'mastery':
          return await this.checkMasteryCriteria(userId, criteria);
        default:
          return false;
      }
    } catch (error) {
      console.error('Error checking badge criteria:', error);
      return false;
    }
  }

  private async checkAssessmentCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    switch (criteria.metric) {
      case 'completed':
        const completed = await db.select().from(assessments)
          .where(and(eq(assessments.userId, userId), eq(assessments.completed, true)));
        return completed.length >= criteria.threshold;
        
      case 'max_score':
        const maxScoreResult = await db.select({ maxScore: sql`MAX(${assessments.score})` })
          .from(assessments)
          .where(eq(assessments.userId, userId));
        const maxScore = Number(maxScoreResult[0]?.maxScore || 0);
        return maxScore >= criteria.threshold;
        
      default:
        return false;
    }
  }

  private async checkLearningCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    // Implementation would check learning-specific metrics
    // This is a simplified version
    return false;
  }

  private async checkStreakCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    // Implementation would check streak data from user profile or dedicated tracking
    const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (user.length === 0) return false;
    
    return (user[0].learningStreak || 0) >= criteria.threshold;
  }

  private async checkAiCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (user.length === 0) return false;
    
    switch (criteria.metric) {
      case 'conversations':
      case 'sessions':
        return (user[0].aiInteractions || 0) >= criteria.threshold;
      default:
        return false;
    }
  }

  private async checkSocialCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    // Implementation would check social engagement metrics
    return false;
  }

  private async checkMasteryCriteria(userId: string, criteria: BadgeCriteria): Promise<boolean> {
    // Implementation would check mastery-specific achievements
    return false;
  }

  // Get user's badge progress
  async getBadgeProgress(userId: string): Promise<BadgeProgress[]> {
    const badges = await db.select().from(achievementBadges).where(eq(achievementBadges.isActive, true));
    const progress: BadgeProgress[] = [];
    
    for (const badge of badges) {
      const criteria = badge.criteria as BadgeCriteria;
      const currentValue = await this.getCurrentProgress(userId, criteria);
      const targetValue = criteria.threshold;
      const percentage = Math.min(100, (currentValue / targetValue) * 100);
      const isComplete = currentValue >= targetValue;
      
      progress.push({
        badgeId: badge.id,
        currentValue,
        targetValue,
        percentage,
        isComplete
      });
    }
    
    return progress;
  }

  private async getCurrentProgress(userId: string, criteria: BadgeCriteria): Promise<number> {
    // Get current progress value for specific criteria
    switch (criteria.type) {
      case 'assessment':
        if (criteria.metric === 'completed') {
          const completed = await db.select().from(assessments)
            .where(and(eq(assessments.userId, userId), eq(assessments.completed, true)));
          return completed.length;
        }
        if (criteria.metric === 'max_score') {
          const maxScoreResult = await db.select({ maxScore: sql`MAX(${assessments.score})` })
            .from(assessments)
            .where(eq(assessments.userId, userId));
          return Number(maxScoreResult[0]?.maxScore || 0);
        }
        break;
        
      case 'streak':
        const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
        return user[0]?.learningStreak || 0;
        
      case 'ai':
        const userAi = await db.select().from(users).where(eq(users.id, userId)).limit(1);
        return userAi[0]?.aiInteractions || 0;
        
      default:
        return 0;
    }
    return 0;
  }

  // Get user's badges with details
  async getUserBadges(userId: string): Promise<(UserBadge & { badge: AchievementBadge })[]> {
    return await db.select({
      id: userBadges.id,
      userId: userBadges.userId,
      badgeId: userBadges.badgeId,
      earnedAt: userBadges.earnedAt,
      progress: userBadges.progress,
      isDisplayed: userBadges.isDisplayed,
      notificationSent: userBadges.notificationSent,
      createdAt: userBadges.createdAt,
      badge: achievementBadges
    })
    .from(userBadges)
    .innerJoin(achievementBadges, eq(userBadges.badgeId, achievementBadges.id))
    .where(eq(userBadges.userId, userId))
    .orderBy(userBadges.earnedAt);
  }

  // Get leaderboard by badge points
  async getBadgeLeaderboard(limit: number = 10): Promise<any[]> {
    const leaderboard = await db.select({
      userId: userBadges.userId,
      totalPoints: sql`SUM(${achievementBadges.points})`.as('totalPoints'),
      badgeCount: sql`COUNT(*)`.as('badgeCount'),
      user: users
    })
    .from(userBadges)
    .innerJoin(achievementBadges, eq(userBadges.badgeId, achievementBadges.id))
    .innerJoin(users, eq(userBadges.userId, users.id))
    .groupBy(userBadges.userId, users.id)
    .orderBy(sql`SUM(${achievementBadges.points}) DESC`)
    .limit(limit);
    
    return leaderboard;
  }

  // Update user progress for specific activity
  async updateUserProgress(userId: string, activity: string, value: number = 1): Promise<void> {
    switch (activity) {
      case 'assessment_completed':
        await db.update(users)
          .set({ 
            assessmentProgress: sql`${users.assessmentProgress} + ${value}`,
            updatedAt: new Date()
          })
          .where(eq(users.id, userId));
        break;
        
      case 'learning_streak':
        await db.update(users)
          .set({ 
            learningStreak: value,
            updatedAt: new Date()
          })
          .where(eq(users.id, userId));
        break;
        
      case 'ai_interaction':
        await db.update(users)
          .set({ 
            aiInteractions: sql`${users.aiInteractions} + ${value}`,
            updatedAt: new Date()
          })
          .where(eq(users.id, userId));
        break;
    }
    
    // Check for new badges after progress update
    await this.checkAndAwardBadges(userId);
  }
}

export const achievementEngine = new AchievementEngine();