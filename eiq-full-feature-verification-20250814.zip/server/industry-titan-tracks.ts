import { storage } from "./storage";

// Industry Titan Learning Tracks Configuration
export interface TitanTrack {
  name: string;
  displayName: string;
  description: string;
  audience: string;
  focus: string;
  ageRange: {
    min: number;
    max: number;
    grades?: string;
  };
  focusAreas: string[];
  learningObjectives: string[];
  prerequisites: string[];
  industryPartners: string[];
}

export const TITAN_TRACKS: TitanTrack[] = [
  {
    name: "JOBS_COOK",
    displayName: "Elementary Academic Foundation",
    description: "Core educational track focusing on essential academic skills, mathematical foundations, and learning fundamentals",
    audience: "Grades 6–8", 
    focus: "Academic foundations, study skills, core subjects",
    ageRange: { min: 11, max: 14, grades: "6-8" },
    focusAreas: [
      "Mathematical Foundations",
      "Reading Comprehension",
      "Scientific Method",
      "Study Skills",
      "Critical Thinking"
    ],
    learningObjectives: [
      "Master core mathematical concepts and problem-solving",
      "Develop strong reading and analytical skills",
      "Learn scientific inquiry and reasoning methods",
      "Build effective study and learning strategies",
      "Strengthen critical thinking across all subjects"
    ],
    prerequisites: [
      "Basic arithmetic proficiency",
      "Reading comprehension at grade level"
    ],
    industryPartners: [
      "Khan Academy",
      "National Education Association",
      "Scholastic Education"
    ]
  },
  {
    name: "PAGE_PICHAI",
    displayName: "Intermediate Academic Development", 
    description: "Advanced middle school and early high school academic track focusing on advanced mathematics and sciences",
    audience: "Grades 8–10",
    focus: "Advanced mathematics, sciences, academic writing",
    ageRange: { min: 13, max: 16, grades: "8-10" },
    focusAreas: [
      "Advanced Algebra",
      "Biology & Chemistry",
      "Academic Writing",
      "Research Methods", 
      "Statistical Analysis"
    ],
    learningObjectives: [
      "Master algebraic concepts and applications", 
      "Understand fundamental scientific principles",
      "Develop advanced writing and communication skills",
      "Learn research and inquiry methods",
      "Analyze and interpret academic data"
    ],
    prerequisites: [
      "Completion of JOBS/COOK track or equivalent",
      "Algebra I proficiency"
    ],
    industryPartners: [
      "College Board",
      "National Science Teachers Association",
      "Educational Testing Service"
    ]
  },
  {
    name: "GATES_BALLMER",
    displayName: "Advanced High School Preparation",
    description: "College preparatory track focusing on advanced mathematics, sciences, and academic research skills",
    audience: "Grades 10–12", 
    focus: "College preparation, advanced academics, research skills",
    ageRange: { min: 15, max: 18, grades: "10-12" },
    focusAreas: [
      "Calculus and Advanced Mathematics",
      "Physics and Chemistry",
      "Research Methodology",
      "College Essay Writing",
      "Academic Presentation Skills"
    ],
    learningObjectives: [
      "Master calculus and advanced mathematical concepts",
      "Understand advanced physics and chemistry principles",
      "Conduct independent academic research projects",
      "Develop strong college-level writing skills",
      "Build presentation and communication abilities"
    ],
    prerequisites: [
      "Completion of PAGE/PICHAI track or equivalent",
      "Pre-calculus proficiency"
    ],
    industryPartners: [
      "College Board Advanced Placement",
      "International Baccalaureate Organization", 
      "National Merit Scholarship Corporation"
    ]
  },
  {
    name: "ZUCK_HUANG",
    displayName: "College Academic Excellence",
    description: "Higher education track focusing on university-level academics and advanced subject mastery",
    audience: "Ages 16–25",
    focus: "University academics, advanced subjects, academic excellence",
    ageRange: { min: 16, max: 25 },
    focusAreas: [
      "Advanced Mathematics and Statistics",
      "Scientific Research Methods",
      "Interdisciplinary Studies",
      "Academic Excellence Strategies",
      "Higher Education Planning"
    ],
    learningObjectives: [
      "Master university-level mathematical and statistical concepts",
      "Conduct advanced academic research and analysis",
      "Integrate knowledge across multiple academic disciplines",
      "Develop strategies for academic excellence and achievement",
      "Plan and execute successful higher education pathways"
    ],
    prerequisites: [
      "Completion of GATES/BALLMER track or equivalent experience",
      "Strong academic foundation in core subjects"
    ],
    industryPartners: [
      "Harvard University",
      "MIT OpenCourseWare",
      "Stanford University",
      "Princeton Review"
    ]
  },
  {
    name: "ELLISON_CATZ",
    displayName: "Adult Lifelong Learning",
    description: "Continuing education track for adult learners pursuing academic advancement and professional development",
    audience: "Ages 26–44",
    focus: "Continuing education, advanced degrees, lifelong learning",
    ageRange: { min: 26, max: 44 },
    focusAreas: [
      "Graduate-Level Studies",
      "Professional Certifications",
      "Academic Research Skills",
      "Advanced Subject Mastery",
      "Educational Leadership"
    ],
    learningObjectives: [
      "Complete graduate-level academic coursework",
      "Earn professional certifications and credentials", 
      "Develop advanced research and analytical skills",
      "Achieve mastery in specialized academic fields",
      "Lead educational initiatives and academic programs"
    ],
    prerequisites: [
      "Bachelor's degree or equivalent academic experience",
      "Interest in advanced academic study"
    ],
    industryPartners: [
      "Graduate School Alliance",
      "Professional Certification Board",
      "Continuing Education Council",
      "Adult Learning Institute"
    ]
  },
  {
    name: "BUFFET_APFEL",
    displayName: "Senior Academic Enrichment",
    description: "Lifelong learning track for senior learners focusing on intellectual enrichment and wisdom sharing",
    audience: "Ages 60+",
    focus: "Academic enrichment, wisdom sharing, intellectual growth",
    ageRange: { min: 60, max: 100 },
    focusAreas: [
      "Intellectual Enrichment",
      "Academic Mentorship",
      "Knowledge Preservation",
      "Educational Technology",
      "Wisdom Sharing"
    ],
    learningObjectives: [
      "Continue intellectual growth and academic exploration",
      "Mentor younger learners and share educational experience",
      "Preserve and document knowledge for future generations",
      "Adapt to new educational technologies and methods",
      "Create educational legacy through teaching and mentorship"
    ],
    prerequisites: [
      "Extensive life learning experience",
      "Interest in educational mentorship and teaching"
    ],
    industryPartners: [
      "Senior Learning Institute",
      "Educational Mentorship Alliance",
      "Lifelong Learning Foundation",
      "Academic Wisdom Council"
    ]
  }
];

// Track Assignment Logic
export function assignTrackByAge(age: number, gradeLevel?: string): TitanTrack {
  // Special handling for grade-based assignment for younger learners
  if (gradeLevel) {
    const grade = parseInt(gradeLevel.replace(/[^0-9]/g, ''));
    
    if (grade >= 6 && grade <= 8) {
      return TITAN_TRACKS.find(t => t.name === "JOBS_COOK")!;
    }
    if (grade >= 8 && grade <= 10) {
      return TITAN_TRACKS.find(t => t.name === "PAGE_PICHAI")!;
    }
    if (grade >= 10 && grade <= 12) {
      return TITAN_TRACKS.find(t => t.name === "GATES_BALLMER")!;
    }
  }
  
  // Age-based assignment
  for (const track of TITAN_TRACKS) {
    if (age >= track.ageRange.min && age <= track.ageRange.max) {
      return track;
    }
  }
  
  // Default fallback
  return TITAN_TRACKS[0]; // JOBS_COOK as default
}

// Initialize tracks in database
export async function initializeTitanTracks() {
  try {
    console.log('[TITAN TRACKS] Initializing industry titan tracks...');
    
    for (const track of TITAN_TRACKS) {
      await storage.upsertIndustryTrack({
        name: track.name,
        displayName: track.displayName,
        description: track.description,
        focusAreas: track.focusAreas,
        ageRanges: {
          min: track.ageRange.min,
          max: track.ageRange.max,
          grades: track.ageRange.grades,
          audience: track.audience
        },
        prerequisites: track.prerequisites,
        learningObjectives: track.learningObjectives,
        industryPartners: track.industryPartners,
        isActive: true
      });
    }
    
    console.log('[TITAN TRACKS] Successfully initialized all titan tracks');
  } catch (error) {
    console.error('[TITAN TRACKS] Error initializing tracks:', error);
  }
}

// Get user's assigned track
export async function getUserAssignedTrack(userId: string, age?: number, gradeLevel?: string) {
  try {
    // Check if user already has a track assigned
    const existingPathway = await storage.getUserLearningPathway(userId);
    if (existingPathway && existingPathway.trackId) {
      return await storage.getIndustryTrack(existingPathway.trackId);
    }
    
    // Assign new track based on age/grade
    if (age || gradeLevel) {
      const recommendedTrack = assignTrackByAge(age || 12, gradeLevel);
      
      // Create learning pathway for the user
      const pathway = await storage.createLearningPathway({
        userId,
        trackId: recommendedTrack.name,
        pathwayType: 'foundation',
        progressMap: {},
        isActive: true
      });
      
      return recommendedTrack;
    }
    
    return null;
  } catch (error) {
    console.error('[TITAN TRACKS] Error getting user track:', error);
    return null;
  }
}

export default {
  TITAN_TRACKS,
  assignTrackByAge,
  initializeTitanTracks,
  getUserAssignedTrack
};