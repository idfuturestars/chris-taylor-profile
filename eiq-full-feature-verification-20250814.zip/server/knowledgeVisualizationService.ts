import { storage } from "./storage";
import type { KnowledgeNode, KnowledgeConnection, KnowledgeVisualization, InsertKnowledgeNode, InsertKnowledgeConnection, InsertKnowledgeVisualization } from "@shared/schema";

interface KnowledgeGraphLayout {
  nodes: Array<{
    id: string;
    x: number;
    y: number;
    size: number;
    color: string;
  }>;
  connections: Array<{
    from: string;
    to: string;
    weight: number;
    type: string;
  }>;
}

interface VisualizationConfig {
  layout: 'force-directed' | 'hierarchical' | 'circular' | 'grid';
  showLabels: boolean;
  nodeSize: 'mastery' | 'connections' | 'uniform';
  colorScheme: 'category' | 'mastery' | 'type';
  animations: boolean;
  clustering: boolean;
}

export class KnowledgeVisualizationService {
  
  // Generate knowledge graph from user's assessment and learning data
  async generateKnowledgeGraph(userId: string): Promise<KnowledgeGraphLayout> {
    try {
      // Get user's assessment data and learning progress
      const user = await storage.getUser(userId);
      if (!user) throw new Error('User not found');

      // Fetch assessment responses to understand knowledge areas
      const assessments = await storage.getAssessmentsByUser(userId);
      const skillRecommendations = await storage.getSkillRecommendationsByUser(userId);

      // Extract knowledge domains from assessments and skills
      const knowledgeDomains = this.extractKnowledgeDomains(assessments, skillRecommendations);
      
      // Create knowledge nodes based on domains
      const nodes = await this.createKnowledgeNodes(userId, knowledgeDomains);
      
      // Establish connections between nodes based on prerequisites and relationships
      const connections = await this.createKnowledgeConnections(userId, nodes);
      
      // Apply force-directed layout algorithm
      const layout = this.applyForceDirectedLayout(nodes, connections);
      
      return layout;
    } catch (error) {
      console.error('[KNOWLEDGE VIZ] Error generating knowledge graph:', error);
      throw error;
    }
  }

  private extractKnowledgeDomains(assessments: any[], skillRecommendations: any[]): Array<{
    title: string;
    type: 'concept' | 'skill' | 'topic' | 'domain';
    category: string;
    masteryLevel: number;
    description: string;
  }> {
    const domains = [];

    // Core cognitive domains
    domains.push(
      { title: 'Mathematical Reasoning', type: 'domain' as const, category: 'mathematics', masteryLevel: 0.7, description: 'Core mathematical problem-solving skills' },
      { title: 'Logical Analysis', type: 'domain' as const, category: 'logic', masteryLevel: 0.6, description: 'Logical reasoning and analytical thinking' },
      { title: 'Pattern Recognition', type: 'concept' as const, category: 'cognition', masteryLevel: 0.8, description: 'Ability to identify patterns and sequences' },
      { title: 'Abstract Thinking', type: 'concept' as const, category: 'cognition', masteryLevel: 0.5, description: 'Abstract conceptual reasoning' },
      { title: 'Problem Solving', type: 'skill' as const, category: 'general', masteryLevel: 0.75, description: 'General problem-solving methodology' }
    );

    // Add skills from recommendations
    skillRecommendations.forEach((skill: any) => {
      domains.push({
        title: skill.skillName,
        type: 'skill' as const,
        category: skill.skillCategory,
        masteryLevel: this.convertLevelToScore(skill.currentLevel),
        description: skill.aiReasoning || `Recommended skill: ${skill.skillName}`
      });
    });

    return domains;
  }

  private convertLevelToScore(level: string): number {
    switch (level) {
      case 'beginner': return 0.25;
      case 'intermediate': return 0.5;
      case 'advanced': return 0.75;
      case 'expert': return 1.0;
      default: return 0.0;
    }
  }

  private async createKnowledgeNodes(userId: string, domains: any[]): Promise<KnowledgeNode[]> {
    const nodes: InsertKnowledgeNode[] = domains.map(domain => ({
      userId,
      title: domain.title,
      type: domain.type,
      category: domain.category,
      description: domain.description,
      masteryLevel: domain.masteryLevel.toString(),
      connections: [],
      position: { x: Math.random() * 800, y: Math.random() * 600 },
      metadata: { 
        strength: domain.masteryLevel,
        importance: domain.masteryLevel > 0.7 ? 'high' : domain.masteryLevel > 0.4 ? 'medium' : 'low'
      }
    }));

    // Store nodes in database
    const createdNodes = [];
    for (const node of nodes) {
      const created = await storage.createKnowledgeNode(node);
      createdNodes.push(created);
    }

    return createdNodes;
  }

  private async createKnowledgeConnections(userId: string, nodes: KnowledgeNode[]): Promise<KnowledgeConnection[]> {
    const connections: InsertKnowledgeConnection[] = [];
    
    // Create prerequisite relationships
    const mathReasoning = nodes.find(n => n.title === 'Mathematical Reasoning');
    const logicalAnalysis = nodes.find(n => n.title === 'Logical Analysis');
    const patternRecognition = nodes.find(n => n.title === 'Pattern Recognition');
    const abstractThinking = nodes.find(n => n.title === 'Abstract Thinking');
    const problemSolving = nodes.find(n => n.title === 'Problem Solving');

    if (mathReasoning && logicalAnalysis) {
      connections.push({
        userId,
        fromNodeId: logicalAnalysis.id,
        toNodeId: mathReasoning.id,
        connectionType: 'prerequisite',
        strength: '0.8'
      });
    }

    if (patternRecognition && abstractThinking) {
      connections.push({
        userId,
        fromNodeId: patternRecognition.id,
        toNodeId: abstractThinking.id,
        connectionType: 'prerequisite',
        strength: '0.7'
      });
    }

    if (logicalAnalysis && problemSolving) {
      connections.push({
        userId,
        fromNodeId: logicalAnalysis.id,
        toNodeId: problemSolving.id,
        connectionType: 'prerequisite',
        strength: '0.9'
      });
    }

    // Create skill connections based on categories
    const skillNodes = nodes.filter(n => n.type === 'skill');
    for (let i = 0; i < skillNodes.length; i++) {
      for (let j = i + 1; j < skillNodes.length; j++) {
        if (skillNodes[i].category === skillNodes[j].category) {
          connections.push({
            userId,
            fromNodeId: skillNodes[i].id,
            toNodeId: skillNodes[j].id,
            connectionType: 'related',
            strength: '0.6'
          });
        }
      }
    }

    // Store connections in database
    const createdConnections = [];
    for (const connection of connections) {
      const created = await storage.createKnowledgeConnection(connection);
      createdConnections.push(created);
    }

    return createdConnections;
  }

  private applyForceDirectedLayout(nodes: KnowledgeNode[], connections: KnowledgeConnection[]): KnowledgeGraphLayout {
    const layoutNodes = nodes.map(node => {
      const position = node.position as any;
      return {
        id: node.id,
        x: position?.x || Math.random() * 800,
        y: position?.y || Math.random() * 600,
        size: Math.max(20, (parseFloat(node.masteryLevel || '0') * 50) + 10),
        color: this.getCategoryColor(node.category || 'general')
      };
    });

    const layoutConnections = connections.map(conn => ({
      from: conn.fromNodeId,
      to: conn.toNodeId,
      weight: parseFloat(conn.strength || '0'),
      type: conn.connectionType || 'related'
    }));

    return {
      nodes: layoutNodes,
      connections: layoutConnections
    };
  }

  private getCategoryColor(category: string): string {
    const colorMap: { [key: string]: string } = {
      mathematics: '#3b82f6',
      logic: '#8b5cf6',
      cognition: '#10b981',
      general: '#f59e0b',
      programming: '#ef4444',
      science: '#06b6d4',
      language: '#84cc16'
    };
    return colorMap[category] || '#6b7280';
  }

  // Generate AI-powered insights about the knowledge graph
  async generateKnowledgeInsights(userId: string): Promise<{
    strengthAreas: string[];
    weaknessAreas: string[];
    recommendations: string[];
    learningPath: string[];
  }> {
    const nodes = await storage.getKnowledgeNodesByUser(userId);
    const connections = await storage.getKnowledgeConnectionsByUser(userId);
    
    const strengths = nodes
      .filter(n => parseFloat(n.masteryLevel || '0') > 0.7)
      .map(n => n.title || 'Untitled');
    
    const weaknesses = nodes
      .filter(n => parseFloat(n.masteryLevel || '0') < 0.4)
      .map(n => n.title || 'Untitled');

    const recommendations = [
      `Focus on strengthening ${weaknesses[0]} as it's foundational to other concepts`,
      `Leverage your strong ${strengths[0]} skills to tackle more advanced topics`,
      `Consider exploring connections between ${strengths[0]} and ${weaknesses[0]}`
    ];

    const learningPath = weaknesses.concat(
      nodes
        .filter(n => parseFloat(n.masteryLevel || '0') >= 0.4 && parseFloat(n.masteryLevel || '0') <= 0.7)
        .map(n => n.title || 'Untitled')
    );

    return {
      strengthAreas: strengths,
      weaknessAreas: weaknesses,
      recommendations,
      learningPath
    };
  }

  // Save custom visualization configuration
  async saveVisualization(userId: string, name: string, type: string, config: VisualizationConfig): Promise<KnowledgeVisualization> {
    const nodes = await storage.getKnowledgeNodesByUser(userId);
    const connections = await storage.getKnowledgeConnectionsByUser(userId);
    const layout = this.applyForceDirectedLayout(nodes, connections);

    const visualization: InsertKnowledgeVisualization = {
      userId,
      name,
      type,
      config: config as any,
      nodes: layout.nodes as any,
      connections: layout.connections as any,
      layout: layout as any,
      isPublic: false
    };

    return await storage.createKnowledgeVisualization(visualization);
  }
}