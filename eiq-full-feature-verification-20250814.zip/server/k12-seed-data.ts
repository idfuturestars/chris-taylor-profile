import { storage } from "./storage";

export const industryTracksSeedData = [
  {
    name: "jobs-cook",
    displayName: "Innovation & Design Leadership",
    description: "Master product innovation, design thinking, and transformative technology leadership inspired by Steve Jobs and Tim Cook",
    focusAreas: [
      "Product Design & Innovation",
      "User Experience Design", 
      "Design Thinking Methodology",
      "Technology Vision & Strategy",
      "Creative Problem Solving",
      "Human-Centered Design"
    ],
    ageRanges: [
      "K-2: Creative Building & Visual Design",
      "3-5: Design Thinking & Innovation Games", 
      "6-8: Product Concepts & User Experience",
      "9-12: Leadership & Strategic Innovation"
    ],
    learningObjectives: [
      "Develop creative problem-solving skills",
      "Master design thinking processes",
      "Learn user-centered design principles",
      "Build innovation and leadership capabilities",
      "Create compelling product experiences"
    ],
    industryPartners: ["Apple", "Tesla", "Design Studios", "Innovation Labs"],
    isActive: true
  },
  {
    name: "page-pichai",
    displayName: "Search & AI Systems",
    description: "Build expertise in AI, machine learning, search algorithms, and large-scale systems following Larry Page and Sundar Pichai's vision",
    focusAreas: [
      "Machine Learning & AI",
      "Algorithm Design & Analysis",
      "Data Systems & Architecture", 
      "Search Technologies",
      "Natural Language Processing",
      "AI Ethics & Responsibility"
    ],
    ageRanges: [
      "K-2: Pattern Recognition & Logic Games",
      "3-5: Basic Algorithms & Data Organization",
      "6-8: Programming & AI Concepts", 
      "9-12: Machine Learning & Advanced Systems"
    ],
    learningObjectives: [
      "Master algorithmic thinking and problem solving",
      "Understand machine learning fundamentals",
      "Learn data structures and system design",
      "Develop AI and search technologies",
      "Apply ethical AI principles"
    ],
    industryPartners: ["Google", "DeepMind", "AI Research Labs", "Tech Startups"],
    isActive: true
  },
  {
    name: "gates-ballmer", 
    displayName: "Software & Platform Engineering",
    description: "Master software development, platform architecture, and enterprise solutions in the tradition of Bill Gates and Steve Ballmer",
    focusAreas: [
      "Software Engineering & Development",
      "Platform Architecture & Design",
      "Cloud Computing Technologies",
      "Enterprise Software Solutions", 
      "System Integration & APIs",
      "DevOps & Deployment"
    ],
    ageRanges: [
      "K-2: Basic Coding & Computer Logic",
      "3-5: Programming Fundamentals & Logic",
      "6-8: Software Development Projects",
      "9-12: Enterprise Architecture & Cloud"
    ],
    learningObjectives: [
      "Learn programming languages and frameworks",
      "Master software architecture principles", 
      "Understand cloud and enterprise systems",
      "Build scalable software solutions",
      "Develop platform thinking capabilities"
    ],
    industryPartners: ["Microsoft", "Enterprise Software Companies", "Cloud Platforms", "Software Consultancies"],
    isActive: true
  },
  {
    name: "zuck-huang",
    displayName: "Social Technology & Computing", 
    description: "Explore social networks, virtual reality, gaming, and next-generation computing inspired by Mark Zuckerberg and Jensen Huang",
    focusAreas: [
      "Social Platform Development",
      "Virtual & Augmented Reality",
      "Gaming Systems & Graphics",
      "GPU Computing & Parallel Processing",
      "Metaverse Technologies",
      "Social Impact & Digital Communities"
    ],
    ageRanges: [
      "K-2: Digital Creativity & Virtual Worlds",
      "3-5: Game Design & Interactive Media",
      "6-8: Social Technology & VR Basics",
      "9-12: Advanced Graphics & Metaverse Development"
    ],
    learningObjectives: [
      "Create interactive digital experiences",
      "Master graphics and visual computing",
      "Build social and collaborative platforms",
      "Develop VR/AR applications",
      "Understand parallel computing concepts"
    ],
    industryPartners: ["Meta", "NVIDIA", "Gaming Studios", "VR/AR Companies"],
    isActive: true
  },
  {
    name: "ellison-catz",
    displayName: "Database & Enterprise Systems",
    description: "Master database technology, enterprise software, and business intelligence systems following Larry Ellison and Safra Catz's approach",
    focusAreas: [
      "Database Systems & Management",
      "Enterprise Software Architecture",
      "Business Intelligence & Analytics",
      "Data Warehousing & ETL",
      "Enterprise Resource Planning",
      "Business Process Optimization"
    ],
    ageRanges: [
      "K-2: Data Organization & Information Systems",
      "3-5: Database Concepts & Data Storage",
      "6-8: SQL & Database Management",
      "9-12: Enterprise Systems & Business Intelligence"
    ],
    learningObjectives: [
      "Master database design and management",
      "Learn enterprise software patterns",
      "Understand business intelligence systems",
      "Develop data analytics capabilities",
      "Build enterprise-scale solutions"
    ],
    industryPartners: ["Oracle", "Enterprise Software Companies", "Database Vendors", "Business Intelligence Firms"],
    isActive: true
  },
  {
    name: "buffet-apfel",
    displayName: "Financial Technology & Analytics",
    description: "Learn financial analysis, investment technology, and quantitative trading systems inspired by Warren Buffet and business leadership",
    focusAreas: [
      "Financial Analysis & Modeling",
      "Investment Technology Systems",
      "Quantitative Methods & Statistics",
      "Risk Management & Assessment",
      "Algorithmic Trading Systems",
      "Business Strategy & Operations"
    ],
    ageRanges: [
      "K-2: Money Concepts & Basic Math",
      "3-5: Financial Literacy & Business Games",
      "6-8: Investment Logic & Market Analysis",
      "9-12: Quantitative Finance & Trading Systems"
    ],
    learningObjectives: [
      "Master financial mathematics and modeling",
      "Learn investment analysis techniques",
      "Understand risk management principles",
      "Develop quantitative analysis skills",
      "Build financial technology solutions"
    ],
    industryPartners: ["Berkshire Hathaway", "FinTech Companies", "Investment Firms", "Financial Technology Startups"],
    isActive: true
  }
];

export const curriculumModulesSeedData = [
  // Jobs/Cook Track - K-2 Module
  {
    trackId: "", // Will be filled by actual track ID
    name: "Creative Building Foundations",
    description: "Introduction to creative thinking and visual design for young learners",
    gradeLevel: "K-2",
    subject: "design",
    difficulty: "foundation", 
    estimatedDuration: 45,
    prerequisites: [],
    learningObjectives: [
      "Identify basic shapes and colors in design",
      "Create simple visual compositions", 
      "Express ideas through drawing and building",
      "Understand the concept of 'making things better'"
    ],
    assessmentCriteria: [
      "Can identify and use basic design elements",
      "Shows creativity in problem-solving",
      "Demonstrates understanding of user needs",
      "Communicates ideas clearly"
    ],
    contentStructure: {
      videos: ["Introduction to Design", "Colors and Shapes", "Building with Blocks"],
      exercises: ["Design Challenge", "Color Mixing", "Shape Creation"],
      projects: ["My Dream Toy", "Perfect Playground"]
    },
    isActive: true
  },
  // Page/Pichai Track - 6-8 Module  
  {
    trackId: "", // Will be filled by actual track ID
    name: "Introduction to Machine Learning",
    description: "Foundational concepts in artificial intelligence and machine learning for middle school students",
    gradeLevel: "6-8",
    subject: "ai_concepts",
    difficulty: "intermediate",
    estimatedDuration: 60,
    prerequisites: ["Basic Programming", "Mathematical Reasoning"],
    learningObjectives: [
      "Understand what machine learning is and how it works",
      "Identify examples of AI in everyday life",
      "Create simple classification algorithms",
      "Explore ethical considerations in AI"
    ],
    assessmentCriteria: [
      "Can explain machine learning concepts clearly",
      "Identifies AI applications accurately", 
      "Builds working classification model",
      "Discusses AI ethics thoughtfully"
    ],
    contentStructure: {
      videos: ["What is AI?", "Machine Learning Basics", "Neural Networks Intro"],
      exercises: ["AI Scavenger Hunt", "Pattern Recognition Games", "Simple Classifier"],
      projects: ["Build an AI Assistant", "Ethical AI Discussion"]
    },
    isActive: true
  },
  // Gates/Ballmer Track - 9-12 Module
  {
    trackId: "", // Will be filled by actual track ID  
    name: "Software Architecture Fundamentals",
    description: "Advanced software design patterns and architectural principles for high school students",
    gradeLevel: "9-12",
    subject: "programming",
    difficulty: "advanced",
    estimatedDuration: 90,
    prerequisites: ["Object-Oriented Programming", "Data Structures", "Algorithms"],
    learningObjectives: [
      "Master software design patterns and principles",
      "Understand system architecture and scalability",
      "Learn cloud computing fundamentals",
      "Build enterprise-level applications"
    ],
    assessmentCriteria: [
      "Applies design patterns correctly",
      "Designs scalable system architectures",
      "Implements cloud-based solutions",
      "Writes maintainable, enterprise-quality code"
    ],
    contentStructure: {
      videos: ["Design Patterns Overview", "Microservices Architecture", "Cloud Deployment"],
      exercises: ["Pattern Implementation", "Architecture Design", "Cloud Migration"],
      projects: ["E-commerce Platform", "Distributed System Design"]
    },
    isActive: true
  }
];

export const questionBankSeedData = [
  {
    moduleId: "", // Will be filled by actual module ID
    questionType: "multiple_choice",
    subject: "mathematics", 
    topic: "algebra",
    difficulty: 2.5,
    questionText: "If x + 5 = 12, what is the value of x?",
    questionData: {
      options: ["5", "7", "12", "17"],
      correctAnswer: 1
    },
    explanation: "To solve x + 5 = 12, we subtract 5 from both sides: x = 12 - 5 = 7",
    hints: [
      "What operation would cancel out adding 5?",
      "Try subtracting 5 from both sides of the equation", 
      "12 - 5 = ?"
    ],
    tags: ["algebra", "equations", "basic"],
    aiGenerated: false,
    validatedBy: "system",
    isActive: true
  },
  {
    moduleId: "", // Will be filled by actual module ID
    questionType: "multiple_choice",
    subject: "programming",
    topic: "logic",
    difficulty: 3.0,
    questionText: "What will this code output?\n\nfor i in range(3):\n    print(i * 2)",
    questionData: {
      options: ["0 1 2", "0 2 4", "2 4 6", "1 2 3"],
      correctAnswer: 1
    },
    explanation: "The range(3) creates values 0, 1, 2. Each is multiplied by 2, giving 0, 2, 4",
    hints: [
      "range(3) gives you 0, 1, 2",
      "Each number gets multiplied by 2",
      "0*2=0, 1*2=2, 2*2=4"
    ],
    tags: ["programming", "loops", "python"],
    aiGenerated: false,
    validatedBy: "system", 
    isActive: true
  },
  {
    moduleId: "", // Will be filled by actual module ID
    questionType: "open_ended",
    subject: "ai_concepts",
    topic: "machine_learning",
    difficulty: 2.0,
    questionText: "Explain in your own words what machine learning is and give one example of how it's used in everyday life.",
    questionData: {},
    explanation: "Machine learning is when computers learn patterns from data to make predictions or decisions without being explicitly programmed for each specific task.",
    hints: [
      "Think about how computers can learn from examples",
      "Consider apps that recommend things to you",
      "How do computers recognize your voice or face?"
    ],
    tags: ["ai", "machine_learning", "concepts"],
    aiGenerated: false,
    validatedBy: "system",
    isActive: true
  }
];

export async function seedK12Data() {
  console.log("🌱 Seeding K-12 industry tracks and curriculum data...");
  
  try {
    // Seed industry tracks
    const createdTracks = [];
    for (const trackData of industryTracksSeedData) {
      const track = await storage.createIndustryTrack(trackData);
      createdTracks.push(track);
      console.log(`✅ Created industry track: ${track.displayName}`);
    }
    
    // Seed curriculum modules with actual track IDs
    for (let i = 0; i < curriculumModulesSeedData.length; i++) {
      const moduleData = {
        ...curriculumModulesSeedData[i],
        trackId: createdTracks[i % createdTracks.length].id
      };
      const module = await storage.createCurriculumModule(moduleData);
      console.log(`✅ Created curriculum module: ${module.name}`);
      
      // Seed questions for this module
      for (const questionData of questionBankSeedData) {
        const question = await storage.createQuestion({
          ...questionData,
          moduleId: module.id
        });
        console.log(`✅ Created question: ${question.questionText.substring(0, 50)}...`);
      }
    }
    
    console.log("🎉 K-12 seed data creation completed successfully!");
    
  } catch (error) {
    console.error("❌ Error seeding K-12 data:", error);
    throw error;
  }
}