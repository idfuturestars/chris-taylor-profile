-- Current sql file was generated after introspecting the database
-- If you want to run this migration please uncomment this code before executing migrations
/*
CREATE TABLE "assessments" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"type" text NOT NULL,
	"score" numeric(5, 2),
	"progress" integer DEFAULT 0,
	"completed" boolean DEFAULT false,
	"data" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"difficulty" text DEFAULT 'adaptive',
	"adaptive_level" numeric(3, 2) DEFAULT '0.00'
);
--> statement-breakpoint
CREATE TABLE "documents" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"file_name" text NOT NULL,
	"file_type" text NOT NULL,
	"file_size" integer,
	"status" text DEFAULT 'processing',
	"extracted_data" jsonb,
	"uploaded_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "course_feed" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"type" text NOT NULL,
	"category" text NOT NULL,
	"priority" integer DEFAULT 0,
	"is_active" boolean DEFAULT true,
	"published_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_conversations" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"messages" jsonb NOT NULL,
	"provider" text NOT NULL,
	"session_id" varchar,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "corporate_partners" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"industry" text NOT NULL,
	"size" text,
	"logo_url" text,
	"website" text,
	"contact_email" text,
	"headquarters" text,
	"target_eiq_range" jsonb,
	"talent_requirements" jsonb,
	"partnership_tier" text,
	"partnership_status" text DEFAULT 'active',
	"recruitment_quota" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"username" text,
	"email" text NOT NULL,
	"password" text,
	"first_name" text,
	"last_name" text,
	"current_level" text DEFAULT 'Foundation',
	"assessment_progress" integer DEFAULT 0,
	"learning_streak" integer DEFAULT 0,
	"ai_interactions" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"profile_image_url" text,
	"auth_provider" text DEFAULT 'local',
	"provider_id" text,
	"linked_providers" text[] DEFAULT '{""}',
	"email_verified" boolean DEFAULT false,
	"last_login_at" timestamp,
	"role" text DEFAULT 'student',
	"institution_id" varchar,
	"staff_credentials" jsonb,
	"is_active" boolean DEFAULT true,
	CONSTRAINT "users_username_unique" UNIQUE("username"),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "learning_paths" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"path_type" text NOT NULL,
	"current_step" integer DEFAULT 0,
	"progress" integer DEFAULT 0,
	"completed" boolean DEFAULT false,
	"data" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "study_groups" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"topic" text NOT NULL,
	"max_members" integer DEFAULT 10,
	"is_active" boolean DEFAULT true,
	"created_by" varchar NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "study_group_members" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"group_id" varchar NOT NULL,
	"user_id" varchar NOT NULL,
	"role" text DEFAULT 'member',
	"joined_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "talent_profiles" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"current_eiq_score" numeric(5, 2),
	"peak_eiq_score" numeric(5, 2),
	"skills_profile" jsonb,
	"career_interests" jsonb,
	"availability" text,
	"resume_data" jsonb,
	"portfolio_links" jsonb,
	"is_open_to_recruitment" boolean DEFAULT false,
	"visibility_settings" jsonb,
	"last_profile_update" timestamp DEFAULT now(),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "university_applications" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"university_id" varchar NOT NULL,
	"program" text NOT NULL,
	"application_eiq_score" numeric(5, 2),
	"transcript_analysis" jsonb,
	"recommendation_status" text,
	"application_data" jsonb,
	"status" text DEFAULT 'draft',
	"submitted_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "university_partners" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"country" text NOT NULL,
	"ranking" integer,
	"logo_url" text,
	"website" text,
	"contact_email" text,
	"min_eiq_score" numeric(5, 2),
	"preferred_eiq_score" numeric(5, 2),
	"programs" jsonb,
	"admission_process" jsonb,
	"partnership_status" text DEFAULT 'active',
	"partnership_tier" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "vr_competition_participants" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"competition_id" varchar NOT NULL,
	"user_id" varchar NOT NULL,
	"entry_eiq_score" numeric(5, 2),
	"current_score" numeric(8, 2) DEFAULT '0',
	"rank" integer,
	"completed_challenges" integer DEFAULT 0,
	"total_time_spent" integer DEFAULT 0,
	"vr_session_data" jsonb,
	"achievements" jsonb,
	"joined_at" timestamp DEFAULT now(),
	"last_active_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_tutoring_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"session_type" text NOT NULL,
	"subject" text NOT NULL,
	"current_eiq_score" numeric(5, 2),
	"target_eiq_score" numeric(5, 2),
	"improvement_plan" jsonb,
	"conversation_history" jsonb NOT NULL,
	"learning_gaps" jsonb,
	"progress_metrics" jsonb,
	"ai_provider" text DEFAULT 'openai' NOT NULL,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"grade_level" text,
	"mastery_level" text DEFAULT 'attempted',
	"hint_usage" jsonb,
	"session_duration" integer,
	"questions_answered" integer DEFAULT 0,
	"correct_answers" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "degree_audits" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"degree_plan_id" varchar NOT NULL,
	"audit_type" text NOT NULL,
	"completed_requirements" jsonb,
	"pending_requirements" jsonb,
	"missing_requirements" jsonb,
	"excess_credits" jsonb,
	"substitute_credits" jsonb,
	"waived_requirements" jsonb,
	"gpa_calculation" jsonb,
	"graduation_eligibility" text,
	"recommended_actions" jsonb,
	"run_date" timestamp DEFAULT now(),
	"audit_results" jsonb
);
--> statement-breakpoint
CREATE TABLE "recruitment_matches" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"talent_profile_id" varchar NOT NULL,
	"corporate_partner_id" varchar NOT NULL,
	"job_title" text NOT NULL,
	"match_score" numeric(5, 2),
	"eiq_requirement" numeric(5, 2),
	"job_description" text,
	"salary" jsonb,
	"status" text DEFAULT 'matched',
	"contacted_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "vr_competitions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"competition_type" text NOT NULL,
	"subject" text NOT NULL,
	"difficulty" text NOT NULL,
	"vr_environment" text NOT NULL,
	"max_participants" integer DEFAULT 100,
	"entry_requirement" numeric(5, 2),
	"prize_structure" jsonb,
	"start_date" timestamp,
	"end_date" timestamp,
	"status" text DEFAULT 'upcoming',
	"leaderboard" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "oauth_providers" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"provider" text NOT NULL,
	"provider_id" text NOT NULL,
	"email" text,
	"name" text,
	"profile_image_url" text,
	"access_token" text,
	"refresh_token" text,
	"token_expiry" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "courses" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"course_code" text NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"credits" integer NOT NULL,
	"department" text NOT NULL,
	"level" text NOT NULL,
	"prerequisites" jsonb,
	"corequisites" jsonb,
	"difficulty" text,
	"average_workload" integer,
	"pass_rate" numeric(5, 2),
	"recommended_eiq_score" numeric(5, 2),
	"offerings" jsonb,
	"max_enrollment" integer,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "courses_course_code_unique" UNIQUE("course_code")
);
--> statement-breakpoint
CREATE TABLE "course_demand_analytics" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"course_id" varchar NOT NULL,
	"semester" text NOT NULL,
	"year" integer NOT NULL,
	"planned_enrollment" integer,
	"actual_enrollment" integer,
	"waitlist_size" integer,
	"demand_score" numeric(5, 2),
	"shortage_risk" text,
	"recommended_sections" integer,
	"eiq_driven_demand" jsonb,
	"generated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "student_degree_plans" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"degree_program_id" varchar NOT NULL,
	"plan_name" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"is_primary" boolean DEFAULT false,
	"current_gpa" numeric(3, 2),
	"completed_credits" integer DEFAULT 0,
	"remaining_credits" integer,
	"projected_graduation_date" timestamp,
	"actual_graduation_date" timestamp,
	"plan_status" text DEFAULT 'active',
	"risk_factors" jsonb,
	"intervention_recommendations" jsonb,
	"eiq_based_recommendations" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "degree_programs" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"university_id" varchar NOT NULL,
	"name" text NOT NULL,
	"degree_type" text NOT NULL,
	"department" text NOT NULL,
	"total_credits" integer NOT NULL,
	"estimated_duration" integer NOT NULL,
	"min_eiq_score" numeric(5, 2),
	"recommended_eiq_score" numeric(5, 2),
	"prerequisites" jsonb,
	"core_requirements" jsonb,
	"elective_requirements" jsonb,
	"specializations" jsonb,
	"career_outcomes" jsonb,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "planned_courses" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"degree_plan_id" varchar NOT NULL,
	"course_id" varchar NOT NULL,
	"planned_semester" text NOT NULL,
	"planned_year" integer NOT NULL,
	"semester_order" integer,
	"status" text DEFAULT 'planned',
	"actual_grade" text,
	"grade_points" numeric(3, 2),
	"is_required" boolean DEFAULT true,
	"requirement_type" text,
	"alternative_courses" jsonb,
	"eiq_recommendation_score" numeric(3, 2),
	"difficulty_prediction" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_onboarding" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"personal_info" jsonb NOT NULL,
	"educational_background" jsonb NOT NULL,
	"career_goals" jsonb NOT NULL,
	"learning_preferences" jsonb NOT NULL,
	"assessment_readiness" jsonb NOT NULL,
	"completed" boolean DEFAULT true,
	"recommended_track" text,
	"estimated_eiq_range" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	"educational_level" text NOT NULL,
	"grade_level" text,
	"age" integer,
	"pathway_type" text NOT NULL,
	"parent_email" text,
	"school_name" text,
	"preferred_subjects" text[],
	"mentor_personality" text DEFAULT 'supportive',
	"ai_conversation_history" jsonb,
	"personalized_insights" jsonb,
	"adaptive_suggestions" jsonb,
	"engagement_level" integer DEFAULT 5,
	"mentor_feedback_rating" integer
);
--> statement-breakpoint
CREATE TABLE "assessment_responses" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"question_id" varchar NOT NULL,
	"session_id" varchar,
	"user_answer" jsonb NOT NULL,
	"is_correct" boolean NOT NULL,
	"time_spent" integer NOT NULL,
	"hints_used" integer DEFAULT 0,
	"attempts_count" integer DEFAULT 1,
	"mastery_level" text,
	"ai_explanation" text,
	"response_date" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "skill_recommendations" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"skill_category" text NOT NULL,
	"skill_name" text NOT NULL,
	"current_level" text NOT NULL,
	"target_level" text NOT NULL,
	"priority" integer DEFAULT 1,
	"estimated_hours" integer DEFAULT 0,
	"prerequisite_skills" text[] DEFAULT '{""}',
	"learning_path" jsonb NOT NULL,
	"ai_reasoning" text,
	"progress" integer DEFAULT 0,
	"is_active" boolean DEFAULT true,
	"completed_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "exercise_attempts" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"exercise_id" varchar NOT NULL,
	"attempt_number" integer DEFAULT 1,
	"start_time" timestamp DEFAULT now(),
	"end_time" timestamp,
	"time_spent" integer,
	"user_response" jsonb NOT NULL,
	"score" numeric(5, 2),
	"mastery_level" text,
	"feedback" text,
	"hints_used" integer DEFAULT 0,
	"is_completed" boolean DEFAULT false,
	"ai_analysis" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "question_bank" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"module_id" varchar NOT NULL,
	"question_type" text NOT NULL,
	"subject" text NOT NULL,
	"topic" text NOT NULL,
	"difficulty" numeric(3, 2) NOT NULL,
	"question_text" text NOT NULL,
	"question_data" jsonb NOT NULL,
	"explanation" text NOT NULL,
	"hints" jsonb,
	"tags" jsonb,
	"ai_generated" boolean DEFAULT false,
	"validated_by" varchar,
	"usage_count" integer DEFAULT 0,
	"success_rate" numeric(5, 2),
	"average_time" integer,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "industry_tracks" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"display_name" text NOT NULL,
	"description" text NOT NULL,
	"focus_areas" jsonb NOT NULL,
	"age_ranges" jsonb NOT NULL,
	"prerequisites" jsonb,
	"learning_objectives" jsonb NOT NULL,
	"industry_partners" jsonb,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "curriculum_modules" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"track_id" varchar NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"grade_level" text NOT NULL,
	"subject" text NOT NULL,
	"difficulty" text NOT NULL,
	"estimated_duration" integer NOT NULL,
	"prerequisites" jsonb,
	"learning_objectives" jsonb NOT NULL,
	"assessment_criteria" jsonb NOT NULL,
	"content_structure" jsonb NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "practice_exercises" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"module_id" varchar NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"exercise_type" text NOT NULL,
	"difficulty" numeric(3, 2) NOT NULL,
	"estimated_time" integer NOT NULL,
	"instructions" text NOT NULL,
	"exercise_data" jsonb NOT NULL,
	"solution_data" jsonb,
	"hints" jsonb,
	"prerequisites" jsonb,
	"learning_objectives" jsonb,
	"is_adaptive" boolean DEFAULT false,
	"adaptive_parameters" jsonb,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "learning_pathways" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"track_id" varchar NOT NULL,
	"pathway_type" text NOT NULL,
	"current_module" varchar,
	"completed_modules" jsonb DEFAULT '[]'::jsonb,
	"progress_map" jsonb NOT NULL,
	"adaptive_recommendations" jsonb,
	"difficulty_profile" jsonb,
	"learning_style" text,
	"weekly_goals" jsonb,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "video_lessons" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"module_id" varchar NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"video_url" text,
	"duration" integer NOT NULL,
	"transcript" text,
	"lesson_order" integer NOT NULL,
	"prerequisites" jsonb,
	"key_concepts_introduced" jsonb,
	"practice_exercises" jsonb,
	"is_interactive" boolean DEFAULT false,
	"interactive_elements" jsonb,
	"view_count" integer DEFAULT 0,
	"average_rating" numeric(3, 2),
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "video_progress" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"video_id" varchar NOT NULL,
	"watched_duration" integer DEFAULT 0,
	"completion_percentage" numeric(5, 2) DEFAULT '0',
	"last_watched_position" integer DEFAULT 0,
	"is_completed" boolean DEFAULT false,
	"notes_count" integer DEFAULT 0,
	"questions_asked" integer DEFAULT 0,
	"user_rating" integer,
	"watch_history" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_mentor_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"session_type" text NOT NULL,
	"started_at" timestamp DEFAULT now(),
	"completed_at" timestamp,
	"conversation_log" jsonb NOT NULL,
	"insights" jsonb,
	"action_items" jsonb,
	"user_satisfaction" integer,
	"mentor_personality" text NOT NULL,
	"ai_provider" text DEFAULT 'anthropic',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_learning_data" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"data_type" text NOT NULL,
	"source_user_id" varchar,
	"source_session_id" varchar,
	"raw_data" jsonb NOT NULL,
	"processed_data" jsonb,
	"patterns" jsonb,
	"correlations" jsonb,
	"feature_vector" jsonb,
	"labels" text[],
	"confidence" numeric(3, 2),
	"model_version" text,
	"processing_algorithm" text,
	"validation_status" text DEFAULT 'pending',
	"learning_impact" jsonb,
	"prediction_accuracy" numeric(3, 2),
	"improvement_metrics" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "real_time_analytics" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"time_window" text NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"active_users" integer DEFAULT 0,
	"new_registrations" integer DEFAULT 0,
	"assessment_sessions" integer DEFAULT 0,
	"completion_rate" numeric(3, 2),
	"avg_response_time" integer,
	"error_rate" numeric(3, 2),
	"server_load" numeric(3, 2),
	"database_connections" integer,
	"avg_session_duration" integer,
	"pages_per_session" numeric(3, 2),
	"bounce_rate" numeric(3, 2),
	"conversion_rate" numeric(3, 2),
	"ai_interactions" integer DEFAULT 0,
	"hints_generated" integer DEFAULT 0,
	"adaptive_adjustments" integer DEFAULT 0,
	"learning_efficiency" numeric(3, 2),
	"test_results" jsonb,
	"stat_sig_results" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "live_testing_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar,
	"session_type" text NOT NULL,
	"started_at" timestamp DEFAULT now(),
	"ended_at" timestamp,
	"duration" integer,
	"is_active" boolean DEFAULT true,
	"test_group" text,
	"test_variant" text,
	"goal_metrics" jsonb,
	"interaction_count" integer DEFAULT 0,
	"error_count" integer DEFAULT 0,
	"completion_rate" numeric(3, 2),
	"satisfaction_score" integer,
	"learning_objectives" text[],
	"achieved_objectives" text[] DEFAULT '{""}',
	"adaptive_adjustments" jsonb,
	"ai_insights" jsonb,
	"behavior_patterns" jsonb,
	"performance_metrics" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_behavior_tracking" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"session_id" varchar NOT NULL,
	"event_type" text NOT NULL,
	"event_data" jsonb NOT NULL,
	"page" text NOT NULL,
	"component" text,
	"response_time" integer,
	"time_on_page" integer,
	"scroll_depth" integer,
	"click_path" text[] DEFAULT '{""}',
	"interaction_quality" integer,
	"focus_time" integer,
	"idle_time" integer,
	"user_agent" text,
	"ip_address" text,
	"device_type" text,
	"browser_type" text,
	"viewport" jsonb,
	"connection_speed" text,
	"experiment_group" text,
	"feature_flags" text[] DEFAULT '{""}',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" jsonb NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "achievement_progress" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"badge_id" varchar NOT NULL,
	"current_progress" integer DEFAULT 0,
	"target_value" integer NOT NULL,
	"progress_data" jsonb,
	"last_updated" timestamp DEFAULT now(),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "achievement_badges" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"tier" text NOT NULL,
	"title" text NOT NULL,
	"description" text NOT NULL,
	"icon_path" text NOT NULL,
	"color_scheme" text NOT NULL,
	"criteria" jsonb NOT NULL,
	"points" integer DEFAULT 0 NOT NULL,
	"rarity" text DEFAULT 'common' NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "achievement_badges_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "user_badges" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"badge_id" varchar NOT NULL,
	"earned_at" timestamp DEFAULT now(),
	"progress" jsonb,
	"is_displayed" boolean DEFAULT true,
	"notification_sent" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "learning_hints" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"question_id" varchar,
	"content" text NOT NULL,
	"type" text NOT NULL,
	"difficulty" text NOT NULL,
	"relevance_score" numeric(3, 2) DEFAULT '0.50',
	"context" jsonb,
	"is_useful" boolean,
	"was_followed" boolean,
	"time_to_show" integer,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "hint_effectiveness" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"hint_id" varchar NOT NULL,
	"performance_before" numeric(3, 2),
	"performance_after" numeric(3, 2),
	"improvement_score" numeric(3, 2),
	"context_similarity" numeric(3, 2),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "chat_messages" (
	"id" varchar PRIMARY KEY NOT NULL,
	"session_id" varchar NOT NULL,
	"role" varchar NOT NULL,
	"content" text NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_sessions" (
	"id" varchar PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"title" varchar NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"last_message_at" timestamp DEFAULT now() NOT NULL,
	"message_count" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "institutions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"accreditation" text,
	"website" text,
	"contact_email" text,
	"address" text,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "staff_observations" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"staff_id" varchar NOT NULL,
	"student_id" varchar NOT NULL,
	"observation_type" text NOT NULL,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"priority" text DEFAULT 'medium',
	"tags" text[] DEFAULT '{""}',
	"is_private" boolean DEFAULT false,
	"parent_notification" boolean DEFAULT false,
	"follow_up_required" boolean DEFAULT false,
	"follow_up_date" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "staff_student_assignments" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"staff_id" varchar NOT NULL,
	"student_id" varchar NOT NULL,
	"assigned_by" varchar NOT NULL,
	"assigned_at" timestamp DEFAULT now(),
	"is_active" boolean DEFAULT true,
	"notes" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "student_progress_analytics" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"student_id" varchar NOT NULL,
	"analysis_date" timestamp DEFAULT now(),
	"cognitive_strengths" jsonb,
	"improvement_areas" jsonb,
	"learning_velocity" numeric(5, 2),
	"engagement_score" numeric(3, 2),
	"risk_factors" jsonb,
	"intervention_suggestions" jsonb,
	"next_milestones" jsonb,
	"parent_report_generated" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "custom_question_responses" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"custom_question_id" varchar NOT NULL,
	"student_id" varchar NOT NULL,
	"response_text" text,
	"response_time" integer,
	"is_correct" boolean,
	"staff_feedback" text,
	"score" numeric(5, 2),
	"follow_up_needed" boolean DEFAULT false,
	"response_metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "knowledge_nodes" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"title" text NOT NULL,
	"type" text NOT NULL,
	"category" text,
	"description" text,
	"mastery_level" numeric(3, 2) DEFAULT '0.00',
	"connections" jsonb DEFAULT '[]'::jsonb,
	"position" jsonb,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ai_question_sessions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"staff_id" varchar NOT NULL,
	"student_assessment_data" jsonb,
	"ai_provider_used" text,
	"generation_parameters" jsonb,
	"generated_questions" jsonb,
	"selected_question_ids" text[] DEFAULT '{""}',
	"session_metadata" jsonb,
	"effectiveness" numeric(3, 2),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "custom_questions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"staff_id" varchar NOT NULL,
	"student_id" varchar,
	"title" text NOT NULL,
	"question_text" text NOT NULL,
	"question_type" text NOT NULL,
	"options" jsonb,
	"correct_answer" text,
	"difficulty_estimate" integer,
	"cognitive_domains" text[] DEFAULT '{""}',
	"created_from_assessment_id" varchar,
	"ai_assistance_used" boolean DEFAULT false,
	"ai_generation_prompt" text,
	"status" text DEFAULT 'draft',
	"tags" text[] DEFAULT '{""}',
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "question_assignments" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"custom_question_id" varchar NOT NULL,
	"student_id" varchar NOT NULL,
	"staff_id" varchar NOT NULL,
	"assigned_at" timestamp DEFAULT now(),
	"due_date" timestamp,
	"priority" text DEFAULT 'medium',
	"instructions" text,
	"status" text DEFAULT 'assigned',
	"completed_at" timestamp,
	"assignment_metadata" jsonb
);
--> statement-breakpoint
CREATE TABLE "knowledge_connections" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"from_node_id" varchar NOT NULL,
	"to_node_id" varchar NOT NULL,
	"connection_type" text DEFAULT 'prerequisite',
	"strength" numeric(3, 2) DEFAULT '1.00',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "knowledge_visualizations" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"config" jsonb,
	"nodes" jsonb,
	"connections" jsonb,
	"layout" jsonb,
	"is_public" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "assessments" ADD CONSTRAINT "assessments_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "documents" ADD CONSTRAINT "documents_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_conversations" ADD CONSTRAINT "ai_conversations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "learning_paths" ADD CONSTRAINT "learning_paths_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "study_groups" ADD CONSTRAINT "study_groups_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "study_group_members" ADD CONSTRAINT "study_group_members_group_id_study_groups_id_fk" FOREIGN KEY ("group_id") REFERENCES "public"."study_groups"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "study_group_members" ADD CONSTRAINT "study_group_members_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "talent_profiles" ADD CONSTRAINT "talent_profiles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "university_applications" ADD CONSTRAINT "university_applications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "university_applications" ADD CONSTRAINT "university_applications_university_id_university_partners_id_fk" FOREIGN KEY ("university_id") REFERENCES "public"."university_partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vr_competition_participants" ADD CONSTRAINT "vr_competition_participants_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vr_competition_participants" ADD CONSTRAINT "vr_competition_participants_competition_id_vr_competitions_id_f" FOREIGN KEY ("competition_id") REFERENCES "public"."vr_competitions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_tutoring_sessions" ADD CONSTRAINT "ai_tutoring_sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "degree_audits" ADD CONSTRAINT "degree_audits_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "degree_audits" ADD CONSTRAINT "degree_audits_degree_plan_id_student_degree_plans_id_fk" FOREIGN KEY ("degree_plan_id") REFERENCES "public"."student_degree_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recruitment_matches" ADD CONSTRAINT "recruitment_matches_talent_profile_id_talent_profiles_id_fk" FOREIGN KEY ("talent_profile_id") REFERENCES "public"."talent_profiles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recruitment_matches" ADD CONSTRAINT "recruitment_matches_corporate_partner_id_corporate_partners_id_" FOREIGN KEY ("corporate_partner_id") REFERENCES "public"."corporate_partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "oauth_providers" ADD CONSTRAINT "oauth_providers_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "course_demand_analytics" ADD CONSTRAINT "course_demand_analytics_course_id_courses_id_fk" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "student_degree_plans" ADD CONSTRAINT "student_degree_plans_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "student_degree_plans" ADD CONSTRAINT "student_degree_plans_degree_program_id_degree_programs_id_fk" FOREIGN KEY ("degree_program_id") REFERENCES "public"."degree_programs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "degree_programs" ADD CONSTRAINT "degree_programs_university_id_university_partners_id_fk" FOREIGN KEY ("university_id") REFERENCES "public"."university_partners"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "planned_courses" ADD CONSTRAINT "planned_courses_degree_plan_id_student_degree_plans_id_fk" FOREIGN KEY ("degree_plan_id") REFERENCES "public"."student_degree_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "planned_courses" ADD CONSTRAINT "planned_courses_course_id_courses_id_fk" FOREIGN KEY ("course_id") REFERENCES "public"."courses"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_onboarding" ADD CONSTRAINT "user_onboarding_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assessment_responses" ADD CONSTRAINT "assessment_responses_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assessment_responses" ADD CONSTRAINT "assessment_responses_question_id_question_bank_id_fk" FOREIGN KEY ("question_id") REFERENCES "public"."question_bank"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "assessment_responses" ADD CONSTRAINT "assessment_responses_session_id_ai_tutoring_sessions_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."ai_tutoring_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "skill_recommendations" ADD CONSTRAINT "skill_recommendations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "exercise_attempts" ADD CONSTRAINT "exercise_attempts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "exercise_attempts" ADD CONSTRAINT "exercise_attempts_exercise_id_practice_exercises_id_fk" FOREIGN KEY ("exercise_id") REFERENCES "public"."practice_exercises"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "question_bank" ADD CONSTRAINT "question_bank_module_id_curriculum_modules_id_fk" FOREIGN KEY ("module_id") REFERENCES "public"."curriculum_modules"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "curriculum_modules" ADD CONSTRAINT "curriculum_modules_track_id_industry_tracks_id_fk" FOREIGN KEY ("track_id") REFERENCES "public"."industry_tracks"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "practice_exercises" ADD CONSTRAINT "practice_exercises_module_id_curriculum_modules_id_fk" FOREIGN KEY ("module_id") REFERENCES "public"."curriculum_modules"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "learning_pathways" ADD CONSTRAINT "learning_pathways_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "learning_pathways" ADD CONSTRAINT "learning_pathways_track_id_industry_tracks_id_fk" FOREIGN KEY ("track_id") REFERENCES "public"."industry_tracks"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "learning_pathways" ADD CONSTRAINT "learning_pathways_current_module_curriculum_modules_id_fk" FOREIGN KEY ("current_module") REFERENCES "public"."curriculum_modules"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "video_lessons" ADD CONSTRAINT "video_lessons_module_id_curriculum_modules_id_fk" FOREIGN KEY ("module_id") REFERENCES "public"."curriculum_modules"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "video_progress" ADD CONSTRAINT "video_progress_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "video_progress" ADD CONSTRAINT "video_progress_video_id_video_lessons_id_fk" FOREIGN KEY ("video_id") REFERENCES "public"."video_lessons"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_mentor_sessions" ADD CONSTRAINT "ai_mentor_sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_learning_data" ADD CONSTRAINT "ai_learning_data_source_user_id_users_id_fk" FOREIGN KEY ("source_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_learning_data" ADD CONSTRAINT "ai_learning_data_source_session_id_live_testing_sessions_id_fk" FOREIGN KEY ("source_session_id") REFERENCES "public"."live_testing_sessions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "live_testing_sessions" ADD CONSTRAINT "live_testing_sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_behavior_tracking" ADD CONSTRAINT "user_behavior_tracking_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "achievement_progress" ADD CONSTRAINT "achievement_progress_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "achievement_progress" ADD CONSTRAINT "achievement_progress_badge_id_achievement_badges_id_fk" FOREIGN KEY ("badge_id") REFERENCES "public"."achievement_badges"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_badges" ADD CONSTRAINT "user_badges_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_badges" ADD CONSTRAINT "user_badges_badge_id_achievement_badges_id_fk" FOREIGN KEY ("badge_id") REFERENCES "public"."achievement_badges"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "learning_hints" ADD CONSTRAINT "learning_hints_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hint_effectiveness" ADD CONSTRAINT "hint_effectiveness_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hint_effectiveness" ADD CONSTRAINT "hint_effectiveness_hint_id_learning_hints_id_fk" FOREIGN KEY ("hint_id") REFERENCES "public"."learning_hints"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_session_id_chat_sessions_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."chat_sessions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_sessions" ADD CONSTRAINT "chat_sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_observations" ADD CONSTRAINT "staff_observations_staff_id_users_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_observations" ADD CONSTRAINT "staff_observations_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_student_assignments" ADD CONSTRAINT "staff_student_assignments_staff_id_users_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_student_assignments" ADD CONSTRAINT "staff_student_assignments_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_student_assignments" ADD CONSTRAINT "staff_student_assignments_assigned_by_users_id_fk" FOREIGN KEY ("assigned_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "student_progress_analytics" ADD CONSTRAINT "student_progress_analytics_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_question_responses" ADD CONSTRAINT "custom_question_responses_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_question_responses" ADD CONSTRAINT "custom_question_responses_custom_question_id_custom_questions_i" FOREIGN KEY ("custom_question_id") REFERENCES "public"."custom_questions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_nodes" ADD CONSTRAINT "knowledge_nodes_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ai_question_sessions" ADD CONSTRAINT "ai_question_sessions_staff_id_users_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_questions" ADD CONSTRAINT "custom_questions_staff_id_users_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_questions" ADD CONSTRAINT "custom_questions_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "custom_questions" ADD CONSTRAINT "custom_questions_created_from_assessment_id_assessments_id_fk" FOREIGN KEY ("created_from_assessment_id") REFERENCES "public"."assessments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "question_assignments" ADD CONSTRAINT "question_assignments_custom_question_id_custom_questions_id_fk" FOREIGN KEY ("custom_question_id") REFERENCES "public"."custom_questions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "question_assignments" ADD CONSTRAINT "question_assignments_student_id_users_id_fk" FOREIGN KEY ("student_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "question_assignments" ADD CONSTRAINT "question_assignments_staff_id_users_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_connections" ADD CONSTRAINT "knowledge_connections_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_connections" ADD CONSTRAINT "knowledge_connections_from_node_id_knowledge_nodes_id_fk" FOREIGN KEY ("from_node_id") REFERENCES "public"."knowledge_nodes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_connections" ADD CONSTRAINT "knowledge_connections_to_node_id_knowledge_nodes_id_fk" FOREIGN KEY ("to_node_id") REFERENCES "public"."knowledge_nodes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "knowledge_visualizations" ADD CONSTRAINT "knowledge_visualizations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "IDX_session_expire" ON "sessions" USING btree ("expire" timestamp_ops);--> statement-breakpoint
CREATE INDEX "idx_achievement_progress_badge" ON "achievement_progress" USING btree ("badge_id" text_ops);--> statement-breakpoint
CREATE INDEX "idx_achievement_progress_user" ON "achievement_progress" USING btree ("user_id" text_ops);--> statement-breakpoint
CREATE INDEX "idx_user_badges_badge_id" ON "user_badges" USING btree ("badge_id" text_ops);--> statement-breakpoint
CREATE INDEX "idx_user_badges_user_id" ON "user_badges" USING btree ("user_id" text_ops);
*/