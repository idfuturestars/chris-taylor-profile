import { relations } from "drizzle-orm/relations";
import { users, assessments, documents, aiConversations, learningPaths, studyGroups, studyGroupMembers, talentProfiles, universityApplications, universityPartners, vrCompetitionParticipants, vrCompetitions, aiTutoringSessions, degreeAudits, studentDegreePlans, recruitmentMatches, corporatePartners, oauthProviders, courses, courseDemandAnalytics, degreePrograms, plannedCourses, userOnboarding, assessmentResponses, questionBank, skillRecommendations, exerciseAttempts, practiceExercises, curriculumModules, industryTracks, learningPathways, videoLessons, videoProgress, aiMentorSessions, aiLearningData, liveTestingSessions, userBehaviorTracking, achievementProgress, achievementBadges, userBadges, learningHints, hintEffectiveness, chatSessions, chatMessages, staffObservations, staffStudentAssignments, studentProgressAnalytics, customQuestionResponses, customQuestions, knowledgeNodes, aiQuestionSessions, questionAssignments, knowledgeConnections, knowledgeVisualizations } from "./schema";

export const assessmentsRelations = relations(assessments, ({one, many}) => ({
	user: one(users, {
		fields: [assessments.userId],
		references: [users.id]
	}),
	customQuestions: many(customQuestions),
}));

export const usersRelations = relations(users, ({many}) => ({
	assessments: many(assessments),
	documents: many(documents),
	aiConversations: many(aiConversations),
	learningPaths: many(learningPaths),
	studyGroups: many(studyGroups),
	studyGroupMembers: many(studyGroupMembers),
	talentProfiles: many(talentProfiles),
	universityApplications: many(universityApplications),
	vrCompetitionParticipants: many(vrCompetitionParticipants),
	aiTutoringSessions: many(aiTutoringSessions),
	degreeAudits: many(degreeAudits),
	oauthProviders: many(oauthProviders),
	studentDegreePlans: many(studentDegreePlans),
	userOnboardings: many(userOnboarding),
	assessmentResponses: many(assessmentResponses),
	skillRecommendations: many(skillRecommendations),
	exerciseAttempts: many(exerciseAttempts),
	learningPathways: many(learningPathways),
	videoProgresses: many(videoProgress),
	aiMentorSessions: many(aiMentorSessions),
	aiLearningData: many(aiLearningData),
	liveTestingSessions: many(liveTestingSessions),
	userBehaviorTrackings: many(userBehaviorTracking),
	achievementProgresses: many(achievementProgress),
	userBadges: many(userBadges),
	learningHints: many(learningHints),
	hintEffectivenesses: many(hintEffectiveness),
	chatSessions: many(chatSessions),
	staffObservations_staffId: many(staffObservations, {
		relationName: "staffObservations_staffId_users_id"
	}),
	staffObservations_studentId: many(staffObservations, {
		relationName: "staffObservations_studentId_users_id"
	}),
	staffStudentAssignments_staffId: many(staffStudentAssignments, {
		relationName: "staffStudentAssignments_staffId_users_id"
	}),
	staffStudentAssignments_studentId: many(staffStudentAssignments, {
		relationName: "staffStudentAssignments_studentId_users_id"
	}),
	staffStudentAssignments_assignedBy: many(staffStudentAssignments, {
		relationName: "staffStudentAssignments_assignedBy_users_id"
	}),
	studentProgressAnalytics: many(studentProgressAnalytics),
	customQuestionResponses: many(customQuestionResponses),
	knowledgeNodes: many(knowledgeNodes),
	aiQuestionSessions: many(aiQuestionSessions),
	customQuestions_staffId: many(customQuestions, {
		relationName: "customQuestions_staffId_users_id"
	}),
	customQuestions_studentId: many(customQuestions, {
		relationName: "customQuestions_studentId_users_id"
	}),
	questionAssignments_studentId: many(questionAssignments, {
		relationName: "questionAssignments_studentId_users_id"
	}),
	questionAssignments_staffId: many(questionAssignments, {
		relationName: "questionAssignments_staffId_users_id"
	}),
	knowledgeConnections: many(knowledgeConnections),
	knowledgeVisualizations: many(knowledgeVisualizations),
}));

export const documentsRelations = relations(documents, ({one}) => ({
	user: one(users, {
		fields: [documents.userId],
		references: [users.id]
	}),
}));

export const aiConversationsRelations = relations(aiConversations, ({one}) => ({
	user: one(users, {
		fields: [aiConversations.userId],
		references: [users.id]
	}),
}));

export const learningPathsRelations = relations(learningPaths, ({one}) => ({
	user: one(users, {
		fields: [learningPaths.userId],
		references: [users.id]
	}),
}));

export const studyGroupsRelations = relations(studyGroups, ({one, many}) => ({
	user: one(users, {
		fields: [studyGroups.createdBy],
		references: [users.id]
	}),
	studyGroupMembers: many(studyGroupMembers),
}));

export const studyGroupMembersRelations = relations(studyGroupMembers, ({one}) => ({
	studyGroup: one(studyGroups, {
		fields: [studyGroupMembers.groupId],
		references: [studyGroups.id]
	}),
	user: one(users, {
		fields: [studyGroupMembers.userId],
		references: [users.id]
	}),
}));

export const talentProfilesRelations = relations(talentProfiles, ({one, many}) => ({
	user: one(users, {
		fields: [talentProfiles.userId],
		references: [users.id]
	}),
	recruitmentMatches: many(recruitmentMatches),
}));

export const universityApplicationsRelations = relations(universityApplications, ({one}) => ({
	user: one(users, {
		fields: [universityApplications.userId],
		references: [users.id]
	}),
	universityPartner: one(universityPartners, {
		fields: [universityApplications.universityId],
		references: [universityPartners.id]
	}),
}));

export const universityPartnersRelations = relations(universityPartners, ({many}) => ({
	universityApplications: many(universityApplications),
	degreePrograms: many(degreePrograms),
}));

export const vrCompetitionParticipantsRelations = relations(vrCompetitionParticipants, ({one}) => ({
	user: one(users, {
		fields: [vrCompetitionParticipants.userId],
		references: [users.id]
	}),
	vrCompetition: one(vrCompetitions, {
		fields: [vrCompetitionParticipants.competitionId],
		references: [vrCompetitions.id]
	}),
}));

export const vrCompetitionsRelations = relations(vrCompetitions, ({many}) => ({
	vrCompetitionParticipants: many(vrCompetitionParticipants),
}));

export const aiTutoringSessionsRelations = relations(aiTutoringSessions, ({one, many}) => ({
	user: one(users, {
		fields: [aiTutoringSessions.userId],
		references: [users.id]
	}),
	assessmentResponses: many(assessmentResponses),
}));

export const degreeAuditsRelations = relations(degreeAudits, ({one}) => ({
	user: one(users, {
		fields: [degreeAudits.userId],
		references: [users.id]
	}),
	studentDegreePlan: one(studentDegreePlans, {
		fields: [degreeAudits.degreePlanId],
		references: [studentDegreePlans.id]
	}),
}));

export const studentDegreePlansRelations = relations(studentDegreePlans, ({one, many}) => ({
	degreeAudits: many(degreeAudits),
	user: one(users, {
		fields: [studentDegreePlans.userId],
		references: [users.id]
	}),
	degreeProgram: one(degreePrograms, {
		fields: [studentDegreePlans.degreeProgramId],
		references: [degreePrograms.id]
	}),
	plannedCourses: many(plannedCourses),
}));

export const recruitmentMatchesRelations = relations(recruitmentMatches, ({one}) => ({
	talentProfile: one(talentProfiles, {
		fields: [recruitmentMatches.talentProfileId],
		references: [talentProfiles.id]
	}),
	corporatePartner: one(corporatePartners, {
		fields: [recruitmentMatches.corporatePartnerId],
		references: [corporatePartners.id]
	}),
}));

export const corporatePartnersRelations = relations(corporatePartners, ({many}) => ({
	recruitmentMatches: many(recruitmentMatches),
}));

export const oauthProvidersRelations = relations(oauthProviders, ({one}) => ({
	user: one(users, {
		fields: [oauthProviders.userId],
		references: [users.id]
	}),
}));

export const courseDemandAnalyticsRelations = relations(courseDemandAnalytics, ({one}) => ({
	course: one(courses, {
		fields: [courseDemandAnalytics.courseId],
		references: [courses.id]
	}),
}));

export const coursesRelations = relations(courses, ({many}) => ({
	courseDemandAnalytics: many(courseDemandAnalytics),
	plannedCourses: many(plannedCourses),
}));

export const degreeProgramsRelations = relations(degreePrograms, ({one, many}) => ({
	studentDegreePlans: many(studentDegreePlans),
	universityPartner: one(universityPartners, {
		fields: [degreePrograms.universityId],
		references: [universityPartners.id]
	}),
}));

export const plannedCoursesRelations = relations(plannedCourses, ({one}) => ({
	studentDegreePlan: one(studentDegreePlans, {
		fields: [plannedCourses.degreePlanId],
		references: [studentDegreePlans.id]
	}),
	course: one(courses, {
		fields: [plannedCourses.courseId],
		references: [courses.id]
	}),
}));

export const userOnboardingRelations = relations(userOnboarding, ({one}) => ({
	user: one(users, {
		fields: [userOnboarding.userId],
		references: [users.id]
	}),
}));

export const assessmentResponsesRelations = relations(assessmentResponses, ({one}) => ({
	user: one(users, {
		fields: [assessmentResponses.userId],
		references: [users.id]
	}),
	questionBank: one(questionBank, {
		fields: [assessmentResponses.questionId],
		references: [questionBank.id]
	}),
	aiTutoringSession: one(aiTutoringSessions, {
		fields: [assessmentResponses.sessionId],
		references: [aiTutoringSessions.id]
	}),
}));

export const questionBankRelations = relations(questionBank, ({one, many}) => ({
	assessmentResponses: many(assessmentResponses),
	curriculumModule: one(curriculumModules, {
		fields: [questionBank.moduleId],
		references: [curriculumModules.id]
	}),
}));

export const skillRecommendationsRelations = relations(skillRecommendations, ({one}) => ({
	user: one(users, {
		fields: [skillRecommendations.userId],
		references: [users.id]
	}),
}));

export const exerciseAttemptsRelations = relations(exerciseAttempts, ({one}) => ({
	user: one(users, {
		fields: [exerciseAttempts.userId],
		references: [users.id]
	}),
	practiceExercise: one(practiceExercises, {
		fields: [exerciseAttempts.exerciseId],
		references: [practiceExercises.id]
	}),
}));

export const practiceExercisesRelations = relations(practiceExercises, ({one, many}) => ({
	exerciseAttempts: many(exerciseAttempts),
	curriculumModule: one(curriculumModules, {
		fields: [practiceExercises.moduleId],
		references: [curriculumModules.id]
	}),
}));

export const curriculumModulesRelations = relations(curriculumModules, ({one, many}) => ({
	questionBanks: many(questionBank),
	industryTrack: one(industryTracks, {
		fields: [curriculumModules.trackId],
		references: [industryTracks.id]
	}),
	practiceExercises: many(practiceExercises),
	learningPathways: many(learningPathways),
	videoLessons: many(videoLessons),
}));

export const industryTracksRelations = relations(industryTracks, ({many}) => ({
	curriculumModules: many(curriculumModules),
	learningPathways: many(learningPathways),
}));

export const learningPathwaysRelations = relations(learningPathways, ({one}) => ({
	user: one(users, {
		fields: [learningPathways.userId],
		references: [users.id]
	}),
	industryTrack: one(industryTracks, {
		fields: [learningPathways.trackId],
		references: [industryTracks.id]
	}),
	curriculumModule: one(curriculumModules, {
		fields: [learningPathways.currentModule],
		references: [curriculumModules.id]
	}),
}));

export const videoLessonsRelations = relations(videoLessons, ({one, many}) => ({
	curriculumModule: one(curriculumModules, {
		fields: [videoLessons.moduleId],
		references: [curriculumModules.id]
	}),
	videoProgresses: many(videoProgress),
}));

export const videoProgressRelations = relations(videoProgress, ({one}) => ({
	user: one(users, {
		fields: [videoProgress.userId],
		references: [users.id]
	}),
	videoLesson: one(videoLessons, {
		fields: [videoProgress.videoId],
		references: [videoLessons.id]
	}),
}));

export const aiMentorSessionsRelations = relations(aiMentorSessions, ({one}) => ({
	user: one(users, {
		fields: [aiMentorSessions.userId],
		references: [users.id]
	}),
}));

export const aiLearningDataRelations = relations(aiLearningData, ({one}) => ({
	user: one(users, {
		fields: [aiLearningData.sourceUserId],
		references: [users.id]
	}),
	liveTestingSession: one(liveTestingSessions, {
		fields: [aiLearningData.sourceSessionId],
		references: [liveTestingSessions.id]
	}),
}));

export const liveTestingSessionsRelations = relations(liveTestingSessions, ({one, many}) => ({
	aiLearningData: many(aiLearningData),
	user: one(users, {
		fields: [liveTestingSessions.userId],
		references: [users.id]
	}),
}));

export const userBehaviorTrackingRelations = relations(userBehaviorTracking, ({one}) => ({
	user: one(users, {
		fields: [userBehaviorTracking.userId],
		references: [users.id]
	}),
}));

export const achievementProgressRelations = relations(achievementProgress, ({one}) => ({
	user: one(users, {
		fields: [achievementProgress.userId],
		references: [users.id]
	}),
	achievementBadge: one(achievementBadges, {
		fields: [achievementProgress.badgeId],
		references: [achievementBadges.id]
	}),
}));

export const achievementBadgesRelations = relations(achievementBadges, ({many}) => ({
	achievementProgresses: many(achievementProgress),
	userBadges: many(userBadges),
}));

export const userBadgesRelations = relations(userBadges, ({one}) => ({
	user: one(users, {
		fields: [userBadges.userId],
		references: [users.id]
	}),
	achievementBadge: one(achievementBadges, {
		fields: [userBadges.badgeId],
		references: [achievementBadges.id]
	}),
}));

export const learningHintsRelations = relations(learningHints, ({one, many}) => ({
	user: one(users, {
		fields: [learningHints.userId],
		references: [users.id]
	}),
	hintEffectivenesses: many(hintEffectiveness),
}));

export const hintEffectivenessRelations = relations(hintEffectiveness, ({one}) => ({
	user: one(users, {
		fields: [hintEffectiveness.userId],
		references: [users.id]
	}),
	learningHint: one(learningHints, {
		fields: [hintEffectiveness.hintId],
		references: [learningHints.id]
	}),
}));

export const chatMessagesRelations = relations(chatMessages, ({one}) => ({
	chatSession: one(chatSessions, {
		fields: [chatMessages.sessionId],
		references: [chatSessions.id]
	}),
}));

export const chatSessionsRelations = relations(chatSessions, ({one, many}) => ({
	chatMessages: many(chatMessages),
	user: one(users, {
		fields: [chatSessions.userId],
		references: [users.id]
	}),
}));

export const staffObservationsRelations = relations(staffObservations, ({one}) => ({
	user_staffId: one(users, {
		fields: [staffObservations.staffId],
		references: [users.id],
		relationName: "staffObservations_staffId_users_id"
	}),
	user_studentId: one(users, {
		fields: [staffObservations.studentId],
		references: [users.id],
		relationName: "staffObservations_studentId_users_id"
	}),
}));

export const staffStudentAssignmentsRelations = relations(staffStudentAssignments, ({one}) => ({
	user_staffId: one(users, {
		fields: [staffStudentAssignments.staffId],
		references: [users.id],
		relationName: "staffStudentAssignments_staffId_users_id"
	}),
	user_studentId: one(users, {
		fields: [staffStudentAssignments.studentId],
		references: [users.id],
		relationName: "staffStudentAssignments_studentId_users_id"
	}),
	user_assignedBy: one(users, {
		fields: [staffStudentAssignments.assignedBy],
		references: [users.id],
		relationName: "staffStudentAssignments_assignedBy_users_id"
	}),
}));

export const studentProgressAnalyticsRelations = relations(studentProgressAnalytics, ({one}) => ({
	user: one(users, {
		fields: [studentProgressAnalytics.studentId],
		references: [users.id]
	}),
}));

export const customQuestionResponsesRelations = relations(customQuestionResponses, ({one}) => ({
	user: one(users, {
		fields: [customQuestionResponses.studentId],
		references: [users.id]
	}),
	customQuestion: one(customQuestions, {
		fields: [customQuestionResponses.customQuestionId],
		references: [customQuestions.id]
	}),
}));

export const customQuestionsRelations = relations(customQuestions, ({one, many}) => ({
	customQuestionResponses: many(customQuestionResponses),
	user_staffId: one(users, {
		fields: [customQuestions.staffId],
		references: [users.id],
		relationName: "customQuestions_staffId_users_id"
	}),
	user_studentId: one(users, {
		fields: [customQuestions.studentId],
		references: [users.id],
		relationName: "customQuestions_studentId_users_id"
	}),
	assessment: one(assessments, {
		fields: [customQuestions.createdFromAssessmentId],
		references: [assessments.id]
	}),
	questionAssignments: many(questionAssignments),
}));

export const knowledgeNodesRelations = relations(knowledgeNodes, ({one, many}) => ({
	user: one(users, {
		fields: [knowledgeNodes.userId],
		references: [users.id]
	}),
	knowledgeConnections_fromNodeId: many(knowledgeConnections, {
		relationName: "knowledgeConnections_fromNodeId_knowledgeNodes_id"
	}),
	knowledgeConnections_toNodeId: many(knowledgeConnections, {
		relationName: "knowledgeConnections_toNodeId_knowledgeNodes_id"
	}),
}));

export const aiQuestionSessionsRelations = relations(aiQuestionSessions, ({one}) => ({
	user: one(users, {
		fields: [aiQuestionSessions.staffId],
		references: [users.id]
	}),
}));

export const questionAssignmentsRelations = relations(questionAssignments, ({one}) => ({
	customQuestion: one(customQuestions, {
		fields: [questionAssignments.customQuestionId],
		references: [customQuestions.id]
	}),
	user_studentId: one(users, {
		fields: [questionAssignments.studentId],
		references: [users.id],
		relationName: "questionAssignments_studentId_users_id"
	}),
	user_staffId: one(users, {
		fields: [questionAssignments.staffId],
		references: [users.id],
		relationName: "questionAssignments_staffId_users_id"
	}),
}));

export const knowledgeConnectionsRelations = relations(knowledgeConnections, ({one}) => ({
	user: one(users, {
		fields: [knowledgeConnections.userId],
		references: [users.id]
	}),
	knowledgeNode_fromNodeId: one(knowledgeNodes, {
		fields: [knowledgeConnections.fromNodeId],
		references: [knowledgeNodes.id],
		relationName: "knowledgeConnections_fromNodeId_knowledgeNodes_id"
	}),
	knowledgeNode_toNodeId: one(knowledgeNodes, {
		fields: [knowledgeConnections.toNodeId],
		references: [knowledgeNodes.id],
		relationName: "knowledgeConnections_toNodeId_knowledgeNodes_id"
	}),
}));

export const knowledgeVisualizationsRelations = relations(knowledgeVisualizations, ({one}) => ({
	user: one(users, {
		fields: [knowledgeVisualizations.userId],
		references: [users.id]
	}),
}));