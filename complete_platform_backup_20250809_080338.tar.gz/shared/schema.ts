import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").unique(),
  email: text("email").notNull().unique(),
  password: text("password"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  currentLevel: text("current_level").default("Foundation"),
  assessmentProgress: integer("assessment_progress").default(0),
  learningStreak: integer("learning_streak").default(0),
  aiInteractions: integer("ai_interactions").default(0),
  // Multi-provider authentication fields
  authProvider: text("auth_provider").default("local"), // local, google, apple, replit
  providerId: text("provider_id"), // OAuth provider user ID
  linkedProviders: text("linked_providers").array().default(sql`'{}'::text[]`), // Array of linked OAuth providers
  emailVerified: boolean("email_verified").default(false),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

// OAuth provider connections table for multi-provider support
export const oauthProviders = pgTable("oauth_providers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), // google, apple, replit
  providerId: text("provider_id").notNull(),
  email: text("email"),
  name: text("name"),
  profileImageUrl: text("profile_image_url"),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  tokenExpiry: timestamp("token_expiry"),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const assessments = pgTable("assessments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // 'core_math', 'applied_reasoning', 'ai_concepts'
  score: decimal("score", { precision: 5, scale: 2 }),
  progress: integer("progress").default(0),
  completed: boolean("completed").default(false),
  data: jsonb("data"), // Store assessment responses and detailed results
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const learningPaths = pgTable("learning_paths", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  pathType: text("path_type").notNull(), // 'foundation', 'immersion', 'mastery'
  currentStep: integer("current_step").default(0),
  progress: integer("progress").default(0),
  completed: boolean("completed").default(false),
  data: jsonb("data"), // Store pathway-specific progress and content
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const userOnboarding = pgTable("user_onboarding", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  // Primary Educational Level Classification (captured first)
  educationalLevel: text("educational_level").notNull(), // k-12, college, masters, phd, phd+, professional
  gradeLevel: text("grade_level"), // K, 1, 2, ..., 12 (for K-12 students)
  age: integer("age"),
  pathwayType: text("pathway_type").notNull(), // "student" or "career"
  
  // Student-focused information (K-12)
  parentEmail: text("parent_email"), // Required for K-12 students
  schoolName: text("school_name"),
  preferredSubjects: text("preferred_subjects").array(),
  
  personalInfo: jsonb("personal_info").notNull(),
  educationalBackground: jsonb("educational_background").notNull(),
  careerGoals: jsonb("career_goals").notNull(),
  learningPreferences: jsonb("learning_preferences").notNull(),
  assessmentReadiness: jsonb("assessment_readiness").notNull(),
  completed: boolean("completed").default(true),
  recommendedTrack: text("recommended_track"),
  estimatedEiqRange: text("estimated_eiq_range"),
  
  // Interactive AI Mentor fields
  mentorPersonality: text("mentor_personality").default("supportive"), // supportive, challenging, friendly, professional
  aiConversationHistory: jsonb("ai_conversation_history"), // Store mentor conversation
  personalizedInsights: jsonb("personalized_insights"), // AI-generated insights about user
  adaptiveSuggestions: jsonb("adaptive_suggestions"), // Real-time AI recommendations
  engagementLevel: integer("engagement_level").default(5), // 1-10 scale
  mentorFeedbackRating: integer("mentor_feedback_rating"), // User's rating of AI mentor
  
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

// AI Mentor Sessions - track detailed interactions
export const aiMentorSessions = pgTable("ai_mentor_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  sessionType: text("session_type").notNull(), // onboarding, assessment_prep, career_guidance, study_planning
  startedAt: timestamp("started_at").default(sql`now()`),
  completedAt: timestamp("completed_at"),
  conversationLog: jsonb("conversation_log").notNull(), // Full conversation with AI mentor
  insights: jsonb("insights"), // AI-generated insights from session
  actionItems: jsonb("action_items"), // Suggested next steps
  userSatisfaction: integer("user_satisfaction"), // 1-5 rating
  mentorPersonality: text("mentor_personality").notNull(),
  aiProvider: text("ai_provider").default("anthropic"), // Which AI was used
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size"),
  status: text("status").default("processing"), // 'processing', 'completed', 'failed'
  extractedData: jsonb("extracted_data"), // OCR and analysis results
  uploadedAt: timestamp("uploaded_at").default(sql`now()`)
});

export const aiConversations = pgTable("ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  messages: jsonb("messages").notNull(), // Array of conversation messages
  provider: text("provider").notNull(), // 'openai', 'anthropic', 'gemini'
  sessionId: varchar("session_id"),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const studyGroups = pgTable("study_groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  topic: text("topic").notNull(),
  maxMembers: integer("max_members").default(10),
  isActive: boolean("is_active").default(true),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const studyGroupMembers = pgTable("study_group_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => studyGroups.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: text("role").default("member"), // 'admin', 'member'
  joinedAt: timestamp("joined_at").default(sql`now()`)
});

export const courseFeed = pgTable("course_feed", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(), // 'lesson', 'practice', 'discussion'
  category: text("category").notNull(), // 'python', 'math', 'ai_ethics'
  priority: integer("priority").default(0),
  isActive: boolean("is_active").default(true),
  publishedAt: timestamp("published_at").default(sql`now()`)
});

// K-12 Industry Titan Tracks
export const industryTracks = pgTable("industry_tracks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // 'Jobs/Cook', 'Page/Pichai', 'Gates/Ballmer', 'Zuck/Huang', 'Ellison/Catz', 'Buffet/Apfel'
  displayName: text("display_name").notNull(),
  description: text("description").notNull(),
  focusAreas: jsonb("focus_areas").notNull(), // Array of key focus areas
  ageRanges: jsonb("age_ranges").notNull(), // Supported age ranges and grade levels
  prerequisites: jsonb("prerequisites"), // Required skills/knowledge
  learningObjectives: jsonb("learning_objectives").notNull(),
  industryPartners: jsonb("industry_partners"), // Companies and industry connections
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// K-12 Curriculum Modules
export const curriculumModules = pgTable("curriculum_modules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackId: varchar("track_id").notNull().references(() => industryTracks.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  gradeLevel: text("grade_level").notNull(), // 'K-2', '3-5', '6-8', '9-12', 'adult'
  subject: text("subject").notNull(), // 'mathematics', 'science', 'programming', 'logic', 'ai_concepts'
  difficulty: text("difficulty").notNull(), // 'foundation', 'intermediate', 'advanced', 'mastery'
  estimatedDuration: integer("estimated_duration").notNull(), // in minutes
  prerequisites: jsonb("prerequisites"),
  learningObjectives: jsonb("learning_objectives").notNull(),
  assessmentCriteria: jsonb("assessment_criteria").notNull(),
  contentStructure: jsonb("content_structure").notNull(), // Video lessons, exercises, projects
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Question Bank for Adaptive Assessments
export const questionBank = pgTable("question_bank", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  moduleId: varchar("module_id").notNull().references(() => curriculumModules.id),
  questionType: text("question_type").notNull(), // 'multiple_choice', 'open_ended', 'coding', 'visual'
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  difficulty: decimal("difficulty", { precision: 3, scale: 2 }).notNull(), // 1.0 to 5.0
  questionText: text("question_text").notNull(),
  questionData: jsonb("question_data").notNull(), // Options, correct answers, code templates
  explanation: text("explanation").notNull(),
  hints: jsonb("hints"), // Progressive hint system
  tags: jsonb("tags"), // Categorization tags
  aiGenerated: boolean("ai_generated").default(false),
  validatedBy: varchar("validated_by"), // Educator who validated the question
  usageCount: integer("usage_count").default(0),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }),
  averageTime: integer("average_time"), // in seconds
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Advanced AI Tutoring & EiQ Coaching
export const aiTutoringSessions = pgTable("ai_tutoring_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  sessionType: text("session_type").notNull(), // 'khan_style_lesson', 'adaptive_practice', 'project_mode', 'diagnostic'
  subject: text("subject").notNull(), // 'mathematics', 'science', 'programming', 'logic', 'ai_concepts'
  gradeLevel: text("grade_level"), // Target grade level
  currentEiQScore: decimal("current_eiq_score", { precision: 5, scale: 2 }),
  targetEiQScore: decimal("target_eiq_score", { precision: 5, scale: 2 }),
  masteryLevel: text("mastery_level").default("attempted"), // 'attempted', 'familiar', 'proficient', 'mastered'
  improvementPlan: jsonb("improvement_plan"), // Personalized coaching plan
  conversationHistory: jsonb("conversation_history").notNull(),
  learningGaps: jsonb("learning_gaps"), // Identified weaknesses and improvement areas
  progressMetrics: jsonb("progress_metrics"), // Session-specific metrics
  hintUsage: jsonb("hint_usage"), // Progressive hint system usage
  aiProvider: text("ai_provider").notNull().default("openai"),
  status: text("status").default("active"), // 'active', 'completed', 'paused'
  sessionDuration: integer("session_duration"), // in minutes
  questionsAnswered: integer("questions_answered").default(0),
  correctAnswers: integer("correct_answers").default(0),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

// Student Assessment Responses
export const assessmentResponses = pgTable("assessment_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  questionId: varchar("question_id").notNull().references(() => questionBank.id),
  sessionId: varchar("session_id").references(() => aiTutoringSessions.id),
  userAnswer: jsonb("user_answer").notNull(),
  isCorrect: boolean("is_correct").notNull(),
  timeSpent: integer("time_spent").notNull(), // in seconds
  hintsUsed: integer("hints_used").default(0),
  attemptsCount: integer("attempts_count").default(1),
  masteryLevel: text("mastery_level"), // Student's mastery after this response
  aiExplanation: text("ai_explanation"), // AI-generated explanation
  responseDate: timestamp("response_date").default(sql`now()`)
});

// Adaptive Learning Pathways
export const learningPathways = pgTable("learning_pathways", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  trackId: varchar("track_id").notNull().references(() => industryTracks.id),
  pathwayType: text("pathway_type").notNull(), // 'foundation', 'immersion', 'mastery'
  currentModule: varchar("current_module").references(() => curriculumModules.id),
  completedModules: jsonb("completed_modules").default(sql`'[]'::jsonb`),
  progressMap: jsonb("progress_map").notNull(), // Detailed progress tracking
  adaptiveRecommendations: jsonb("adaptive_recommendations"), // AI-driven next steps
  difficultyProfile: jsonb("difficulty_profile"), // Subject-specific difficulty preferences
  learningStyle: text("learning_style"), // 'visual', 'auditory', 'kinesthetic', 'mixed'
  weeklyGoals: jsonb("weekly_goals"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Video Lessons (Khan Academy Style)
export const videoLessons = pgTable("video_lessons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  moduleId: varchar("module_id").notNull().references(() => curriculumModules.id),
  title: text("title").notNull(),
  description: text("description"),
  videoUrl: text("video_url"), // Link to video content
  duration: integer("duration").notNull(), // in seconds
  transcript: text("transcript"),
  lessonOrder: integer("lesson_order").notNull(),
  prerequisites: jsonb("prerequisites"),
  keyConceptsIntroduced: jsonb("key_concepts_introduced"),
  practiceExercises: jsonb("practice_exercises"), // Associated practice problems
  isInteractive: boolean("is_interactive").default(false),
  interactiveElements: jsonb("interactive_elements"), // Embedded quizzes, simulations
  viewCount: integer("view_count").default(0),
  averageRating: decimal("average_rating", { precision: 3, scale: 2 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Student Video Progress
export const videoProgress = pgTable("video_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  videoId: varchar("video_id").notNull().references(() => videoLessons.id),
  watchedDuration: integer("watched_duration").default(0), // in seconds
  completionPercentage: decimal("completion_percentage", { precision: 5, scale: 2 }).default("0"),
  lastWatchedPosition: integer("last_watched_position").default(0),
  isCompleted: boolean("is_completed").default(false),
  notesCount: integer("notes_count").default(0),
  questionsAsked: integer("questions_asked").default(0),
  userRating: integer("user_rating"), // 1-5 stars
  watchHistory: jsonb("watch_history"), // Detailed viewing patterns
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

// Practice Exercises
export const practiceExercises = pgTable("practice_exercises", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  moduleId: varchar("module_id").notNull().references(() => curriculumModules.id),
  title: text("title").notNull(),
  description: text("description"),
  exerciseType: text("exercise_type").notNull(), // 'drill', 'application', 'project', 'game'
  difficulty: decimal("difficulty", { precision: 3, scale: 2 }).notNull(),
  estimatedTime: integer("estimated_time").notNull(), // in minutes
  instructions: text("instructions").notNull(),
  exerciseData: jsonb("exercise_data").notNull(), // Exercise content and structure
  solutionData: jsonb("solution_data"), // Solutions and rubrics
  hints: jsonb("hints"),
  prerequisites: jsonb("prerequisites"),
  learningObjectives: jsonb("learning_objectives"),
  isAdaptive: boolean("is_adaptive").default(false),
  adaptiveParameters: jsonb("adaptive_parameters"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Student Exercise Attempts
export const exerciseAttempts = pgTable("exercise_attempts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  exerciseId: varchar("exercise_id").notNull().references(() => practiceExercises.id),
  attemptNumber: integer("attempt_number").default(1),
  startTime: timestamp("start_time").default(sql`now()`),
  endTime: timestamp("end_time"),
  timeSpent: integer("time_spent"), // in seconds
  userResponse: jsonb("user_response").notNull(),
  score: decimal("score", { precision: 5, scale: 2 }),
  masteryLevel: text("mastery_level"), // 'attempted', 'familiar', 'proficient', 'mastered'
  feedback: text("feedback"),
  hintsUsed: integer("hints_used").default(0),
  isCompleted: boolean("is_completed").default(false),
  aiAnalysis: jsonb("ai_analysis"), // AI analysis of student work
  createdAt: timestamp("created_at").default(sql`now()`)
});

// VR Competition Environments
export const vrCompetitions = pgTable("vr_competitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  competitionType: text("competition_type").notNull(), // 'global_championship', 'regional_contest', 'practice_battle'
  subject: text("subject").notNull(), // 'mathematics', 'reasoning', 'ai_concepts', 'mixed'
  difficulty: text("difficulty").notNull(), // 'foundation', 'intermediate', 'advanced', 'mastery'
  vrEnvironment: text("vr_environment").notNull(), // 'space_station', 'ancient_library', 'futuristic_lab'
  maxParticipants: integer("max_participants").default(100),
  entryRequirement: decimal("entry_requirement", { precision: 5, scale: 2 }), // Minimum EiQ score
  prizeStructure: jsonb("prize_structure"), // Prize distribution and rewards
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  status: text("status").default("upcoming"), // 'upcoming', 'active', 'completed', 'cancelled'
  leaderboard: jsonb("leaderboard"), // Real-time competition standings
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const vrCompetitionParticipants = pgTable("vr_competition_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  competitionId: varchar("competition_id").notNull().references(() => vrCompetitions.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  entryEiQScore: decimal("entry_eiq_score", { precision: 5, scale: 2 }),
  currentScore: decimal("current_score", { precision: 8, scale: 2 }).default("0"),
  rank: integer("rank"),
  completedChallenges: integer("completed_challenges").default(0),
  totalTimeSpent: integer("total_time_spent").default(0), // in minutes
  vrSessionData: jsonb("vr_session_data"), // VR-specific interaction data
  achievements: jsonb("achievements"), // Competition-specific achievements
  joinedAt: timestamp("joined_at").default(sql`now()`),
  lastActiveAt: timestamp("last_active_at").default(sql`now()`)
});

// Comprehensive Degree Planning System (HighPoint.io Integration)
export const degreePrograms = pgTable("degree_programs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  universityId: varchar("university_id").notNull().references(() => universityPartners.id),
  name: text("name").notNull(), // e.g., "Computer Science BS", "Mathematics PhD"
  degreeType: text("degree_type").notNull(), // 'bachelor', 'master', 'phd', 'certificate'
  department: text("department").notNull(),
  totalCredits: integer("total_credits").notNull(),
  estimatedDuration: integer("estimated_duration").notNull(), // in semesters
  minEiQScore: decimal("min_eiq_score", { precision: 5, scale: 2 }),
  recommendedEiQScore: decimal("recommended_eiq_score", { precision: 5, scale: 2 }),
  prerequisites: jsonb("prerequisites"), // Course prerequisites and requirements
  coreRequirements: jsonb("core_requirements"), // Required courses with credit hours
  electiveRequirements: jsonb("elective_requirements"), // Elective categories and requirements
  specializations: jsonb("specializations"), // Available specialization tracks
  careerOutcomes: jsonb("career_outcomes"), // Expected career paths and outcomes
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const courses = pgTable("courses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseCode: text("course_code").notNull().unique(), // e.g., "MATH101", "CS202"
  title: text("title").notNull(),
  description: text("description"),
  credits: integer("credits").notNull(),
  department: text("department").notNull(),
  level: text("level").notNull(), // 'undergraduate', 'graduate'
  prerequisites: jsonb("prerequisites"), // Required prerequisite courses
  corequisites: jsonb("corequisites"), // Courses that must be taken concurrently
  difficulty: text("difficulty"), // 'foundation', 'intermediate', 'advanced'
  averageWorkload: integer("average_workload"), // Hours per week
  passRate: decimal("pass_rate", { precision: 5, scale: 2 }), // Historical pass rate
  recommendedEiQScore: decimal("recommended_eiq_score", { precision: 5, scale: 2 }),
  offerings: jsonb("offerings"), // When the course is typically offered (fall/spring/summer)
  maxEnrollment: integer("max_enrollment"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const studentDegreePlans = pgTable("student_degree_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  degreeProgramId: varchar("degree_program_id").notNull().references(() => degreePrograms.id),
  planName: text("plan_name").notNull(), // e.g., "My CS Degree Plan", "Accelerated Path"
  isActive: boolean("is_active").default(true),
  isPrimary: boolean("is_primary").default(false),
  currentGPA: decimal("current_gpa", { precision: 3, scale: 2 }),
  completedCredits: integer("completed_credits").default(0),
  remainingCredits: integer("remaining_credits"),
  projectedGraduationDate: timestamp("projected_graduation_date"),
  actualGraduationDate: timestamp("actual_graduation_date"),
  planStatus: text("plan_status").default("active"), // 'active', 'on_track', 'off_track', 'completed', 'withdrawn'
  riskFactors: jsonb("risk_factors"), // Identified risks to graduation
  interventionRecommendations: jsonb("intervention_recommendations"), // AI-generated recommendations
  eiqBasedRecommendations: jsonb("eiq_based_recommendations"), // EiQ score-based course suggestions
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const plannedCourses = pgTable("planned_courses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  degreePlanId: varchar("degree_plan_id").notNull().references(() => studentDegreePlans.id),
  courseId: varchar("course_id").notNull().references(() => courses.id),
  plannedSemester: text("planned_semester").notNull(), // e.g., "Fall 2024", "Spring 2025"
  plannedYear: integer("planned_year").notNull(),
  semesterOrder: integer("semester_order"), // 1, 2, 3, etc.
  status: text("status").default("planned"), // 'planned', 'enrolled', 'in_progress', 'completed', 'failed', 'withdrawn'
  actualGrade: text("actual_grade"), // 'A', 'B', 'C', etc.
  gradePoints: decimal("grade_points", { precision: 3, scale: 2 }),
  isRequired: boolean("is_required").default(true), // vs elective
  requirementType: text("requirement_type"), // 'core', 'major_elective', 'general_elective', 'prerequisite'
  alternativeCourses: jsonb("alternative_courses"), // Alternative courses that meet the same requirement
  eiqRecommendationScore: decimal("eiq_recommendation_score", { precision: 3, scale: 2 }), // How well this matches student's EiQ
  difficultyPrediction: text("difficulty_prediction"), // AI prediction of difficulty for this student
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const degreeAudits = pgTable("degree_audits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  degreePlanId: varchar("degree_plan_id").notNull().references(() => studentDegreePlans.id),
  auditType: text("audit_type").notNull(), // 'real_time', 'graduation_check', 'what_if'
  completedRequirements: jsonb("completed_requirements"),
  pendingRequirements: jsonb("pending_requirements"),
  missingRequirements: jsonb("missing_requirements"),
  excessCredits: jsonb("excess_credits"), // Credits beyond degree requirements
  substituteCredits: jsonb("substitute_credits"), // Approved course substitutions
  waivedRequirements: jsonb("waived_requirements"), // Waived requirements with justification
  gpaCalculation: jsonb("gpa_calculation"), // Detailed GPA breakdown
  graduationEligibility: text("graduation_eligibility"), // 'eligible', 'pending', 'not_eligible'
  recommendedActions: jsonb("recommended_actions"), // Next steps to stay on track
  runDate: timestamp("run_date").default(sql`now()`),
  auditResults: jsonb("audit_results") // Complete audit results
});

export const courseDemandAnalytics = pgTable("course_demand_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: varchar("course_id").notNull().references(() => courses.id),
  semester: text("semester").notNull(),
  year: integer("year").notNull(),
  plannedEnrollment: integer("planned_enrollment"), // Students who have this in their plan
  actualEnrollment: integer("actual_enrollment"),
  waitlistSize: integer("waitlist_size"),
  demandScore: decimal("demand_score", { precision: 5, scale: 2 }), // Calculated demand metric
  shortageRisk: text("shortage_risk"), // 'low', 'medium', 'high', 'critical'
  recommendedSections: integer("recommended_sections"), // AI recommendation for sections needed
  eiqDrivenDemand: jsonb("eiq_driven_demand"), // Demand based on EiQ score distributions
  generatedAt: timestamp("generated_at").default(sql`now()`)
});

// University Admission System Integration
export const universityPartners = pgTable("university_partners", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: text("country").notNull(),
  ranking: integer("ranking"), // Global university ranking
  logoUrl: text("logo_url"),
  website: text("website"),
  contactEmail: text("contact_email"),
  minEiQScore: decimal("min_eiq_score", { precision: 5, scale: 2 }), // Minimum EiQ for consideration
  preferredEiQScore: decimal("preferred_eiq_score", { precision: 5, scale: 2 }), // Target EiQ for strong candidacy
  programs: jsonb("programs"), // Available programs and their EiQ requirements
  admissionProcess: jsonb("admission_process"), // EiQ integration specifics
  partnershipStatus: text("partnership_status").default("active"), // 'active', 'pending', 'inactive'
  partnershipTier: text("partnership_tier"), // 'premier', 'standard', 'basic'
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const universityApplications = pgTable("university_applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  universityId: varchar("university_id").notNull().references(() => universityPartners.id),
  program: text("program").notNull(),
  applicationEiQScore: decimal("application_eiq_score", { precision: 5, scale: 2 }),
  transcriptAnalysis: jsonb("transcript_analysis"), // AI analysis of uploaded transcripts
  recommendationStatus: text("recommendation_status"), // 'highly_recommended', 'recommended', 'conditional', 'not_recommended'
  applicationData: jsonb("application_data"), // Complete application information
  status: text("status").default("draft"), // 'draft', 'submitted', 'under_review', 'accepted', 'rejected', 'waitlisted'
  submittedAt: timestamp("submitted_at"),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Corporate Partnership Program
export const corporatePartners = pgTable("corporate_partners", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  industry: text("industry").notNull(), // 'technology', 'finance', 'healthcare', 'consulting'
  size: text("size"), // 'startup', 'medium', 'enterprise', 'fortune500'
  logoUrl: text("logo_url"),
  website: text("website"),
  contactEmail: text("contact_email"),
  headquarters: text("headquarters"),
  targetEiQRange: jsonb("target_eiq_range"), // Preferred EiQ score ranges for different roles
  talentRequirements: jsonb("talent_requirements"), // Specific skills and EiQ criteria
  partnershipTier: text("partnership_tier"), // 'premier', 'standard', 'basic'
  partnershipStatus: text("partnership_status").default("active"),
  recruitmentQuota: integer("recruitment_quota"), // Annual hiring targets from platform
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const talentProfile = pgTable("talent_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  currentEiQScore: decimal("current_eiq_score", { precision: 5, scale: 2 }),
  peakEiQScore: decimal("peak_eiq_score", { precision: 5, scale: 2 }),
  skillsProfile: jsonb("skills_profile"), // Detailed breakdown of abilities
  careerInterests: jsonb("career_interests"), // Preferred industries and roles
  availability: text("availability"), // 'immediate', 'graduate_2024', 'graduate_2025', 'flexible'
  resumeData: jsonb("resume_data"), // AI-extracted resume information
  portfolioLinks: jsonb("portfolio_links"),
  isOpenToRecruitment: boolean("is_open_to_recruitment").default(false),
  visibilitySettings: jsonb("visibility_settings"), // Privacy controls
  lastProfileUpdate: timestamp("last_profile_update").default(sql`now()`),
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const recruitmentMatches = pgTable("recruitment_matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  talentProfileId: varchar("talent_profile_id").notNull().references(() => talentProfile.id),
  corporatePartnerId: varchar("corporate_partner_id").notNull().references(() => corporatePartners.id),
  jobTitle: text("job_title").notNull(),
  matchScore: decimal("match_score", { precision: 5, scale: 2 }), // AI-calculated compatibility
  eiqRequirement: decimal("eiq_requirement", { precision: 5, scale: 2 }),
  jobDescription: text("job_description"),
  salary: jsonb("salary"), // Salary range and benefits
  status: text("status").default("matched"), // 'matched', 'contacted', 'interviewing', 'offered', 'hired', 'declined'
  contactedAt: timestamp("contacted_at"),
  createdAt: timestamp("created_at").default(sql`now()`)
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  assessments: many(assessments),
  learningPaths: many(learningPaths),
  documents: many(documents),
  aiConversations: many(aiConversations),
  studyGroupMemberships: many(studyGroupMembers),
  createdStudyGroups: many(studyGroups)
}));

export const assessmentsRelations = relations(assessments, ({ one }) => ({
  user: one(users, {
    fields: [assessments.userId],
    references: [users.id]
  })
}));

export const learningPathsRelations = relations(learningPaths, ({ one }) => ({
  user: one(users, {
    fields: [learningPaths.userId],
    references: [users.id]
  })
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  user: one(users, {
    fields: [documents.userId],
    references: [users.id]
  })
}));

export const aiConversationsRelations = relations(aiConversations, ({ one }) => ({
  user: one(users, {
    fields: [aiConversations.userId],
    references: [users.id]
  })
}));

export const studyGroupsRelations = relations(studyGroups, ({ one, many }) => ({
  creator: one(users, {
    fields: [studyGroups.createdBy],
    references: [users.id]
  }),
  members: many(studyGroupMembers)
}));

export const studyGroupMembersRelations = relations(studyGroupMembers, ({ one }) => ({
  group: one(studyGroups, {
    fields: [studyGroupMembers.groupId],
    references: [studyGroups.id]
  }),
  user: one(users, {
    fields: [studyGroupMembers.userId],
    references: [users.id]
  })
}));

// K-12 Education Relations
export const industryTracksRelations = relations(industryTracks, ({ many }) => ({
  modules: many(curriculumModules),
  pathways: many(learningPathways)
}));

export const curriculumModulesRelations = relations(curriculumModules, ({ one, many }) => ({
  track: one(industryTracks, {
    fields: [curriculumModules.trackId],
    references: [industryTracks.id]
  }),
  questions: many(questionBank),
  videos: many(videoLessons),
  exercises: many(practiceExercises)
}));

export const questionBankRelations = relations(questionBank, ({ one, many }) => ({
  module: one(curriculumModules, {
    fields: [questionBank.moduleId],
    references: [curriculumModules.id]
  }),
  responses: many(assessmentResponses)
}));

export const learningPathwaysRelations = relations(learningPathways, ({ one }) => ({
  user: one(users, {
    fields: [learningPathways.userId],
    references: [users.id]
  }),
  track: one(industryTracks, {
    fields: [learningPathways.trackId],
    references: [industryTracks.id]
  }),
  currentModule: one(curriculumModules, {
    fields: [learningPathways.currentModule],
    references: [curriculumModules.id]
  })
}));

export const videoLessonsRelations = relations(videoLessons, ({ one, many }) => ({
  module: one(curriculumModules, {
    fields: [videoLessons.moduleId],
    references: [curriculumModules.id]
  }),
  progress: many(videoProgress)
}));

export const videoProgressRelations = relations(videoProgress, ({ one }) => ({
  user: one(users, {
    fields: [videoProgress.userId],
    references: [users.id]
  }),
  video: one(videoLessons, {
    fields: [videoProgress.videoId],
    references: [videoLessons.id]
  })
}));

export const practiceExercisesRelations = relations(practiceExercises, ({ one, many }) => ({
  module: one(curriculumModules, {
    fields: [practiceExercises.moduleId],
    references: [curriculumModules.id]
  }),
  attempts: many(exerciseAttempts)
}));

export const exerciseAttemptsRelations = relations(exerciseAttempts, ({ one }) => ({
  user: one(users, {
    fields: [exerciseAttempts.userId],
    references: [users.id]
  }),
  exercise: one(practiceExercises, {
    fields: [exerciseAttempts.exerciseId],
    references: [practiceExercises.id]
  })
}));

export const assessmentResponsesRelations = relations(assessmentResponses, ({ one }) => ({
  user: one(users, {
    fields: [assessmentResponses.userId],
    references: [users.id]
  }),
  question: one(questionBank, {
    fields: [assessmentResponses.questionId],
    references: [questionBank.id]
  }),
  session: one(aiTutoringSessions, {
    fields: [assessmentResponses.sessionId],
    references: [aiTutoringSessions.id]
  })
}));

// Advanced AI Tutoring Relations
export const aiTutoringSessionsRelations = relations(aiTutoringSessions, ({ one, many }) => ({
  user: one(users, {
    fields: [aiTutoringSessions.userId],
    references: [users.id]
  }),
  responses: many(assessmentResponses)
}));

export const vrCompetitionsRelations = relations(vrCompetitions, ({ many }) => ({
  participants: many(vrCompetitionParticipants)
}));

export const vrCompetitionParticipantsRelations = relations(vrCompetitionParticipants, ({ one }) => ({
  competition: one(vrCompetitions, {
    fields: [vrCompetitionParticipants.competitionId],
    references: [vrCompetitions.id]
  }),
  user: one(users, {
    fields: [vrCompetitionParticipants.userId],
    references: [users.id]
  })
}));

export const universityApplicationsRelations = relations(universityApplications, ({ one }) => ({
  user: one(users, {
    fields: [universityApplications.userId],
    references: [users.id]
  }),
  university: one(universityPartners, {
    fields: [universityApplications.universityId],
    references: [universityPartners.id]
  })
}));

export const universityPartnersRelations = relations(universityPartners, ({ many }) => ({
  applications: many(universityApplications)
}));

export const talentProfileRelations = relations(talentProfile, ({ one, many }) => ({
  user: one(users, {
    fields: [talentProfile.userId],
    references: [users.id]
  }),
  matches: many(recruitmentMatches)
}));

export const corporatePartnersRelations = relations(corporatePartners, ({ many }) => ({
  matches: many(recruitmentMatches)
}));

export const recruitmentMatchesRelations = relations(recruitmentMatches, ({ one }) => ({
  talentProfile: one(talentProfile, {
    fields: [recruitmentMatches.talentProfileId],
    references: [talentProfile.id]
  }),
  corporatePartner: one(corporatePartners, {
    fields: [recruitmentMatches.corporatePartnerId],
    references: [corporatePartners.id]
  })
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertAssessmentSchema = createInsertSchema(assessments).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertStudyGroupSchema = createInsertSchema(studyGroups).omit({
  id: true,
  createdAt: true
});

export const insertStudyGroupMemberSchema = createInsertSchema(studyGroupMembers).omit({
  id: true,
  joinedAt: true
});

export const insertCourseFeedSchema = createInsertSchema(courseFeed).omit({
  id: true,
  publishedAt: true
});

// K-12 Education Insert Schemas
export const insertIndustryTrackSchema = createInsertSchema(industryTracks).omit({
  id: true,
  createdAt: true
});

export const insertCurriculumModuleSchema = createInsertSchema(curriculumModules).omit({
  id: true,
  createdAt: true
});

export const insertQuestionBankSchema = createInsertSchema(questionBank).omit({
  id: true,
  createdAt: true
});

export const insertAssessmentResponseSchema = createInsertSchema(assessmentResponses).omit({
  id: true,
  responseDate: true
});

export const insertLearningPathwaySchema = createInsertSchema(learningPathways).omit({
  id: true,
  createdAt: true
});

export const insertVideoLessonSchema = createInsertSchema(videoLessons).omit({
  id: true,
  createdAt: true
});

export const insertVideoProgressSchema = createInsertSchema(videoProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPracticeExerciseSchema = createInsertSchema(practiceExercises).omit({
  id: true,
  createdAt: true
});

export const insertExerciseAttemptSchema = createInsertSchema(exerciseAttempts).omit({
  id: true,
  createdAt: true
});

// AI Tutoring Insert Schemas
export const insertAiTutoringSessionSchema = createInsertSchema(aiTutoringSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertVrCompetitionSchema = createInsertSchema(vrCompetitions).omit({
  id: true,
  createdAt: true
});

export const insertVrCompetitionParticipantSchema = createInsertSchema(vrCompetitionParticipants).omit({
  id: true,
  joinedAt: true,
  lastActiveAt: true
});

export const insertUniversityPartnerSchema = createInsertSchema(universityPartners).omit({
  id: true,
  createdAt: true
});

export const insertUniversityApplicationSchema = createInsertSchema(universityApplications).omit({
  id: true,
  createdAt: true
});

export const insertCorporatePartnerSchema = createInsertSchema(corporatePartners).omit({
  id: true,
  createdAt: true
});

export const insertTalentProfileSchema = createInsertSchema(talentProfile).omit({
  id: true,
  createdAt: true
});

export const insertRecruitmentMatchSchema = createInsertSchema(recruitmentMatches).omit({
  id: true,
  createdAt: true
});

export const insertUserOnboardingSchema = createInsertSchema(userOnboarding).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertAiMentorSessionSchema = createInsertSchema(aiMentorSessions).omit({
  id: true,
  createdAt: true
});

// Skill Recommendations Schema
export const skillRecommendations = pgTable("skill_recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  skillCategory: text("skill_category").notNull(), // 'programming', 'mathematics', 'ai_concepts', 'problem_solving'
  skillName: text("skill_name").notNull(),
  currentLevel: text("current_level").notNull(), // 'beginner', 'intermediate', 'advanced', 'expert'
  targetLevel: text("target_level").notNull(),
  priority: integer("priority").default(1), // 1-5 priority ranking
  estimatedHours: integer("estimated_hours").default(0),
  prerequisiteSkills: text("prerequisite_skills").array().default(sql`'{}'::text[]`),
  learningPath: jsonb("learning_path").notNull(), // Structured learning steps and resources
  aiReasoning: text("ai_reasoning"), // AI explanation for why this skill is recommended
  progress: integer("progress").default(0), // 0-100 completion percentage
  isActive: boolean("is_active").default(true),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const insertSkillRecommendationSchema = createInsertSchema(skillRecommendations).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// Types for skill recommendations
export type SkillRecommendation = typeof skillRecommendations.$inferSelect;
export type InsertSkillRecommendation = typeof skillRecommendations.$inferInsert;

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type LearningPath = typeof learningPaths.$inferSelect;
export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type AiConversation = typeof aiConversations.$inferSelect;
export type InsertAiConversation = z.infer<typeof insertAiConversationSchema>;
export type StudyGroup = typeof studyGroups.$inferSelect;
export type InsertStudyGroup = z.infer<typeof insertStudyGroupSchema>;
export type StudyGroupMember = typeof studyGroupMembers.$inferSelect;
export type InsertStudyGroupMember = z.infer<typeof insertStudyGroupMemberSchema>;
export type CourseFeed = typeof courseFeed.$inferSelect;
export type InsertCourseFeed = z.infer<typeof insertCourseFeedSchema>;

// K-12 Education Types
export type IndustryTrack = typeof industryTracks.$inferSelect;
export type InsertIndustryTrack = z.infer<typeof insertIndustryTrackSchema>;
export type CurriculumModule = typeof curriculumModules.$inferSelect;
export type InsertCurriculumModule = z.infer<typeof insertCurriculumModuleSchema>;
export type QuestionBank = typeof questionBank.$inferSelect;
export type InsertQuestionBank = z.infer<typeof insertQuestionBankSchema>;
export type AssessmentResponse = typeof assessmentResponses.$inferSelect;
export type InsertAssessmentResponse = z.infer<typeof insertAssessmentResponseSchema>;
export type LearningPathway = typeof learningPathways.$inferSelect;
export type InsertLearningPathway = z.infer<typeof insertLearningPathwaySchema>;
export type VideoLesson = typeof videoLessons.$inferSelect;
export type InsertVideoLesson = z.infer<typeof insertVideoLessonSchema>;
export type VideoProgress = typeof videoProgress.$inferSelect;
export type InsertVideoProgress = z.infer<typeof insertVideoProgressSchema>;
export type PracticeExercise = typeof practiceExercises.$inferSelect;
export type InsertPracticeExercise = z.infer<typeof insertPracticeExerciseSchema>;
export type ExerciseAttempt = typeof exerciseAttempts.$inferSelect;
export type InsertExerciseAttempt = z.infer<typeof insertExerciseAttemptSchema>;

// AI Tutoring Types
export type AiTutoringSession = typeof aiTutoringSessions.$inferSelect;
export type InsertAiTutoringSession = z.infer<typeof insertAiTutoringSessionSchema>;

// VR Competition Types
export type VrCompetition = typeof vrCompetitions.$inferSelect;
export type InsertVrCompetition = z.infer<typeof insertVrCompetitionSchema>;
export type VrCompetitionParticipant = typeof vrCompetitionParticipants.$inferSelect;
export type InsertVrCompetitionParticipant = z.infer<typeof insertVrCompetitionParticipantSchema>;

// University & Corporate Types
export type UniversityPartner = typeof universityPartners.$inferSelect;
export type InsertUniversityPartner = z.infer<typeof insertUniversityPartnerSchema>;
export type UniversityApplication = typeof universityApplications.$inferSelect;
export type InsertUniversityApplication = z.infer<typeof insertUniversityApplicationSchema>;
export type CorporatePartner = typeof corporatePartners.$inferSelect;
export type InsertCorporatePartner = z.infer<typeof insertCorporatePartnerSchema>;
export type TalentProfile = typeof talentProfile.$inferSelect;
export type InsertTalentProfile = z.infer<typeof insertTalentProfileSchema>;
export type RecruitmentMatch = typeof recruitmentMatches.$inferSelect;
export type InsertRecruitmentMatch = z.infer<typeof insertRecruitmentMatchSchema>;

// Onboarding types
export type UserOnboarding = typeof userOnboarding.$inferSelect;
export type InsertUserOnboarding = z.infer<typeof insertUserOnboardingSchema>;

// Degree Planning Insert Schemas
export const insertDegreeProgramSchema = createInsertSchema(degreePrograms).omit({
  id: true,
  createdAt: true
});
export type InsertDegreeProgram = z.infer<typeof insertDegreeProgramSchema>;

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true
});
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export const insertStudentDegreePlanSchema = createInsertSchema(studentDegreePlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
export type InsertStudentDegreePlan = z.infer<typeof insertStudentDegreePlanSchema>;

export const insertPlannedCourseSchema = createInsertSchema(plannedCourses).omit({
  id: true,
  createdAt: true
});
export type InsertPlannedCourse = z.infer<typeof insertPlannedCourseSchema>;

export const insertDegreeAuditSchema = createInsertSchema(degreeAudits).omit({
  id: true,
  runDate: true
});
export type InsertDegreeAudit = z.infer<typeof insertDegreeAuditSchema>;

// Degree Planning Types
export type DegreeProgram = typeof degreePrograms.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type StudentDegreePlan = typeof studentDegreePlans.$inferSelect;
export type PlannedCourse = typeof plannedCourses.$inferSelect;
export type DegreeAudit = typeof degreeAudits.$inferSelect;
export type CourseDemandAnalytics = typeof courseDemandAnalytics.$inferSelect;
