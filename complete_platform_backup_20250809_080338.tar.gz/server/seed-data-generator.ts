interface UserAssessmentData {
  userId: string;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  eiqScore: number;
  placementTrack: "platinum" | "gold" | "silver";
  domainScores: {
    algebra: number;
    statistics: number;
    calculus: number;
    programming: number;
    ai_concepts: number;
    logic: number;
  };
  assessmentResponses: Record<string, string>;
  learningGaps: string[];
  strengthAreas: string[];
  careerOutcome?: {
    company: string;
    position: string;
    salary: number;
    timeToHire: number; // months
  };
  universityOutcome?: {
    university: string;
    program: string;
    scholarship: number;
  };
  demographics: {
    age: number;
    country: string;
    educationLevel: string;
    priorExperience: string;
  };
  engagementMetrics: {
    assessmentDuration: number; // minutes
    questionsAnswered: number;
    hintsUsed: number;
    retakeCount: number;
  };
}

// Realistic career outcomes data
const CAREER_OUTCOMES = [
  { company: "Google", position: "Software Engineer", salaryRange: [180000, 220000], hiringRate: 0.12 },
  { company: "Meta", position: "Software Engineer", salaryRange: [175000, 210000], hiringRate: 0.15 },
  { company: "Apple", position: "Software Engineer", salaryRange: [170000, 200000], hiringRate: 0.18 },
  { company: "Microsoft", position: "Software Engineer", salaryRange: [165000, 195000], hiringRate: 0.22 },
  { company: "Amazon", position: "Software Development Engineer", salaryRange: [160000, 190000], hiringRate: 0.25 },
  { company: "Netflix", position: "Senior Software Engineer", salaryRange: [200000, 280000], hiringRate: 0.08 },
  { company: "Uber", position: "Software Engineer", salaryRange: [155000, 185000], hiringRate: 0.20 },
  { company: "Airbnb", position: "Software Engineer", salaryRange: [150000, 180000], hiringRate: 0.18 },
  { company: "Stripe", position: "Software Engineer", salaryRange: [170000, 200000], hiringRate: 0.15 },
  { company: "OpenAI", position: "ML Engineer", salaryRange: [200000, 300000], hiringRate: 0.05 }
];

const UNIVERSITY_OUTCOMES = [
  { university: "Stanford University", program: "Computer Science PhD", scholarshipRate: 0.85, avgScholarship: 45000 },
  { university: "MIT", program: "Computer Science MS", scholarshipRate: 0.70, avgScholarship: 35000 },
  { university: "Carnegie Mellon", program: "Machine Learning PhD", scholarshipRate: 0.80, avgScholarship: 40000 },
  { university: "UC Berkeley", program: "EECS PhD", scholarshipRate: 0.75, avgScholarship: 38000 },
  { university: "Caltech", program: "Computer Science MS", scholarshipRate: 0.65, avgScholarship: 30000 },
  { university: "Harvard", program: "Computer Science PhD", scholarshipRate: 0.90, avgScholarship: 50000 },
  { university: "Princeton", program: "Computer Science PhD", scholarshipRate: 0.85, avgScholarship: 47000 }
];

const COUNTRIES = ["United States", "Canada", "United Kingdom", "Germany", "India", "China", "Japan", "South Korea", "Australia", "Singapore"];
const EDUCATION_LEVELS = ["High School", "Some College", "Bachelor's Degree", "Master's Degree", "PhD"];
const EXPERIENCE_LEVELS = ["None", "Some Programming", "1-2 Years", "3-5 Years", "5+ Years"];

class SeedDataGenerator {
  private generateRandomUser(index: number): UserAssessmentData {
    const firstName = this.generateFirstName();
    const lastName = this.generateLastName();
    const username = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${index}`;
    
    // Generate realistic EiQ score with normal distribution
    const eiqScore = Math.max(300, Math.min(900, Math.floor(this.normalRandom(600, 120))));
    
    // Determine placement track based on EiQ score with some variance
    let placementTrack: "platinum" | "gold" | "silver";
    if (eiqScore >= 700) placementTrack = "platinum";
    else if (eiqScore >= 500) placementTrack = "gold";
    else placementTrack = "silver";

    // Generate correlated domain scores
    const baseScore = eiqScore / 10; // Convert to 30-90 range
    const variance = 15;
    
    const domainScores = {
      algebra: Math.max(20, Math.min(100, Math.floor(baseScore + this.normalRandom(0, variance)))),
      statistics: Math.max(20, Math.min(100, Math.floor(baseScore + this.normalRandom(0, variance)))),
      calculus: Math.max(15, Math.min(100, Math.floor(baseScore * 0.9 + this.normalRandom(0, variance)))),
      programming: Math.max(25, Math.min(100, Math.floor(baseScore * 1.1 + this.normalRandom(0, variance)))),
      ai_concepts: Math.max(20, Math.min(100, Math.floor(baseScore * 0.85 + this.normalRandom(0, variance)))),
      logic: Math.max(30, Math.min(100, Math.floor(baseScore + this.normalRandom(0, variance / 2))))
    };

    // Generate realistic assessment responses
    const assessmentResponses = this.generateAssessmentResponses(domainScores, placementTrack);
    
    // Generate learning gaps and strengths based on scores
    const { learningGaps, strengthAreas } = this.generateLearningProfile(domainScores, placementTrack);

    // Generate career outcome for successful students
    const careerOutcome = this.generateCareerOutcome(eiqScore, placementTrack);
    const universityOutcome = this.generateUniversityOutcome(eiqScore, placementTrack);

    return {
      userId: `user_${index.toString().padStart(6, '0')}`,
      username,
      firstName,
      lastName,
      email: `${username}@example.com`,
      eiqScore,
      placementTrack,
      domainScores,
      assessmentResponses,
      learningGaps,
      strengthAreas,
      careerOutcome,
      universityOutcome,
      demographics: {
        age: Math.floor(Math.random() * 15) + 16, // 16-30 years old
        country: COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)],
        educationLevel: EDUCATION_LEVELS[Math.floor(Math.random() * EDUCATION_LEVELS.length)],
        priorExperience: EXPERIENCE_LEVELS[Math.floor(Math.random() * EXPERIENCE_LEVELS.length)]
      },
      engagementMetrics: {
        assessmentDuration: Math.floor(Math.random() * 60) + 30, // 30-90 minutes
        questionsAnswered: Math.floor(Math.random() * 30) + 20, // 20-50 questions
        hintsUsed: Math.floor(Math.random() * 8), // 0-7 hints
        retakeCount: Math.random() < 0.3 ? Math.floor(Math.random() * 3) + 1 : 0 // 30% retake
      }
    };
  }

  private generateCareerOutcome(eiqScore: number, track: string) {
    // Higher EiQ scores have better career outcomes
    if (Math.random() < this.getCareerSuccessRate(eiqScore, track)) {
      const availableJobs = CAREER_OUTCOMES.filter(job => 
        Math.random() < job.hiringRate * this.getCareerMultiplier(eiqScore)
      );
      
      if (availableJobs.length > 0) {
        const job = availableJobs[Math.floor(Math.random() * availableJobs.length)];
        return {
          company: job.company,
          position: job.position,
          salary: Math.floor(Math.random() * (job.salaryRange[1] - job.salaryRange[0])) + job.salaryRange[0],
          timeToHire: this.getTimeToHire(eiqScore, track)
        };
      }
    }
    return undefined;
  }

  private generateUniversityOutcome(eiqScore: number, track: string) {
    if (Math.random() < this.getUniversityAcceptanceRate(eiqScore, track)) {
      const university = UNIVERSITY_OUTCOMES[Math.floor(Math.random() * UNIVERSITY_OUTCOMES.length)];
      return {
        university: university.university,
        program: university.program,
        scholarship: Math.random() < university.scholarshipRate ? 
          Math.floor(Math.random() * university.avgScholarship * 0.5) + university.avgScholarship * 0.5 : 0
      };
    }
    return undefined;
  }

  private getCareerSuccessRate(eiqScore: number, track: string): number {
    if (track === "platinum") return Math.min(0.85, eiqScore / 800);
    if (track === "gold") return Math.min(0.65, eiqScore / 700);
    return Math.min(0.35, eiqScore / 600);
  }

  private getUniversityAcceptanceRate(eiqScore: number, track: string): number {
    if (track === "platinum") return Math.min(0.75, eiqScore / 850);
    if (track === "gold") return Math.min(0.50, eiqScore / 750);
    return Math.min(0.25, eiqScore / 650);
  }

  private getCareerMultiplier(eiqScore: number): number {
    return Math.max(0.5, Math.min(2.0, eiqScore / 600));
  }

  private getTimeToHire(eiqScore: number, track: string): number {
    const baseTime = track === "platinum" ? 8 : track === "gold" ? 14 : 20;
    const variance = 4;
    return Math.max(3, Math.floor(baseTime + this.normalRandom(0, variance)));
  }

  private generateAssessmentResponses(domainScores: any, track: string): Record<string, string> {
    // Generate realistic assessment responses based on performance level
    const responses: Record<string, string> = {};
    
    // Sample questions with realistic response patterns
    const questionIds = [
      "foundation_algebra_1", "intermediate_stats_1", "advanced_calculus_1", 
      "advanced_ai_1", "programming_logic_1", "reasoning_pattern_1"
    ];

    questionIds.forEach(questionId => {
      if (questionId.includes("algebra")) {
        responses[questionId] = domainScores.algebra > 70 ? "5" : domainScores.algebra > 50 ? "5" : "3";
      } else if (questionId.includes("stats")) {
        responses[questionId] = domainScores.statistics > 70 ? "3% chance of observing this result if null hypothesis is true" : "3% chance the null hypothesis is true";
      } else if (questionId.includes("calculus")) {
        responses[questionId] = domainScores.calculus > 80 ? "x²e^x + 2xe^x" : "2xe^x";
      } else {
        // Generate realistic text responses for open-ended questions
        const responseQuality = (domainScores.ai_concepts + domainScores.programming) / 2;
        if (responseQuality > 75) {
          responses[questionId] = "Comprehensive answer demonstrating deep understanding...";
        } else if (responseQuality > 50) {
          responses[questionId] = "Good answer showing solid grasp of concepts...";
        } else {
          responses[questionId] = "Basic answer with some understanding...";
        }
      }
    });

    return responses;
  }

  private generateLearningProfile(domainScores: any, track: string) {
    const learningGaps: string[] = [];
    const strengthAreas: string[] = [];

    Object.entries(domainScores).forEach(([domain, score]) => {
      if ((score as number) < 60) {
        learningGaps.push(this.getDomainGap(domain));
      } else if ((score as number) > 80) {
        strengthAreas.push(this.getDomainStrength(domain));
      }
    });

    return { learningGaps, strengthAreas };
  }

  private getDomainGap(domain: string): string {
    const gaps: Record<string, string[]> = {
      algebra: ["Linear equation solving", "Quadratic formulas", "System of equations"],
      statistics: ["Hypothesis testing", "Probability distributions", "Confidence intervals"],
      calculus: ["Derivatives", "Integration", "Limits and continuity"],
      programming: ["Object-oriented programming", "Data structures", "Algorithm analysis"],
      ai_concepts: ["Machine learning fundamentals", "Neural network architecture", "Deep learning concepts"],
      logic: ["Logical reasoning", "Proof techniques", "Problem decomposition"]
    };
    
    const domainGaps = gaps[domain] || ["General knowledge in this area"];
    return domainGaps[Math.floor(Math.random() * domainGaps.length)];
  }

  private getDomainStrength(domain: string): string {
    const strengths: Record<string, string[]> = {
      algebra: ["Advanced algebraic manipulation", "Complex equation solving", "Mathematical modeling"],
      statistics: ["Statistical analysis", "Data interpretation", "Research methodology"],
      calculus: ["Advanced calculus applications", "Mathematical analysis", "Optimization techniques"],
      programming: ["Software architecture", "Algorithm implementation", "Code optimization"],
      ai_concepts: ["Machine learning expertise", "AI system design", "Research methodology"],
      logic: ["Logical reasoning", "Problem-solving strategy", "Analytical thinking"]
    };
    
    const domainStrengths = strengths[domain] || ["Strong foundation in this area"];
    return domainStrengths[Math.floor(Math.random() * domainStrengths.length)];
  }

  private normalRandom(mean: number, stdDev: number): number {
    // Box-Muller transformation for normal distribution
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return z0 * stdDev + mean;
  }

  private generateFirstName(): string {
    const names = [
      "Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Avery", "Quinn", "Sage", "River",
      "Emma", "Liam", "Olivia", "Noah", "Ava", "Ethan", "Sophia", "Mason", "Isabella", "William",
      "Mia", "James", "Charlotte", "Benjamin", "Amelia", "Lucas", "Harper", "Henry", "Evelyn", "Alexander",
      "Abigail", "Michael", "Emily", "Daniel", "Elizabeth", "Matthew", "Camila", "Jackson", "Luna", "Sebastian",
      "Ella", "David", "Sofia", "Carter", "Avery", "Owen", "Scarlett", "Wyatt", "Eleanor", "Luke"
    ];
    return names[Math.floor(Math.random() * names.length)];
  }

  private generateLastName(): string {
    const names = [
      "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
      "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
      "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
      "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
      "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts"
    ];
    return names[Math.floor(Math.random() * names.length)];
  }

  public generateBatch(startIndex: number, batchSize: number): UserAssessmentData[] {
    const batch: UserAssessmentData[] = [];
    for (let i = startIndex; i < startIndex + batchSize; i++) {
      batch.push(this.generateRandomUser(i));
    }
    return batch;
  }

  public generateAnalytics(userData: UserAssessmentData[]): any {
    const totalUsers = userData.length;
    const trackDistribution = {
      platinum: userData.filter(u => u.placementTrack === "platinum").length,
      gold: userData.filter(u => u.placementTrack === "gold").length,
      silver: userData.filter(u => u.placementTrack === "silver").length
    };

    const avgEiqScore = userData.reduce((sum, u) => sum + u.eiqScore, 0) / totalUsers;
    
    const careerOutcomes = userData.filter(u => u.careerOutcome).length;
    const universityOutcomes = userData.filter(u => u.universityOutcome).length;
    
    const topCompanies = userData
      .filter(u => u.careerOutcome)
      .reduce((acc: Record<string, number>, u) => {
        const company = u.careerOutcome!.company;
        acc[company] = (acc[company] || 0) + 1;
        return acc;
      }, {});

    return {
      totalUsers,
      trackDistribution,
      avgEiqScore: Math.round(avgEiqScore),
      successMetrics: {
        careerPlacements: careerOutcomes,
        universityAdmissions: universityOutcomes,
        totalSuccessRate: Math.round(((careerOutcomes + universityOutcomes) / totalUsers) * 100)
      },
      topCompanies: Object.entries(topCompanies)
        .sort(([,a], [,b]) => (b as number) - (a as number))
        .slice(0, 10),
      avgSalary: userData
        .filter(u => u.careerOutcome)
        .reduce((sum, u) => sum + u.careerOutcome!.salary, 0) / careerOutcomes || 0
    };
  }
}

export const seedGenerator = new SeedDataGenerator();