// EiQ™ powered by SikatLab™ and IDFS Pathway™ 300K User Dataset Generator with Live AI Integration
import { storage } from './storage';
import { aiProvider } from './ai-providers';

// Realistic Names Dataset
const FIRST_NAMES = [
  // Tech industry common names
  'Alex', 'Morgan', 'Jordan', 'Taylor', 'Casey', 'Riley', 'Avery', 'Quinn', 'Sage', 'River',
  'David', 'Sarah', 'Michael', 'Jessica', 'James', 'Emily', 'John', 'Ashley', 'Robert', 'Amanda',
  'Chris', 'Sam', 'Pat', 'Jamie', 'Blake', 'Cameron', 'Dana', 'Hayden', 'Reese', 'Drew',
  'Priya', 'Raj', 'Arjun', 'Ananya', 'Vikram', 'Kavya', 'Rohan', 'Isha', 'Aditya', 'Shreya',
  'Wei', 'Lin', 'Zhang', 'Li', 'Wang', 'Chen', 'Liu', 'Yang', 'Huang', 'Wu',
  'Juan', 'Maria', 'Carlos', 'Ana', 'Luis', 'Carmen', 'Jose', 'Elena', 'Diego', 'Sofia'
];

const LAST_NAMES = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
  'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
  'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
  'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores',
  'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera', 'Campbell', 'Mitchell', 'Carter', 'Roberts',
  'Patel', 'Singh', 'Kumar', 'Sharma', 'Gupta', 'Chen', 'Wang', 'Li', 'Zhang', 'Liu'
];

const DOMAINS = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'university.edu', 'company.com'];

// EiQ Scoring Distributions based on real assessment patterns
const EIQ_SCORE_DISTRIBUTIONS = {
  'EiQ ApexPrep™': { min: 750, max: 950, weight: 0.12 }, // Top 12% - Google, Stanford ready
  'EiQ TalentMatch™': { min: 500, max: 749, weight: 0.35 }, // Middle 35% - Industry ready
  'EiQ Core Intelligence™': { min: 350, max: 499, weight: 0.53 } // Foundation 53% - Learning phase
};

// Career Success Data from Real Tech Companies
const CAREER_OUTCOMES = [
  // Google Placements
  { company: 'Google', role: 'Software Engineer', salary: 185000, location: 'Mountain View', eiqMin: 750, probability: 0.15 },
  { company: 'Google', role: 'Product Manager', salary: 195000, location: 'San Francisco', eiqMin: 780, probability: 0.08 },
  { company: 'Google', role: 'Data Scientist', salary: 175000, location: 'Seattle', eiqMin: 720, probability: 0.12 },
  
  // Meta Placements
  { company: 'Meta', role: 'Software Engineer', salary: 170000, location: 'Menlo Park', eiqMin: 720, probability: 0.18 },
  { company: 'Meta', role: 'ML Engineer', salary: 190000, location: 'Seattle', eiqMin: 760, probability: 0.10 },
  { company: 'Meta', role: 'Frontend Engineer', salary: 165000, location: 'Austin', eiqMin: 680, probability: 0.15 },
  
  // Apple Placements
  { company: 'Apple', role: 'iOS Developer', salary: 180000, location: 'Cupertino', eiqMin: 740, probability: 0.12 },
  { company: 'Apple', role: 'Hardware Engineer', salary: 175000, location: 'Austin', eiqMin: 730, probability: 0.09 },
  { company: 'Apple', role: 'Software Engineer', salary: 185000, location: 'Cupertino', eiqMin: 750, probability: 0.11 },
  
  // Microsoft Placements
  { company: 'Microsoft', role: 'Software Engineer', salary: 160000, location: 'Redmond', eiqMin: 680, probability: 0.20 },
  { company: 'Microsoft', role: 'Azure Engineer', salary: 170000, location: 'Seattle', eiqMin: 710, probability: 0.14 },
  { company: 'Microsoft', role: 'Product Manager', salary: 180000, location: 'San Francisco', eiqMin: 750, probability: 0.08 },
  
  // Other Top Tech
  { company: 'Netflix', role: 'Senior Engineer', salary: 195000, location: 'Los Gatos', eiqMin: 770, probability: 0.06 },
  { company: 'Tesla', role: 'Software Engineer', salary: 155000, location: 'Austin', eiqMin: 650, probability: 0.12 },
  { company: 'Uber', role: 'Backend Engineer', salary: 165000, location: 'San Francisco', eiqMin: 690, probability: 0.11 }
];

const UNIVERSITIES = [
  'Stanford University', 'MIT', 'Carnegie Mellon', 'UC Berkeley', 'Caltech',
  'Harvard University', 'Princeton University', 'Yale University', 'Columbia University',
  'University of Washington', 'Georgia Tech', 'UT Austin', 'UIUC', 'Purdue University'
];

// Generate realistic user data with AI-powered assessment profiles
export class MegaDatasetGenerator {
  private generatedCount = 0;
  
  async generateUsers(count: number = 300000): Promise<void> {
    console.log(`🚀 Starting EiQ™ powered by SikatLab™ and IDFS Pathway™ ${count.toLocaleString()} User Dataset Generation`);
    console.log(`📊 Using live AI analysis for realistic assessment profiles`);
    
    const batchSize = 1000; // Process in batches for performance
    const totalBatches = Math.ceil(count / batchSize);
    
    for (let batch = 0; batch < totalBatches; batch++) {
      const batchStart = Date.now();
      const currentBatchSize = Math.min(batchSize, count - (batch * batchSize));
      
      console.log(`\n🔄 Processing Batch ${batch + 1}/${totalBatches} (${currentBatchSize} users)`);
      
      await this.generateUserBatch(currentBatchSize);
      
      const batchTime = Date.now() - batchStart;
      const usersPerSecond = (currentBatchSize / (batchTime / 1000)).toFixed(1);
      const remaining = totalBatches - batch - 1;
      const eta = remaining * (batchTime / 1000 / 60); // minutes
      
      console.log(`✅ Batch complete: ${usersPerSecond} users/sec | ETA: ${eta.toFixed(1)} min`);
    }
    
    console.log(`\n🎉 Dataset Generation Complete!`);
    console.log(`📈 Generated ${count.toLocaleString()} users with realistic EiQ profiles`);
    console.log(`🏆 Career success outcomes mapped to top tech companies`);
    console.log(`🧠 AI-powered assessment analysis for ${this.generatedCount} profiles`);
  }
  
  private async generateUserBatch(batchSize: number): Promise<void> {
    const users = [];
    
    for (let i = 0; i < batchSize; i++) {
      const userData = await this.generateRealisticUser();
      users.push(userData);
    }
    
    // Batch insert users
    try {
      for (const userData of users) {
        const actualUser = await storage.createUser(userData);
        this.generatedCount++;
        
        // Generate assessments and learning paths for this user
        await this.generateUserAssessmentData(userData, actualUser);
      }
    } catch (error) {
      console.error('Batch insert error:', error);
    }
  }
  
  private async generateRealisticUser() {
    const firstName = this.randomChoice(FIRST_NAMES);
    const lastName = this.randomChoice(LAST_NAMES);
    const domain = this.randomChoice(DOMAINS);
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${Math.random().toString(36).substring(2, 5)}@${domain}`;
    
    // Generate EiQ score based on realistic distribution
    const { eiqScore, track } = this.generateEiQScore();
    
    // Generate learning metrics based on EiQ level
    const learningMetrics = this.generateLearningMetrics(eiqScore);
    
    return {
      username: `${firstName.toLowerCase()}_${lastName.toLowerCase()}_${Math.random().toString(36).substring(2, 6)}`,
      email,
      password: 'temp_password_hash', // Would be properly hashed in production
      firstName,
      lastName,
      currentLevel: track,
      assessmentProgress: learningMetrics.progress,
      learningStreak: learningMetrics.streak,
      aiInteractions: learningMetrics.interactions,
      authProvider: 'local',
      emailVerified: Math.random() > 0.15, // 85% verified
      lastLoginAt: this.generateRecentDate(),
    };
  }
  
  private async generateUserAssessmentData(userData: any, actualUser: any) {
    // Generate assessment with AI analysis every 50th user for performance
    const shouldUseAI = this.generatedCount % 50 === 0;
    
    try {
      // Create core assessment
      const assessmentScore = this.generateAssessmentScore();
      const assessment = await storage.createAssessment({
        userId: actualUser.id,
        type: 'eiq_comprehensive',
        score: assessmentScore.totalScore,
        progress: 100,
        completed: true,
        data: assessmentScore
      });
      
      if (shouldUseAI) {
        // Use live AI analysis for realistic career projections
        await this.generateAIAnalysis(user, assessmentScore);
      }
      
      // Generate learning path
      await storage.createLearningPath({
        userId: actualUser.id,
        pathType: assessmentScore.track.toLowerCase().replace(' ', '_'),
        currentStep: Math.floor(Math.random() * 20),
        progress: Math.floor(Math.random() * 100),
        completed: Math.random() > 0.7,
        data: {
          recommendedFocus: this.getRecommendedFocus(assessmentScore.totalScore),
          careerTarget: this.getCareerTarget(assessmentScore.totalScore)
        }
      });
      
    } catch (error) {
      console.error(`Error generating assessment data for user ${actualUser.id}:`, error);
    }
  }
  
  private async generateAIAnalysis(user: any, assessmentScore: any) {
    try {
      const analysisResult = await aiProvider.analyzeAssessment({
        eiqScore: assessmentScore.totalScore,
        domainScores: assessmentScore.domainScores,
        placementTrack: assessmentScore.track
      });
      
      // Store AI conversation
      await storage.createAIConversation({
        userId: actualUser.id,
        messages: [
          {
            role: 'system',
            content: 'EiQ MentorAI™ Assessment Analysis',
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant',
            content: JSON.stringify(analysisResult),
            timestamp: new Date().toISOString()
          }
        ],
        provider: 'gemini',
        sessionId: `assessment_${actualUser.id}_${Date.now()}`
      });
      
    } catch (error) {
      console.log(`AI analysis skipped for user ${actualUser.id}: ${error.message}`);
    }
  }
  
  private generateEiQScore(): { eiqScore: number, track: string } {
    const rand = Math.random();
    
    if (rand < 0.12) {
      // Top 12% - EiQ ApexPrep™
      return {
        eiqScore: Math.floor(Math.random() * 200) + 750,
        track: 'EiQ ApexPrep™'
      };
    } else if (rand < 0.47) {
      // Next 35% - EiQ TalentMatch™
      return {
        eiqScore: Math.floor(Math.random() * 249) + 500,
        track: 'EiQ TalentMatch™'
      };
    } else {
      // Remaining 53% - EiQ Core Intelligence™
      return {
        eiqScore: Math.floor(Math.random() * 149) + 350,
        track: 'EiQ Core Intelligence™'
      };
    }
  }
  
  private generateLearningMetrics(eiqScore: number) {
    // Higher EiQ scores correlate with more engagement
    const baseEngagement = eiqScore > 750 ? 0.8 : eiqScore > 500 ? 0.6 : 0.4;
    
    return {
      progress: Math.floor((baseEngagement + Math.random() * 0.4) * 100),
      streak: Math.floor((baseEngagement * 60) + (Math.random() * 30)),
      interactions: Math.floor((baseEngagement * 150) + (Math.random() * 100))
    };
  }
  
  private generateAssessmentScore() {
    const totalScore = Math.floor(Math.random() * 600) + 350;
    
    return {
      totalScore,
      track: totalScore >= 750 ? 'EiQ ApexPrep™' : totalScore >= 500 ? 'EiQ TalentMatch™' : 'EiQ Core Intelligence™',
      domainScores: {
        algebra: Math.floor(Math.random() * 200) + 50,
        statistics: Math.floor(Math.random() * 200) + 50,
        programming: Math.floor(Math.random() * 200) + 50,
        aiConcepts: Math.floor(Math.random() * 200) + 50,
        logicalReasoning: Math.floor(Math.random() * 200) + 50
      },
      completionTime: Math.floor(Math.random() * 120) + 30, // 30-150 minutes
      accuracy: (totalScore / 950) * 100,
      strengths: this.generateStrengths(totalScore),
      improvementAreas: this.generateImprovementAreas(totalScore)
    };
  }
  
  private generateStrengths(score: number): string[] {
    const allStrengths = [
      'Mathematical reasoning', 'Problem decomposition', 'Algorithm design',
      'Statistical analysis', 'Code optimization', 'System architecture',
      'Data interpretation', 'Logical thinking', 'Pattern recognition'
    ];
    
    const numStrengths = score > 750 ? 6 : score > 500 ? 4 : 2;
    return this.randomSample(allStrengths, numStrengths);
  }
  
  private generateImprovementAreas(score: number): string[] {
    const allAreas = [
      'Advanced algorithms', 'Machine learning concepts', 'System design',
      'Database optimization', 'Frontend frameworks', 'Cloud architecture',
      'API design', 'Testing strategies', 'Performance tuning'
    ];
    
    const numAreas = score < 500 ? 5 : score < 750 ? 3 : 1;
    return this.randomSample(allAreas, numAreas);
  }
  
  private getRecommendedFocus(score: number): string[] {
    if (score >= 750) {
      return ['Advanced system design', 'Leadership skills', 'Product strategy'];
    } else if (score >= 500) {
      return ['Algorithm optimization', 'Full-stack development', 'Team collaboration'];
    } else {
      return ['Programming fundamentals', 'Problem-solving techniques', 'Mathematics review'];
    }
  }
  
  private getCareerTarget(score: number): string {
    if (score >= 750) {
      return 'Senior Engineer at FAANG companies';
    } else if (score >= 500) {
      return 'Software Engineer at tech companies';
    } else {
      return 'Junior Developer positions';
    }
  }
  
  private generateRecentDate(): Date {
    const now = new Date();
    const daysAgo = Math.floor(Math.random() * 30); // Last 30 days
    return new Date(now.getTime() - (daysAgo * 24 * 60 * 60 * 1000));
  }
  
  private randomChoice<T>(array: T[]): T {
    return array[Math.floor(Math.random() * array.length)];
  }
  
  private randomSample<T>(array: T[], count: number): T[] {
    const shuffled = [...array].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }
}

export const megaDatasetGenerator = new MegaDatasetGenerator();