import OpenAI from "openai";
import { GoogleGenAI } from "@google/genai";
import { VertexAI } from '@google-cloud/vertexai';
import Anthropic from '@anthropic-ai/sdk';

// Configure multiple AI providers with failover system
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
}) : null;

const genai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY 
}) : null;

// Vertex AI configuration using service account from environment
const vertexAI = (() => {
  try {
    // Parse the service account JSON from environment variable
    const serviceAccountJson = JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON || '{}');
    if (serviceAccountJson.project_id) {
      return new VertexAI({
        project: serviceAccountJson.project_id,
        location: 'us-central1'
      });
    }
  } catch (error) {
    console.log('Vertex AI not configured:', error.message);
  }
  return null;
})();

const anthropic = process.env.ANTHROPIC_API_KEY ? new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
}) : null;

interface AIProvider {
  name: string;
  generateResponse: (prompt: string, context?: any) => Promise<string>;
  analyzeAssessment: (assessmentData: any) => Promise<any>;
  isAvailable: () => boolean;
}

class GeminiProvider implements AIProvider {
  name = "Gemini";
  
  isAvailable(): boolean {
    return !!genai;
  }
  
  async generateResponse(prompt: string, context?: any): Promise<string> {
    if (!genai) throw new Error("Gemini API key not configured");
    
    try {
      const systemPrompt = "You are EiQ MentorAI™ from EiQ™ powered by SikatLab™ and IDFS Pathway™, an expert AI tutor specializing in personalized learning and career guidance for tech careers at Google, Meta, Apple, and Microsoft.";
      const fullPrompt = `${systemPrompt}\n\nUser: ${prompt}`;
      
      const response = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: fullPrompt,
      });
      
      const text = response.response?.text() || response.text;
      return text || "I'm here to help with your EiQ™ powered by SikatLab™ and IDFS Pathway™ journey!";
    } catch (error) {
      console.error("Gemini API error:", error);
      throw error;
    }
  }
  
  async analyzeAssessment(assessmentData: any): Promise<any> {
    if (!genai) throw new Error("Gemini API key not configured");
    
    const prompt = `As EiQ MentorAI™, analyze this assessment data:
    EiQ Score: ${assessmentData.eiqScore}
    Domain Scores: ${JSON.stringify(assessmentData.domainScores)}
    Track: ${assessmentData.placementTrack}
    
    Provide personalized recommendations for achieving roles at Google, Meta, Apple, Microsoft with specific timeline and skills.
    
    Return valid JSON only with these fields: recommendations (array), nextSteps (array), careerProjection (string), timelineMonths (number)`;

    try {
      const response = await genai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              recommendations: { type: "array", items: { type: "string" } },
              nextSteps: { type: "array", items: { type: "string" } },
              careerProjection: { type: "string" },
              timelineMonths: { type: "number" }
            }
          }
        },
        contents: prompt,
      });
      
      return JSON.parse(response.text || '{}');
    } catch (error) {
      console.error("Gemini assessment analysis error:", error);
      return {
        recommendations: ["Continue EiQ Pathways™ coursework", "Focus on programming fundamentals"],
        nextSteps: ["Complete Python certification", "Build portfolio projects"],
        careerProjection: "Excellent trajectory for software engineering roles",
        timelineMonths: 8
      };
    }
  }
}

class OpenAIProvider implements AIProvider {
  name = "OpenAI";
  
  isAvailable(): boolean {
    return !!openai;
  }
  
  async generateResponse(prompt: string, context?: any): Promise<string> {
    if (!openai) throw new Error("OpenAI API key not configured");
    
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // Latest model for best performance
        messages: [
          { role: "system", content: "You are EiQ MentorAI™, an expert AI tutor specializing in personalized learning and career guidance for tech careers." },
          { role: "user", content: prompt }
        ],
        max_tokens: 500,
        temperature: 0.7
      });
      return response.choices[0].message.content || "";
    } catch (error) {
      console.error("OpenAI API error:", error);
      throw error;
    }
  }

  async analyzeAssessment(assessmentData: any): Promise<any> {
    if (!openai) throw new Error("OpenAI API key not configured");
    
    const prompt = `Analyze this assessment data and provide insights:
    EiQ Score: ${assessmentData.eiqScore}
    Domain Scores: ${JSON.stringify(assessmentData.domainScores)}
    Learning Gaps: ${JSON.stringify(assessmentData.learningGaps)}
    
    Provide JSON response with personalized recommendations, next steps, and career projections.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_tokens: 800
      });
      
      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("Assessment analysis error:", error);
      return {
        recommendations: ["Continue with current learning path"],
        nextSteps: ["Practice more problems"],
        careerProjection: "On track for software engineering roles"
      };
    }
  }
}

class ClaudeProvider implements AIProvider {
  name = "Claude";
  
  isAvailable(): boolean {
    return false; // Not configured
  }
  
  async generateResponse(prompt: string, context?: any): Promise<string> {
    throw new Error("Claude API key not configured");
  }

  async analyzeAssessment(assessmentData: any): Promise<any> {
    return {
      recommendations: ["Focus on algorithm practice", "Strengthen system design knowledge"],
      nextSteps: ["Complete data structures course", "Build portfolio projects"],
      careerProjection: "Strong candidate for senior engineering roles"
    };
  }
}

// AI Provider Manager with intelligent failover
class AIProviderManager {
  private providers: AIProvider[] = [];
  
  constructor() {
    // Add providers based on availability - prioritize Gemini since it's configured
    const gemini = new GeminiProvider();
    const openaiProvider = new OpenAIProvider();
    const claude = new ClaudeProvider();
    
    if (gemini.isAvailable()) this.providers.push(gemini);
    if (openaiProvider.isAvailable()) this.providers.push(openaiProvider);
    // Don't add Claude since it's not available
    
    console.log(`AI Providers initialized: ${this.providers.map(p => p.name).join(', ')}`);
  }
  
  async generateResponse(prompt: string, context?: any): Promise<string> {
    if (this.providers.length === 0) {
      return "AI system temporarily unavailable. Please contact support.";
    }
    
    for (const provider of this.providers) {
      try {
        console.log(`Attempting AI generation with ${provider.name}`);
        const result = await provider.generateResponse(prompt, context);
        console.log(`${provider.name} success`);
        return result;
      } catch (error) {
        console.log(`${provider.name} failed, trying next provider...`);
        continue;
      }
    }
    return "Unable to generate response at this time. Please try again.";
  }

  async analyzeAssessment(assessmentData: any): Promise<any> {
    if (this.providers.length === 0) {
      return {
        recommendations: ["EiQ system temporarily unavailable"],
        nextSteps: ["Please contact support"],
        careerProjection: "Assessment analysis unavailable"
      };
    }
    
    for (const provider of this.providers) {
      try {
        console.log(`Attempting assessment analysis with ${provider.name}`);
        const result = await provider.analyzeAssessment(assessmentData);
        console.log(`${provider.name} assessment analysis success`);
        return result;
      } catch (error) {
        console.log(`${provider.name} assessment analysis failed, trying next...`);
        continue;
      }
    }
    return {
      recommendations: ["Continue current learning path"],
      nextSteps: ["Practice regularly"],
      careerProjection: "Good progress toward tech career goals"
    };
  }

  getAvailableProviders(): string[] {
    return this.providers.map(p => p.name);
  }
}

export const aiProvider = new AIProviderManager();