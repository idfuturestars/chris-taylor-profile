import { cn } from "@/lib/utils";

interface EiQLogoProps {
  className?: string;
  showText?: boolean;
}

export default function EiQLogo({ className, showText = true }: EiQLogoProps) {
  return (
    <div className={cn("flex items-center space-x-3", className)}>
      <div className="flex items-center">
        <span className="text-2xl font-bold text-foreground">E</span>
        <div className="relative">
          <span className="text-2xl font-bold text-foreground">i</span>
          {/* Custom Four-Pointed Star SVG above the i */}
          <svg 
            className="absolute -top-1 left-1/2 transform -translate-x-1/2" 
            width="8" 
            height="8" 
            viewBox="0 0 24 24" 
            fill="white"
          >
            <path d="M12 0L14.12 9.88L24 12L14.12 14.12L12 24L9.88 14.12L0 12L9.88 9.88L12 0Z"/>
          </svg>
        </div>
        <span className="text-2xl font-bold text-foreground">Q</span>
        <span className="text-xs font-bold text-foreground relative -top-3">™</span>
      </div>
      {showText && (
        <span className="text-sm text-muted-foreground">powered by SikatLabsAI™ and IDFS Pathway™</span>
      )}
    </div>
  );
}
