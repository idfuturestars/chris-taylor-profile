import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Target, Zap, Crown, Rocket } from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  rarity: "common" | "rare" | "legendary";
  earned: boolean;
  earnedDate?: string;
  category: "career" | "academic" | "skill" | "milestone";
}

export default function AchievementShowcase() {
  const achievements: Achievement[] = [
    {
      id: "google-offer",
      title: "Googler Elite",
      description: "Received job offer from Google using EiQ™ powered by SikatLab™ and IDFS Pathway™ preparation",
      icon: Crown,
      rarity: "legendary",
      earned: true,
      earnedDate: "2024-12-15",
      category: "career"
    },
    {
      id: "meta-offer", 
      title: "Meta Achiever",
      description: "Landed Software Engineer role at Meta (Facebook)",
      icon: Rocket,
      rarity: "legendary", 
      earned: true,
      earnedDate: "2024-11-22",
      category: "career"
    },
    {
      id: "stanford-admit",
      title: "Cardinal Scholar",
      description: "Accepted to Stanford University CS Program",
      icon: Trophy,
      rarity: "legendary",
      earned: true,
      earnedDate: "2024-03-28",
      category: "academic"
    },
    {
      id: "platinum-track",
      title: "Platinum Mastery",
      description: "Achieved Platinum track placement (EiQ Score 750+)",
      icon: Star,
      rarity: "rare",
      earned: true,
      earnedDate: "2024-08-12",
      category: "skill"
    },
    {
      id: "ai-research-pub",
      title: "Research Pioneer",
      description: "Published AI research paper with 100+ citations",
      icon: Target,
      rarity: "legendary", 
      earned: false,
      category: "academic"
    },
    {
      id: "startup-founder",
      title: "Tech Founder",
      description: "Founded AI startup valued at $10M+",
      icon: Zap,
      rarity: "legendary",
      earned: false,
      category: "career"
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "legendary": return "bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500";
      case "rare": return "bg-gradient-to-r from-purple-400 to-blue-500";
      default: return "bg-gradient-to-r from-green-400 to-blue-500";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "career": return "💼";
      case "academic": return "🎓";
      case "skill": return "🧠";
      case "milestone": return "🎯";
      default: return "⭐";
    }
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-primary" />
          EiQ™ powered by SikatLab™ and IDFS Pathway™ Achievements
        </CardTitle>
        <p className="text-muted-foreground text-sm">
          Track your journey from assessment to career success at top tech companies
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((achievement) => {
            const IconComponent = achievement.icon;
            return (
              <div
                key={achievement.id}
                className={`relative p-4 rounded-lg border ${
                  achievement.earned 
                    ? "bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20" 
                    : "bg-muted/30 border-muted-foreground/20 opacity-60"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className={`p-2 rounded-lg ${getRarityColor(achievement.rarity)} bg-opacity-20`}>
                    <IconComponent className={`h-5 w-5 ${achievement.earned ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge 
                      variant={achievement.earned ? "default" : "outline"}
                      className="text-xs"
                    >
                      {achievement.rarity.toUpperCase()}
                    </Badge>
                    <span className="text-xs">
                      {getCategoryIcon(achievement.category)}
                    </span>
                  </div>
                </div>

                <h4 className={`font-semibold mb-2 ${achievement.earned ? "text-foreground" : "text-muted-foreground"}`}>
                  {achievement.title}
                </h4>
                <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                  {achievement.description}
                </p>

                {achievement.earned && achievement.earnedDate && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-primary font-medium">EARNED</span>
                    <span className="text-muted-foreground">
                      {new Date(achievement.earnedDate).toLocaleDateString()}
                    </span>
                  </div>
                )}

                {!achievement.earned && (
                  <div className="text-xs text-muted-foreground">
                    <span className="font-medium">IN PROGRESS</span>
                  </div>
                )}

                {achievement.earned && (
                  <div className="absolute -top-1 -right-1">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
          <h5 className="font-semibold mb-2 text-primary">Success Stories</h5>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• <strong>Sarah Chen</strong> - EiQ Score 782 → Google AI Research Scientist</p>
            <p>• <strong>Marcus Johnson</strong> - EiQ Score 745 → Meta ML Engineer, $180K starting</p>
            <p>• <strong>Priya Patel</strong> - EiQ Score 756 → Stanford CS PhD, full funding</p>
            <p>• <strong>Alex Rivera</strong> - EiQ Score 723 → Apple Software Engineer, promoted to Senior in 8 months</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}