import { 
  Calculator, 
  Brain, 
  Upload, 
  Sprout, 
  Rocket, 
  Crown, 
  BarChart3, 
  Headphones, 
  GraduationCap, 
  Briefcase,
  Users,
  MessageSquare,
  Zap,
  Settings 
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export default function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const mainNavigation = [
    { id: "dashboard", icon: BarChart3, label: "Learning Dashboard" },
    { id: "education-pathways", icon: GraduationCap, label: "Educational Pathways" },
    { id: "assessment", icon: Calculator, label: "Adaptive Assessment" },
    { id: "ai-tutor", icon: Brain, label: "AI Learning Assistant" },
    { id: "skill-recommendations", icon: Rocket, label: "Skill Recommendations" },
    { id: "study-groups", icon: Users, label: "Study Groups" },
    { id: "learning-progress", icon: BarChart3, label: "Learning Progress" },
    { id: "subjects", icon: Brain, label: "Subject Explorer" },
    { id: "ai-assistant", icon: MessageSquare, label: "AI Study Helper" },
    { id: "upload", icon: Upload, label: "Upload Materials" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  const educationalSubjects = [
    { icon: Calculator, label: "Mathematics", href: "#", progress: 25 },
    { icon: Brain, label: "Science & Discovery", href: "#", progress: 35 },
    { icon: MessageSquare, label: "Language Arts", href: "#", progress: 30 },
    { icon: Users, label: "Social Studies", href: "#", progress: 20 },
    { icon: Rocket, label: "Technology", href: "#", progress: 40 },
  ];

  const learningPaths = [
    { icon: Sprout, label: "Foundation", href: "#", color: "text-green-500" },
    { icon: Rocket, label: "Immersion", href: "#", color: "text-primary" },
    { icon: Crown, label: "Mastery", href: "#", color: "text-purple-500" },
  ];

  return (
    <aside className="hidden lg:block w-64 bg-secondary border-r border-border">
      <div className="p-6">
        <div className="space-y-6">
          {/* Main Navigation */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Main
            </h3>
            <nav className="space-y-2">
              {mainNavigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "flex items-center space-x-3 rounded-lg px-3 py-2 transition-colors w-full text-left",
                    activeSection === item.id
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Assessment Section */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Subjects
            </h3>
            <nav className="space-y-2">
              {educationalSubjects.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg px-3 py-2 transition-colors"
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                  <span className="ml-auto text-xs bg-muted text-muted-foreground px-2 py-1 rounded">
                    {item.progress}%
                  </span>
                </a>
              ))}
            </nav>
          </div>

          {/* Learning Paths */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Learning Paths
            </h3>
            <nav className="space-y-2">
              {learningPaths.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="flex items-center space-x-3 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg px-3 py-2 transition-colors"
                >
                  <item.icon className={cn("w-5 h-5", item.color)} />
                  <span>{item.label}</span>
                </a>
              ))}
            </nav>
          </div>
        </div>
      </div>
    </aside>
  );
}
