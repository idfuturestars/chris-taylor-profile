import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BookOpen, Play, Target, Trophy, Users, Zap, Brain, Code, Calculator, Beaker, Globe, TrendingUp, GraduationCap, Award, FlaskConical, Microscope, Rocket } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const higherEducationTracks = [
  {
    id: "undergraduate",
    name: "Undergraduate Programs",
    displayName: "Bachelor's Degree Pathways",
    description: "Comprehensive undergraduate education with AI-powered course optimization and career alignment",
    focusAreas: ["Core Requirements", "Major Specialization", "Research Experience", "Internships"],
    levels: ["Freshman", "Sophomore", "Junior", "Senior"],
    icon: "🎓",
    color: "bg-blue-500",
    subjects: ["Liberal Arts", "STEM Fields", "Business", "Social Sciences"],
    learningOutcomes: ["Critical Thinking", "Research Skills", "Professional Competency", "Interdisciplinary Knowledge"],
    duration: "4 years",
    nextSteps: ["Graduate School", "Professional Career", "Research Positions"]
  },
  {
    id: "graduate",
    name: "Graduate Studies",
    displayName: "Master's Degree & Professional Programs",
    description: "Advanced specialized education with research methodology and professional skill development",
    focusAreas: ["Advanced Coursework", "Thesis Research", "Professional Practice", "Leadership Development"],
    levels: ["Year 1: Foundations", "Year 2: Specialization", "Thesis/Capstone", "Defense/Completion"],
    icon: "📚",
    color: "bg-green-500",
    subjects: ["MBA", "MS/MA Programs", "Professional Degrees", "Research Masters"],
    learningOutcomes: ["Expert Knowledge", "Research Methodology", "Leadership Skills", "Professional Network"],
    duration: "1-3 years",
    nextSteps: ["PhD Programs", "Senior Positions", "Entrepreneurship", "Consulting"]
  },
  {
    id: "doctoral",
    name: "Doctoral Programs",
    displayName: "PhD & Professional Doctorates",
    description: "Original research contribution with dissertation and comprehensive examinations",
    focusAreas: ["Comprehensive Exams", "Original Research", "Dissertation Writing", "Academic Publications"],
    levels: ["Coursework Phase", "Qualifying Exams", "Research Phase", "Dissertation Defense"],
    icon: "🔬",
    color: "bg-purple-500",
    subjects: ["PhD Research", "Professional Doctorates", "Interdisciplinary Studies", "Joint Programs"],
    learningOutcomes: ["Research Excellence", "Academic Writing", "Teaching Skills", "Subject Mastery"],
    duration: "4-7 years",
    nextSteps: ["Postdoc Research", "Faculty Positions", "Industry R&D", "Consulting"]
  },
  {
    id: "postdoctoral",
    name: "Postdoctoral Research",
    displayName: "Post-PhD Research & Academic Career Development",
    description: "Advanced research training and academic career preparation with mentorship",
    focusAreas: ["Independent Research", "Grant Writing", "Teaching Experience", "Academic Networking"],
    levels: ["Early Postdoc", "Mid-Career", "Senior Research", "Transition Planning"],
    icon: "🚀",
    color: "bg-indigo-500",
    subjects: ["Research Leadership", "Grant Applications", "Academic Publishing", "Collaboration"],
    learningOutcomes: ["Research Independence", "Grant Success", "Academic Leadership", "Career Transition"],
    duration: "1-5 years",
    nextSteps: ["Faculty Positions", "Industry Leadership", "Research Institutes", "Entrepreneurship"]
  },
  {
    id: "professional-development",
    name: "Continuous Professional Development",
    displayName: "Lifelong Learning & Skill Enhancement",
    description: "Ongoing skill development and professional advancement throughout career",
    focusAreas: ["Executive Education", "Professional Certifications", "Industry Updates", "Leadership Training"],
    levels: ["Mid-Career", "Senior Professional", "Executive Level", "Thought Leadership"],
    icon: "📈",
    color: "bg-red-500",
    subjects: ["Executive MBA", "Professional Certificates", "Industry Conferences", "Mentorship"],
    learningOutcomes: ["Strategic Thinking", "Industry Expertise", "Leadership Excellence", "Innovation Capability"],
    duration: "Ongoing",
    nextSteps: ["C-Suite Positions", "Board Roles", "Consulting", "Teaching/Mentoring"]
  },
  {
    id: "research-innovation",
    name: "Research & Innovation Track",
    displayName: "Advanced Research & Technology Innovation",
    description: "Cutting-edge research in emerging technologies and scientific breakthroughs",
    focusAreas: ["Breakthrough Research", "Technology Transfer", "Innovation Management", "Cross-Disciplinary Work"],
    levels: ["Research Associate", "Principal Investigator", "Research Director", "Chief Scientist"],
    icon: "🔬",
    color: "bg-yellow-500",
    subjects: ["AI/ML Research", "Biotech Innovation", "Quantum Computing", "Sustainability Tech"],
    learningOutcomes: ["Scientific Innovation", "Technology Translation", "Research Leadership", "Global Impact"],
    duration: "Career-long",
    nextSteps: ["Research Institutes", "Tech Companies", "Government Labs", "Startup Founding"]
  }
];

const sampleGraduateProgress = {
  currentTrack: "doctoral",
  currentLevel: "Research Phase",
  eiqScore: 785,
  academicStanding: "Excellent",
  researchProgress: 72,
  completedCourses: 24,
  totalRequiredCourses: 30,
  publicationsCount: 3,
  currentProject: {
    title: "AI-Powered Educational Assessment Systems",
    progress: 78,
    timeToDefense: "8 months",
    advisor: "Dr. Sarah Chen",
    committee: ["Dr. Michael Roberts", "Dr. Lisa Zhang", "Dr. James Wilson"]
  },
  achievements: [
    { name: "Research Excellence Award", icon: "🏆", rarity: "Epic", year: "2024" },
    { name: "Best Paper Award", icon: "📄", rarity: "Rare", year: "2023" },
    { name: "Teaching Assistant of the Year", icon: "👨‍🏫", rarity: "Rare", year: "2023" },
    { name: "Graduate Fellowship", icon: "💰", rarity: "Epic", year: "2022" }
  ],
  recentMilestones: [
    { title: "Dissertation Proposal Defense", completed: true, date: "2024-06-15", score: 95 },
    { title: "Comprehensive Examinations", completed: true, date: "2024-03-20", score: 92 },
    { title: "Research Publication Accepted", completed: true, date: "2024-08-01", score: 88 },
    { title: "Conference Presentation", completed: false, progress: 65, deadline: "2024-12-15" }
  ],
  funding: {
    currentGrant: "NSF Graduate Research Fellowship",
    amount: "$45,000/year",
    duration: "3 years",
    status: "Active"
  }
};

export default function HigherEducationDashboard() {
  const [selectedLevel, setSelectedLevel] = useState("doctoral");
  const [selectedTrack, setSelectedTrack] = useState("doctoral");

  const { data: userProfile } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: true
  });

  const currentTrack = higherEducationTracks.find(track => track.id === selectedTrack);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <GraduationCap className="h-8 w-8 text-purple-500" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">EiQ™ powered by SikatLab™ and IDFS Pathway™</h1>
              </div>
              <Badge variant="secondary" className="text-xs">Higher Education Platform</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600 dark:text-gray-400">EiQ Score</p>
                <p className="text-xl font-bold text-purple-500">{sampleGraduateProgress.eiqScore}</p>
              </div>
              <Avatar>
                <AvatarImage src={userProfile?.profileImageUrl} />
                <AvatarFallback>
                  {userProfile?.firstName?.[0]}{userProfile?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <GraduationCap className="h-8 w-8 text-purple-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Current Level</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{sampleGraduateProgress.currentLevel}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-blue-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Research Progress</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{sampleGraduateProgress.researchProgress}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Award className="h-8 w-8 text-green-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Publications</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{sampleGraduateProgress.publicationsCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="h-8 w-8 text-orange-500" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Time to Defense</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{sampleGraduateProgress.currentProject.timeToDefense}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="progress" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="research">Research</TabsTrigger>
            <TabsTrigger value="pathways">Career Pathways</TabsTrigger>
            <TabsTrigger value="funding">Funding</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
          </TabsList>

          <TabsContent value="progress" className="space-y-6">
            {/* Current Research Project */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">Current Research Project</CardTitle>
                    <CardDescription>{sampleGraduateProgress.currentProject.title}</CardDescription>
                  </div>
                  <Badge className={currentTrack?.color}>{currentTrack?.displayName}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span>Dissertation Progress</span>
                    <span>{sampleGraduateProgress.currentProject.progress}% complete</span>
                  </div>
                  <Progress value={sampleGraduateProgress.currentProject.progress} className="h-2" />
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Advisor: </span>
                      <span className="font-medium">{sampleGraduateProgress.currentProject.advisor}</span>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Expected Defense: </span>
                      <span className="font-medium">{sampleGraduateProgress.currentProject.timeToDefense}</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Committee Members: </span>
                      <span className="text-sm">{sampleGraduateProgress.currentProject.committee.join(", ")}</span>
                    </div>
                    <Button>
                      <Play className="h-4 w-4 mr-2" />
                      Continue Research
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Academic Milestones */}
            <Card>
              <CardHeader>
                <CardTitle>Academic Milestones</CardTitle>
                <CardDescription>Key achievements and upcoming deadlines</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleGraduateProgress.recentMilestones.map((milestone, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {milestone.completed ? (
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm">✓</span>
                          </div>
                        ) : (
                          <div className="w-8 h-8 bg-orange-300 rounded-full flex items-center justify-center">
                            <span className="text-orange-800 text-sm">{milestone.progress}%</span>
                          </div>
                        )}
                        <div>
                          <p className="font-medium">{milestone.title}</p>
                          {milestone.completed ? (
                            <p className="text-sm text-green-600">
                              Completed {milestone.date} • Score: {milestone.score}%
                            </p>
                          ) : (
                            <p className="text-sm text-orange-600">Deadline: {milestone.deadline}</p>
                          )}
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        {milestone.completed ? "Review" : "Work On"}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Academic Standing */}
            <Card>
              <CardHeader>
                <CardTitle>Academic Standing</CardTitle>
                <CardDescription>Current academic performance metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{sampleGraduateProgress.academicStanding}</div>
                    <div className="text-sm text-gray-600">Overall Standing</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{sampleGraduateProgress.completedCourses}/{sampleGraduateProgress.totalRequiredCourses}</div>
                    <div className="text-sm text-gray-600">Courses Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{sampleGraduateProgress.publicationsCount}</div>
                    <div className="text-sm text-gray-600">Publications</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">{sampleGraduateProgress.eiqScore}</div>
                    <div className="text-sm text-gray-600">EiQ Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="research" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Research Tools & Resources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full justify-start" variant="outline">
                    <Microscope className="h-4 w-4 mr-2" />
                    Laboratory Management
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Brain className="h-4 w-4 mr-2" />
                    AI Research Assistant
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Literature Review
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Calculator className="h-4 w-4 mr-2" />
                    Statistical Analysis
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Publication Pipeline</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <span>Paper in Review</span>
                    <Badge variant="secondary">Under Review</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <span>Conference Abstract</span>
                    <Badge variant="secondary">In Progress</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <span>Book Chapter</span>
                    <Badge variant="secondary">Planning</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="pathways" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {higherEducationTracks.map((track) => (
                <Card 
                  key={track.id} 
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    selectedTrack === track.id ? 'ring-2 ring-purple-500' : ''
                  }`}
                  onClick={() => setSelectedTrack(track.id)}
                >
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{track.icon}</div>
                      <div>
                        <CardTitle className="text-lg">{track.displayName}</CardTitle>
                        <CardDescription className="text-sm">{track.duration}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{track.description}</p>
                    <div className="space-y-2">
                      <div>
                        <span className="text-xs font-medium text-gray-500">Focus Areas:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {track.focusAreas.slice(0, 3).map((area, index) => (
                            <Badge key={index} variant="outline" className="text-xs">{area}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-500">Next Steps:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {track.nextSteps.slice(0, 2).map((step, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">{step}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="funding" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Funding</CardTitle>
                <CardDescription>Active grants and financial support</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold">{sampleGraduateProgress.funding.currentGrant}</h4>
                      <Badge className="bg-green-500">{sampleGraduateProgress.funding.status}</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Amount: </span>
                        <span className="font-medium">{sampleGraduateProgress.funding.amount}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Duration: </span>
                        <span className="font-medium">{sampleGraduateProgress.funding.duration}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Funding Opportunities</CardTitle>
                <CardDescription>Available grants and fellowship opportunities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">NIH Graduate Fellowship</p>
                      <p className="text-sm text-gray-600">Deadline: March 15, 2025</p>
                    </div>
                    <Button size="sm">Apply</Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Research Conference Grant</p>
                      <p className="text-sm text-gray-600">Deadline: January 30, 2025</p>
                    </div>
                    <Button size="sm">Apply</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Academic Network</CardTitle>
                  <CardDescription>Your research and professional connections</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>SC</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">Dr. Sarah Chen</p>
                        <p className="text-sm text-gray-600">Dissertation Advisor</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>MR</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">Dr. Michael Roberts</p>
                        <p className="text-sm text-gray-600">Committee Member</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>LZ</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">Dr. Lisa Zhang</p>
                        <p className="text-sm text-gray-600">Research Collaborator</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Professional Development</CardTitle>
                  <CardDescription>Upcoming conferences and networking events</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <p className="font-medium">International AI Conference 2025</p>
                      <p className="text-sm text-gray-600">March 15-18, 2025 • San Francisco</p>
                      <Badge variant="outline" className="mt-2">Speaking</Badge>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <p className="font-medium">Graduate Research Symposium</p>
                      <p className="text-sm text-gray-600">April 5-6, 2025 • Virtual</p>
                      <Badge variant="outline" className="mt-2">Attending</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}