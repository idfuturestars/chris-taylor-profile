import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BookOpen, Play, Target, Trophy, Users, Zap, Brain, Code, Calculator, Beaker, Globe, TrendingUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const k12LearningTracks = [
  {
    id: "mathematics",
    name: "Mathematics & Logic",
    displayName: "Mathematical Thinking & Problem Solving",
    description: "Build strong mathematical foundations with AI-powered adaptive learning",
    focusAreas: ["Number Sense", "Algebra", "Geometry", "Statistics"],
    ageRanges: ["K-2: Counting & Shapes", "3-5: Basic Operations", "6-8: Pre-Algebra", "9-12: Advanced Math"],
    icon: "🔢",
    color: "bg-blue-500",
    subjects: ["Arithmetic", "Algebra", "Geometry", "Calculus"],
    learningOutcomes: ["Problem Solving", "Logical Thinking", "Mathematical Reasoning", "Data Analysis"]
  },
  {
    id: "science",
    name: "Science & Discovery", 
    displayName: "Scientific Inquiry & Exploration",
    description: "Explore the natural world through hands-on experiments and AI-guided discovery",
    focusAreas: ["Scientific Method", "Life Sciences", "Physical Sciences", "Earth Sciences"],
    ageRanges: ["K-2: Nature Exploration", "3-5: Simple Experiments", "6-8: Scientific Method", "9-12: Advanced Research"],
    icon: "🔬",
    color: "bg-green-500",
    subjects: ["Biology", "Chemistry", "Physics", "Environmental Science"],
    learningOutcomes: ["Critical Thinking", "Hypothesis Testing", "Data Collection", "Scientific Reasoning"]
  },
  {
    id: "technology",
    name: "Technology & Computing",
    displayName: "Digital Literacy & Programming", 
    description: "Learn computational thinking and digital skills for the modern world",
    focusAreas: ["Programming Basics", "Digital Citizenship", "Creative Computing", "Problem Solving"],
    ageRanges: ["K-2: Digital Awareness", "3-5: Basic Coding", "6-8: Programming Projects", "9-12: Advanced Computing"],
    icon: "💻",
    color: "bg-purple-500",
    subjects: ["Computer Science", "Digital Design", "Robotics", "AI Fundamentals"],
    learningOutcomes: ["Computational Thinking", "Digital Literacy", "Creative Problem Solving", "Technical Skills"]
  },
  {
    id: "language-arts",
    name: "Language Arts & Communication",
    displayName: "Reading, Writing & Communication Skills",
    description: "Develop strong literacy and communication skills through interactive learning",
    focusAreas: ["Reading Comprehension", "Creative Writing", "Grammar", "Communication"],
    ageRanges: ["K-2: Basic Reading", "3-5: Reading Fluency", "6-8: Critical Analysis", "9-12: Advanced Writing"],
    icon: "📚",
    color: "bg-indigo-500", 
    subjects: ["Literature", "Writing", "Grammar", "Public Speaking"],
    learningOutcomes: ["Reading Comprehension", "Writing Skills", "Critical Analysis", "Effective Communication"]
  },
  {
    id: "social-studies",
    name: "Social Studies & Global Awareness",
    displayName: "History, Geography & Cultural Understanding",
    description: "Explore world cultures, history, and develop global citizenship skills",
    focusAreas: ["World History", "Geography", "Civics", "Cultural Studies"],
    ageRanges: ["K-2: Community Helpers", "3-5: Local History", "6-8: World Cultures", "9-12: Global Issues"],
    icon: "🌍",
    color: "bg-red-500",
    subjects: ["History", "Geography", "Government", "Economics"],
    learningOutcomes: ["Cultural Awareness", "Historical Thinking", "Geographic Literacy", "Civic Engagement"]
  },
  {
    id: "arts-creativity",
    name: "Arts & Creative Expression",
    displayName: "Visual Arts, Music & Creative Thinking",
    description: "Develop artistic skills and creative expression through multiple mediums",
    focusAreas: ["Visual Arts", "Music", "Drama", "Creative Writing"],
    ageRanges: ["K-2: Art Exploration", "3-5: Creative Skills", "6-8: Artistic Expression", "9-12: Advanced Arts"],
    icon: "🎨",
    color: "bg-yellow-500",
    subjects: ["Drawing", "Music", "Drama", "Digital Art"],
    learningOutcomes: ["Creative Expression", "Artistic Skills", "Cultural Appreciation", "Innovation"]
  }
];

const sampleStudentProgress = {
  currentTrack: "science",
  eiqScore: 485,
  masteryLevel: "Proficient",
  learningStreak: 23,
  completedModules: 12,
  totalModules: 28,
  weeklyGoal: 5,
  currentModule: {
    name: "Scientific Method & Hypothesis Testing",
    progress: 68,
    timeRemaining: "2 hours"
  },
  achievements: [
    { name: "Science Explorer", icon: "🔬", rarity: "Common" },
    { name: "Logic Master", icon: "🧠", rarity: "Rare" },
    { name: "Learning Champion", icon: "🏆", rarity: "Epic" }
  ],
  recentLessons: [
    { title: "Scientific Observation Skills", completed: true, score: 92 },
    { title: "Forming Hypotheses", completed: true, score: 88 },
    { title: "Conducting Experiments", completed: false, progress: 45 }
  ]
};

export default function K12Dashboard() {
  const [selectedGradeLevel, setSelectedGradeLevel] = useState("6-8");
  const [selectedTrack, setSelectedTrack] = useState("science");

  const { data: userProfile } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: true
  });

  const currentTrack = k12LearningTracks.find(track => track.id === selectedTrack);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Brain className="h-8 w-8 text-green-500" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">EiQ™ powered by SikatLab™ and IDFS Pathway™</h1>
              </div>
              <Badge variant="secondary" className="text-xs">K-12 Learning Platform</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600 dark:text-gray-400">EiQ Score</p>
                <p className="text-xl font-bold text-green-500">{sampleStudentProgress.eiqScore}</p>
              </div>
              <Avatar>
                <AvatarImage src={(userProfile as any)?.profileImageUrl} />
                <AvatarFallback>
                  {(userProfile as any)?.firstName?.[0] || 'U'}{(userProfile as any)?.lastName?.[0] || 'S'}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Zap className="h-8 w-8 text-yellow-500" />
                <div className="ml-4">
                  <p className="text-2xl font-bold">{sampleStudentProgress.learningStreak}</p>
                  <p className="text-gray-600 dark:text-gray-400">Day Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="h-8 w-8 text-blue-500" />
                <div className="ml-4">
                  <p className="text-2xl font-bold">{sampleStudentProgress.completedModules}/{sampleStudentProgress.totalModules}</p>
                  <p className="text-gray-600 dark:text-gray-400">Modules</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Trophy className="h-8 w-8 text-purple-500" />
                <div className="ml-4">
                  <p className="text-2xl font-bold">{sampleStudentProgress.achievements.length}</p>
                  <p className="text-gray-600 dark:text-gray-400">Achievements</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-green-500" />
                <div className="ml-4">
                  <p className="text-2xl font-bold">{sampleStudentProgress.masteryLevel}</p>
                  <p className="text-gray-600 dark:text-gray-400">Mastery</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="learning" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="tracks">Industry Tracks</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="community">Community</TabsTrigger>
          </TabsList>

          <TabsContent value="learning" className="space-y-6">
            {/* Current Module Progress */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">Continue Learning</CardTitle>
                    <CardDescription>{sampleStudentProgress.currentModule.name}</CardDescription>
                  </div>
                  <Badge className={currentTrack?.color}>{currentTrack?.displayName}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{sampleStudentProgress.currentModule.progress}% complete</span>
                  </div>
                  <Progress value={sampleStudentProgress.currentModule.progress} className="h-2" />
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {sampleStudentProgress.currentModule.timeRemaining} remaining
                    </span>
                    <Button>
                      <Play className="h-4 w-4 mr-2" />
                      Continue
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Learning Hub</CardTitle>
                <CardDescription>Access your personalized learning tools</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Link href="/assessment">
                    <Card className="hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Target className="h-8 w-8 text-blue-500" />
                          <div>
                            <p className="font-semibold">EiQ Assessment</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Test your abilities</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link href="/ai-tutor">
                    <Card className="hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Brain className="h-8 w-8 text-green-500" />
                          <div>
                            <p className="font-semibold">AI Tutor</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Get personalized help</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link href="/skills">
                    <Card className="hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="h-8 w-8" />
                          <div>
                            <p className="font-semibold">Skill Recommendations</p>
                            <p className="text-sm text-purple-100">AI-powered learning path</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Grade Level Selector */}
            <Card>
              <CardHeader>
                <CardTitle>Select Your Grade Level</CardTitle>
                <CardDescription>Choose your current academic level for personalized content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {["K-2", "3-5", "6-8", "9-12"].map((level) => (
                    <Button
                      key={level}
                      variant={selectedGradeLevel === level ? "default" : "outline"}
                      onClick={() => setSelectedGradeLevel(level)}
                      className="h-16"
                    >
                      <div className="text-center">
                        <div className="text-lg font-bold">{level}</div>
                        <div className="text-xs">
                          {level === "K-2" && "Ages 5-7"}
                          {level === "3-5" && "Ages 8-10"} 
                          {level === "6-8" && "Ages 11-13"}
                          {level === "9-12" && "Ages 14-18"}
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Lessons */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Lessons</CardTitle>
                <CardDescription>Your latest learning activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleStudentProgress.recentLessons.map((lesson, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {lesson.completed ? (
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm">✓</span>
                          </div>
                        ) : (
                          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                            <span className="text-gray-600 text-sm">{lesson.progress}%</span>
                          </div>
                        )}
                        <div>
                          <p className="font-medium">{lesson.title}</p>
                          {lesson.completed ? (
                            <p className="text-sm text-green-600">Score: {lesson.score}%</p>
                          ) : (
                            <p className="text-sm text-gray-600">In Progress</p>
                          )}
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        {lesson.completed ? "Review" : "Continue"}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tracks" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {k12LearningTracks.map((track) => (
                <Card 
                  key={track.id} 
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    selectedTrack === track.id ? 'ring-2 ring-green-500' : ''
                  }`}
                  onClick={() => setSelectedTrack(track.id)}
                >
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{track.icon}</div>
                      <div>
                        <CardTitle className="text-lg">{track.displayName}</CardTitle>
                        <CardDescription className="text-sm">{track.name}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{track.description}</p>
                    
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium mb-2">Focus Areas:</p>
                        <div className="flex flex-wrap gap-1">
                          {track.focusAreas.slice(0, 2).map((area, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {area}
                            </Badge>
                          ))}
                          {track.focusAreas.length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{track.focusAreas.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div>
                        <p className="text-sm font-medium mb-2">Career Outcomes:</p>
                        <div className="flex flex-wrap gap-1">
                          {track.careerOutcomes.slice(0, 2).map((outcome, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {outcome}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <Button 
                      className="w-full mt-4" 
                      variant={selectedTrack === track.id ? "default" : "outline"}
                    >
                      {selectedTrack === track.id ? "Current Track" : "Explore Track"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Selected Track Details */}
            {currentTrack && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <span className="text-2xl">{currentTrack.icon}</span>
                    <span>{currentTrack.displayName} - Age-Specific Learning</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {currentTrack.ageRanges.map((range, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <p className="font-medium text-sm mb-2">{range}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            {/* Learning Analytics */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Mastery Progress</CardTitle>
                  <CardDescription>Your progress across different subjects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { subject: "Mathematics", level: "Proficient", progress: 78 },
                      { subject: "Programming", level: "Familiar", progress: 45 },
                      { subject: "Logic & Reasoning", level: "Mastered", progress: 95 },
                      { subject: "AI Concepts", level: "Attempted", progress: 25 }
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">{item.subject}</span>
                          <Badge variant={
                            item.level === "Mastered" ? "default" :
                            item.level === "Proficient" ? "secondary" :
                            item.level === "Familiar" ? "outline" : "destructive"
                          }>
                            {item.level}
                          </Badge>
                        </div>
                        <Progress value={item.progress} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                  <CardDescription>Your learning milestones</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {sampleStudentProgress.achievements.map((achievement, index) => (
                      <div key={index} className="text-center p-3 border rounded-lg">
                        <div className="text-2xl mb-2">{achievement.icon}</div>
                        <p className="text-xs font-medium">{achievement.name}</p>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {achievement.rarity}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Goals */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Learning Goals</CardTitle>
                <CardDescription>Stay on track with your learning objectives</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Complete {sampleStudentProgress.weeklyGoal} lessons this week</span>
                    <Badge>3/{sampleStudentProgress.weeklyGoal}</Badge>
                  </div>
                  <Progress value={60} className="h-2" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    You're 60% of the way to your weekly goal. Keep it up!
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="community" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Global Leaderboard</CardTitle>
                  <CardDescription>See how you rank globally</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { rank: 1, name: "Alex Chen", score: 892, track: "Page/Pichai" },
                      { rank: 2, name: "Sofia Rodriguez", score: 847, track: "Jobs/Cook" },
                      { rank: 3, name: "David Kim", score: 823, track: "Gates/Ballmer" },
                      { rank: 47, name: "You", score: 485, track: "Page/Pichai", highlight: true }
                    ].map((student, index) => (
                      <div 
                        key={index} 
                        className={`flex items-center justify-between p-3 rounded-lg ${
                          student.highlight ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-gray-50 dark:bg-gray-800'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                            student.rank === 1 ? 'bg-yellow-500 text-white' :
                            student.rank === 2 ? 'bg-gray-400 text-white' :
                            student.rank === 3 ? 'bg-amber-600 text-white' :
                            'bg-gray-200 text-gray-700'
                          }`}>
                            {student.rank}
                          </div>
                          <div>
                            <p className="font-medium">{student.name}</p>
                            <p className="text-xs text-gray-600 dark:text-gray-400">{student.track}</p>
                          </div>
                        </div>
                        <Badge variant="outline">{student.score}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Study Groups</CardTitle>
                  <CardDescription>Join collaborative learning sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { name: "AI Explorers", members: 12, topic: "Machine Learning Basics", active: true },
                      { name: "Math Masters", members: 8, topic: "Algebra Challenge", active: false },
                      { name: "Code Warriors", members: 15, topic: "Programming Projects", active: true }
                    ].map((group, index) => (
                      <div key={index} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{group.name}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{group.topic}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4" />
                            <span className="text-sm">{group.members}</span>
                            {group.active && <div className="w-2 h-2 bg-green-500 rounded-full"></div>}
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full">
                          {group.active ? "Join Session" : "View Group"}
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}