import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Mic, MicOff, Play, Square, Brain, Volume2, FileAudio, Zap, Target, TrendingUp, AlertCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VoiceAnalysis {
  id: string;
  transcript: string;
  confidence: number;
  duration: number;
  aiAnalysis: {
    comprehension: number;
    articulation: number;
    vocabulary: number;
    fluency: number;
    technicalAccuracy: number;
    overallScore: number;
    insights: string[];
    recommendations: string[];
    skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  };
  timestamp: string;
}

interface VoicePrompt {
  id: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  prompt: string;
  expectedKeywords: string[];
  timeLimit: number;
}

const voicePrompts: VoicePrompt[] = [
  {
    id: "tech_1",
    category: "Technical Communication",
    difficulty: "medium",
    prompt: "Explain how machine learning algorithms work and their applications in modern technology.",
    expectedKeywords: ["algorithm", "data", "training", "model", "prediction", "artificial intelligence"],
    timeLimit: 120
  },
  {
    id: "problem_1",
    category: "Problem Solving",
    difficulty: "hard",
    prompt: "Describe your approach to debugging a complex software issue in a production environment.",
    expectedKeywords: ["debugging", "logs", "testing", "reproduction", "systematic", "monitoring"],
    timeLimit: 180
  },
  {
    id: "leadership_1",
    category: "Leadership",
    difficulty: "medium",
    prompt: "How would you lead a team through a challenging project with tight deadlines?",
    expectedKeywords: ["delegation", "communication", "prioritization", "motivation", "planning"],
    timeLimit: 150
  }
];

export default function VoiceAssessment() {
  const [isRecording, setIsRecording] = useState(false);
  const [currentPrompt, setCurrentPrompt] = useState<VoicePrompt | null>(null);
  const [transcript, setTranscript] = useState("");
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<VoiceAnalysis[]>([]);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const timerRef = useRef<NodeJS.Timeout>();
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch voice assessment history
  const { data: assessmentHistory, isLoading } = useQuery({
    queryKey: ["/api/voice-assessments"],
  });

  // Voice analysis mutation
  const analyzeVoiceMutation = useMutation({
    mutationFn: async (data: { transcript: string; audioBlob: Blob; promptId: string; duration: number }) => {
      const formData = new FormData();
      formData.append('transcript', data.transcript);
      formData.append('audio', data.audioBlob, 'recording.wav');
      formData.append('promptId', data.promptId);
      formData.append('duration', data.duration.toString());

      return apiRequest("/api/voice-assessments/analyze", {
        method: "POST",
        body: formData,
      });
    },
    onSuccess: (result) => {
      setAnalysisResults(prev => [result, ...prev]);
      toast({
        title: "Voice Analysis Complete!",
        description: `Overall Score: ${Math.round(result.aiAnalysis.overallScore)}% - ${result.aiAnalysis.skillLevel}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/voice-assessments"] });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze voice recording. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          }
        }
        if (finalTranscript) {
          setTranscript(prev => prev + finalTranscript);
        }
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        toast({
          title: "Voice Recognition Error",
          description: "Please check your microphone permissions.",
          variant: "destructive",
        });
      };

      recognitionRef.current = recognition;
    } else {
      toast({
        title: "Voice Recognition Not Supported",
        description: "Please use a modern browser with voice recognition support.",
        variant: "destructive",
      });
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [toast]);

  // Recording timer
  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording]);

  const startRecording = async () => {
    if (!currentPrompt) {
      toast({
        title: "No Prompt Selected",
        description: "Please select a voice prompt first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      setMediaRecorder(recorder);
      recorder.start();
      
      // Start speech recognition
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }

      setIsRecording(true);
      setRecordingTime(0);
      setTranscript("");

      toast({
        title: "Recording Started",
        description: "Speak clearly and answer the prompt thoroughly.",
      });
    } catch (error) {
      toast({
        title: "Microphone Access Denied",
        description: "Please allow microphone access to use voice assessment.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.stop();
    }
    
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    setIsRecording(false);
    
    toast({
      title: "Recording Stopped",
      description: "Processing your response for AI analysis...",
    });

    // Auto-submit for analysis
    setTimeout(() => {
      if (audioBlob && transcript && currentPrompt) {
        analyzeVoiceMutation.mutate({
          transcript,
          audioBlob,
          promptId: currentPrompt.id,
          duration: recordingTime
        });
      }
    }, 1000);
  };

  const playRecording = () => {
    if (audioBlob && audioRef.current) {
      const url = URL.createObjectURL(audioBlob);
      audioRef.current.src = url;
      audioRef.current.play();
      setIsPlaying(true);

      audioRef.current.onended = () => {
        setIsPlaying(false);
        URL.revokeObjectURL(url);
      };
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const selectPrompt = (prompt: VoicePrompt) => {
    setCurrentPrompt(prompt);
    setTranscript("");
    setAudioBlob(null);
    setRecordingTime(0);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Mic className="h-8 w-8 text-purple-500" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Voice Assessment with AI Analysis</h1>
              </div>
              <Badge variant="secondary" className="text-xs">AI-Powered Speech Analysis</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600 dark:text-gray-400">Assessments Completed</p>
                <p className="text-xl font-bold text-purple-500">{analysisResults.length}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="assessment" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="assessment">Voice Assessment</TabsTrigger>
            <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
            <TabsTrigger value="history">Assessment History</TabsTrigger>
          </TabsList>

          <TabsContent value="assessment" className="space-y-6">
            {/* Prompt Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Assessment Prompt</CardTitle>
                <CardDescription>Choose a category and prompt for your voice assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {voicePrompts.map((prompt) => (
                    <Card 
                      key={prompt.id} 
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        currentPrompt?.id === prompt.id ? 'ring-2 ring-purple-500 bg-purple-50 dark:bg-purple-900/20' : ''
                      }`}
                      onClick={() => selectPrompt(prompt)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{prompt.category}</CardTitle>
                            <Badge variant={prompt.difficulty === 'easy' ? 'default' : prompt.difficulty === 'medium' ? 'secondary' : 'destructive'}>
                              {prompt.difficulty}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            {formatTime(prompt.timeLimit)}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-700 dark:text-gray-300">{prompt.prompt}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recording Interface */}
            {currentPrompt && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Volume2 className="h-5 w-5 mr-2" />
                    {currentPrompt.category} Assessment
                  </CardTitle>
                  <CardDescription>{currentPrompt.prompt}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Recording Controls */}
                  <div className="flex items-center justify-center space-x-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-500 mb-2">
                        {formatTime(recordingTime)}
                      </div>
                      <div className="text-sm text-gray-600">
                        Limit: {formatTime(currentPrompt.timeLimit)}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center space-x-4">
                    {!isRecording ? (
                      <Button
                        onClick={startRecording}
                        size="lg"
                        className="bg-red-500 hover:bg-red-600 text-white"
                      >
                        <Mic className="h-5 w-5 mr-2" />
                        Start Recording
                      </Button>
                    ) : (
                      <Button
                        onClick={stopRecording}
                        size="lg"
                        variant="outline"
                        className="border-red-500 text-red-500 hover:bg-red-50"
                      >
                        <Square className="h-5 w-5 mr-2" />
                        Stop Recording
                      </Button>
                    )}

                    {audioBlob && !isRecording && (
                      <Button
                        onClick={playRecording}
                        size="lg"
                        variant="outline"
                        disabled={isPlaying}
                      >
                        <Play className="h-5 w-5 mr-2" />
                        {isPlaying ? 'Playing...' : 'Play Recording'}
                      </Button>
                    )}
                  </div>

                  {/* Live Transcript */}
                  {(transcript || isRecording) && (
                    <Card className="bg-gray-50 dark:bg-gray-800">
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center">
                          <FileAudio className="h-5 w-5 mr-2" />
                          Live Transcript
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="max-h-40 overflow-y-auto">
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            {transcript || "Start speaking to see live transcript..."}
                            {isRecording && <span className="animate-pulse text-red-500">●</span>}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Processing Status */}
                  {analyzeVoiceMutation.isPending && (
                    <Alert>
                      <Brain className="h-4 w-4" />
                      <AlertDescription>
                        AI is analyzing your voice recording for communication skills, technical accuracy, and fluency...
                      </AlertDescription>
                    </Alert>
                  )}

                  <audio ref={audioRef} className="hidden" />
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            {analysisResults.length > 0 ? (
              <div className="space-y-6">
                {analysisResults.map((analysis) => (
                  <Card key={analysis.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center">
                            <Brain className="h-5 w-5 mr-2 text-purple-500" />
                            AI Voice Analysis Results
                          </CardTitle>
                          <CardDescription>
                            {new Date(analysis.timestamp).toLocaleDateString()} - Duration: {Math.round(analysis.duration)}s
                          </CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-purple-500">
                            {Math.round(analysis.aiAnalysis.overallScore)}%
                          </div>
                          <Badge variant={analysis.aiAnalysis.skillLevel === 'expert' ? 'default' : 'secondary'}>
                            {analysis.aiAnalysis.skillLevel}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Skill Breakdown */}
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Comprehension</div>
                          <Progress value={analysis.aiAnalysis.comprehension} className="h-2" />
                          <div className="text-xs text-gray-600">{analysis.aiAnalysis.comprehension}%</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Articulation</div>
                          <Progress value={analysis.aiAnalysis.articulation} className="h-2" />
                          <div className="text-xs text-gray-600">{analysis.aiAnalysis.articulation}%</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Vocabulary</div>
                          <Progress value={analysis.aiAnalysis.vocabulary} className="h-2" />
                          <div className="text-xs text-gray-600">{analysis.aiAnalysis.vocabulary}%</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Fluency</div>
                          <Progress value={analysis.aiAnalysis.fluency} className="h-2" />
                          <div className="text-xs text-gray-600">{analysis.aiAnalysis.fluency}%</div>
                        </div>
                        <div className="space-y-2">
                          <div className="text-sm font-medium">Technical Accuracy</div>
                          <Progress value={analysis.aiAnalysis.technicalAccuracy} className="h-2" />
                          <div className="text-xs text-gray-600">{analysis.aiAnalysis.technicalAccuracy}%</div>
                        </div>
                      </div>

                      {/* AI Insights */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-medium mb-3 flex items-center">
                            <Zap className="h-4 w-4 mr-2 text-yellow-500" />
                            Key Insights
                          </h4>
                          <div className="space-y-2">
                            {analysis.aiAnalysis.insights.map((insight, index) => (
                              <div key={index} className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                <p className="text-sm">{insight}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-medium mb-3 flex items-center">
                            <Target className="h-4 w-4 mr-2 text-green-500" />
                            Recommendations
                          </h4>
                          <div className="space-y-2">
                            {analysis.aiAnalysis.recommendations.map((rec, index) => (
                              <div key={index} className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                <p className="text-sm">{rec}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Transcript */}
                      <div>
                        <h4 className="font-medium mb-3">Full Transcript</h4>
                        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <p className="text-sm text-gray-700 dark:text-gray-300">{analysis.transcript}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No Analysis Results</h3>
                  <p className="text-gray-600 dark:text-gray-400">Complete a voice assessment to see AI analysis results.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Assessment History</CardTitle>
                <CardDescription>Track your progress across multiple voice assessments</CardDescription>
              </CardHeader>
              <CardContent>
                {assessmentHistory?.length > 0 ? (
                  <div className="space-y-4">
                    {assessmentHistory.map((assessment: any, index: number) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{assessment.category}</p>
                            <p className="text-sm text-gray-600">{assessment.date}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-purple-500">{assessment.score}%</p>
                            <Badge variant="outline">{assessment.level}</Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileAudio className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No History Available</h3>
                    <p className="text-gray-600 dark:text-gray-400">Complete voice assessments to build your history.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}