import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Send, Lightbulb, BookOpen, Code, Calculator, Beaker, Target, Users, Zap } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ChatMessage {
  id: string;
  role: "user" | "ai";
  content: string;
  timestamp: Date;
  type?: "explanation" | "hint" | "practice" | "encouragement";
  metadata?: {
    subject?: string;
    difficulty?: number;
    concepts?: string[];
  };
}

interface TutoringSession {
  id: string;
  sessionType: "khan_style_lesson" | "adaptive_practice" | "project_mode" | "diagnostic";
  subject: string;
  gradeLevel: string;
  currentEiQScore: number;
  targetEiQScore: number;
  masteryLevel: string;
  learningGaps: string[];
  progressMetrics: {
    questionsAnswered: number;
    correctAnswers: number;
    hintsUsed: number;
    timeSpent: number;
  };
}

const sampleSession: TutoringSession = {
  id: "session-1",
  sessionType: "khan_style_lesson",
  subject: "mathematics",
  gradeLevel: "6-8",
  currentEiQScore: 485,
  targetEiQScore: 550,
  masteryLevel: "familiar",
  learningGaps: ["algebraic reasoning", "word problems", "fraction operations"],
  progressMetrics: {
    questionsAnswered: 12,
    correctAnswers: 9,
    hintsUsed: 3,
    timeSpent: 25
  }
};

const initialMessages: ChatMessage[] = [
  {
    id: "welcome",
    role: "ai",
    content: "Hi! I'm your AI tutor for the Page/Pichai track. I see you're working on algebraic reasoning. Let's start with something fun - imagine you're Google's newest engineer and need to solve this problem!\n\nIf a search algorithm processes x queries per second, and it needs to handle 1000 queries, how would you write an equation to find the time needed?",
    timestamp: new Date(),
    type: "explanation",
    metadata: {
      subject: "mathematics",
      difficulty: 2.5,
      concepts: ["algebra", "real-world-applications"]
    }
  }
];

const tutorPersonalities = {
  "jobs-cook": {
    name: "Design Mentor",
    avatar: "🍎",
    style: "Creative and innovation-focused, connects math to product design",
    greeting: "Let's think like designers! Every equation is a blueprint for innovation."
  },
  "page-pichai": {
    name: "Algorithm Guide", 
    avatar: "🔍",
    style: "Logical and systematic, relates concepts to search and AI",
    greeting: "Welcome! Let's explore how these concepts power Google's algorithms."
  },
  "gates-ballmer": {
    name: "Code Architect",
    avatar: "💻", 
    style: "Structured and practical, emphasizes software applications",
    greeting: "Time to build! Let's see how this math becomes powerful software."
  },
  "zuck-huang": {
    name: "Virtual Reality Coach",
    avatar: "🌐",
    style: "Interactive and visual, connects to gaming and VR",
    greeting: "Ready to level up? These concepts will power your VR worlds!"
  },
  "ellison-catz": {
    name: "Data Strategist", 
    avatar: "🗄️",
    style: "Analytical and business-focused, ties to enterprise solutions",
    greeting: "Let's unlock the power of data! Every formula tells a business story."
  },
  "buffet-apfel": {
    name: "Financial Analyst",
    avatar: "💰",
    style: "Practical and investment-focused, relates to financial calculations",
    greeting: "Smart investments start with smart math. Let's calculate success!"
  }
};

export default function AITutor() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [currentTrack, setCurrentTrack] = useState("page-pichai");
  const [sessionMode, setSessionMode] = useState<"lesson" | "practice" | "help">("lesson");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const tutor = tutorPersonalities[currentTrack as keyof typeof tutorPersonalities];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("/api/ai/tutor-chat", "POST", {
        message,
        sessionId: sampleSession.id,
        track: currentTrack,
        mode: sessionMode,
        context: {
          subject: sampleSession.subject,
          gradeLevel: sampleSession.gradeLevel,
          masteryLevel: sampleSession.masteryLevel,
          learningGaps: sampleSession.learningGaps
        }
      });
      return response;
    },
    onMutate: () => {
      setIsTyping(true);
    },
    onSuccess: (response) => {
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: "ai",
        content: response.content || "I understand. Let me help you with that!",
        timestamp: new Date(),
        type: response.type || "explanation",
        metadata: response.metadata
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    },
    onError: () => {
      const errorMessage: ChatMessage = {
        id: `ai-error-${Date.now()}`,
        role: "ai", 
        content: "I'm having trouble connecting right now, but let's keep learning! Can you try rephrasing your question?",
        timestamp: new Date(),
        type: "encouragement"
      };
      setMessages(prev => [...prev, errorMessage]);
      setIsTyping(false);
    }
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    sendMessageMutation.mutate(inputMessage);
    setInputMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const suggestedQuestions = [
    "Can you explain this step by step?",
    "I need a hint for this problem",
    "Show me a real-world example",
    "Can we try a practice problem?",
    "Why is this concept important?"
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <Brain className="h-8 w-8 text-green-500" />
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">AI Tutor</h1>
                  <p className="text-gray-600 dark:text-gray-400">Personalized Learning with {tutor.name}</p>
                </div>
              </div>
              <div className="text-4xl">{tutor.avatar}</div>
            </div>

            <div className="flex items-center space-x-4">
              <Badge variant="secondary">EiQ: {sampleSession.currentEiQScore}</Badge>
              <Badge variant="outline">Target: {sampleSession.targetEiQScore}</Badge>
            </div>
          </div>

          {/* Session Modes */}
          <Tabs value={sessionMode} onValueChange={(value) => setSessionMode(value as any)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="lesson">
                <BookOpen className="h-4 w-4 mr-2" />
                Lesson Mode
              </TabsTrigger>
              <TabsTrigger value="practice">
                <Target className="h-4 w-4 mr-2" />
                Practice Mode
              </TabsTrigger>
              <TabsTrigger value="help">
                <Lightbulb className="h-4 w-4 mr-2" />
                Help Mode
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>{tutor.name}</span>
                  <Badge className="capitalize">{sessionMode} Mode</Badge>
                </CardTitle>
                <CardDescription>{tutor.greeting}</CardDescription>
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col">
                {/* Messages */}
                <ScrollArea className="flex-1 pr-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div className={`flex space-x-3 max-w-[80%] ${
                          message.role === "user" ? "flex-row-reverse space-x-reverse" : ""
                        }`}>
                          <Avatar className="w-8 h-8">
                            {message.role === "ai" ? (
                              <AvatarFallback>{tutor.avatar}</AvatarFallback>
                            ) : (
                              <AvatarFallback>U</AvatarFallback>
                            )}
                          </Avatar>
                          <div
                            className={`rounded-lg px-4 py-2 ${
                              message.role === "user"
                                ? "bg-green-500 text-white"
                                : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white"
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                            {message.metadata?.concepts && (
                              <div className="mt-2 flex flex-wrap gap-1">
                                {message.metadata.concepts.map((concept, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {concept}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="flex space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarFallback>{tutor.avatar}</AvatarFallback>
                          </Avatar>
                          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-2">
                            <div className="flex space-x-1">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: "0.1s"}}></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: "0.2s"}}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Suggested Questions */}
                <div className="mt-4 mb-4">
                  <div className="flex flex-wrap gap-2">
                    {suggestedQuestions.map((question, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setInputMessage(question)}
                        className="text-xs"
                      >
                        {question}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Input */}
                <div className="flex space-x-2">
                  <Textarea
                    placeholder="Ask me anything about this topic..."
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    rows={2}
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!inputMessage.trim() || sendMessageMutation.isPending}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Session Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Session Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Questions Answered</span>
                    <Badge>{sampleSession.progressMetrics.questionsAnswered}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Accuracy</span>
                    <Badge variant="secondary">
                      {Math.round((sampleSession.progressMetrics.correctAnswers / sampleSession.progressMetrics.questionsAnswered) * 100)}%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Hints Used</span>
                    <Badge variant="outline">{sampleSession.progressMetrics.hintsUsed}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Time Spent</span>
                    <Badge variant="outline">{sampleSession.progressMetrics.timeSpent}m</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Learning Gaps */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Focus Areas</CardTitle>
                <CardDescription>Areas we're working on today</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sampleSession.learningGaps.map((gap, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Target className="h-4 w-4 text-orange-500" />
                      <span className="text-sm capitalize">{gap.replace('-', ' ')}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Calculator className="h-4 w-4 mr-2" />
                    Practice Problems
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Code className="h-4 w-4 mr-2" />
                    Code Examples
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Beaker className="h-4 w-4 mr-2" />
                    Experiments
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Users className="h-4 w-4 mr-2" />
                    Study Group
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Today's Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                      <Zap className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Problem Solver</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Solved 5 algebra problems</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <Brain className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Quick Learner</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Mastered new concept</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}