import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Brain, Target, TrendingUp, BookOpen, Clock, Star, Zap, Award, Users, ChevronRight, Play, CheckCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SkillRecommendation {
  id: string;
  skillName: string;
  category: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  confidence: number;
  estimatedTimeToComplete: string;
  prerequisites: string[];
  learningPath: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  relevanceScore: number;
  industryDemand: number;
  careerImpact: number;
  reasoning: string;
  relatedSkills: string[];
  resources: {
    type: string;
    title: string;
    provider: string;
    duration: string;
    rating: number;
  }[];
}

interface UserSkillProfile {
  currentSkills: string[];
  skillLevels: { [key: string]: number };
  learningGoals: string[];
  careerPath: string;
  timeAvailability: string;
  preferredLearningStyle: string;
  completedAssessments: number;
  eiqScore: number;
}

const mockSkillProfile: UserSkillProfile = {
  currentSkills: ["JavaScript", "Python", "React", "Data Analysis", "Problem Solving"],
  skillLevels: {
    "JavaScript": 85,
    "Python": 70,
    "React": 80,
    "Data Analysis": 60,
    "Problem Solving": 75
  },
  learningGoals: ["Machine Learning", "Cloud Computing", "Leadership"],
  careerPath: "Software Engineering",
  timeAvailability: "10-15 hours/week",
  preferredLearningStyle: "Interactive",
  completedAssessments: 12,
  eiqScore: 785
};

export default function SkillRecommendationEngine() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [userProfile, setUserProfile] = useState<UserSkillProfile>(mockSkillProfile);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch skill recommendations
  const { data: skillRecommendations, isLoading } = useQuery({
    queryKey: ["/api/skill-recommendations", selectedCategory],
    enabled: true
  });

  // Fetch user learning analytics
  const { data: learningAnalytics } = useQuery({
    queryKey: ["/api/learning-analytics"],
  });

  // Accept recommendation mutation
  const acceptRecommendationMutation = useMutation({
    mutationFn: async (recommendationId: string) => {
      return apiRequest(`/api/skill-recommendations/${recommendationId}/accept`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      toast({
        title: "Recommendation Accepted!",
        description: "We're creating your personalized learning path.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/skill-recommendations"] });
    },
  });

  // Generate new recommendations mutation
  const generateRecommendationsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("/api/skill-recommendations/generate", {
        method: "POST",
      });
    },
    onSuccess: () => {
      toast({
        title: "New Recommendations Generated!",
        description: "Updated recommendations based on your latest progress.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/skill-recommendations"] });
    },
  });

  const categories = [
    { id: "all", name: "All Recommendations", count: 24 },
    { id: "technical", name: "Technical Skills", count: 12 },
    { id: "soft-skills", name: "Soft Skills", count: 6 },
    { id: "leadership", name: "Leadership", count: 4 },
    { id: "emerging", name: "Emerging Tech", count: 8 }
  ];

  const priorityColors = {
    critical: "bg-red-500",
    high: "bg-orange-500", 
    medium: "bg-yellow-500",
    low: "bg-green-500"
  };

  const difficultyColors = {
    beginner: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400",
    intermediate: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400",
    advanced: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Brain className="h-8 w-8 text-purple-500" />
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Interactive Skill Recommendation Engine</h1>
              </div>
              <Badge variant="secondary" className="text-xs">AI-Powered Learning</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                onClick={() => generateRecommendationsMutation.mutate()}
                disabled={generateRecommendationsMutation.isPending}
                variant="outline"
              >
                <Zap className="h-4 w-4 mr-2" />
                Refresh Recommendations
              </Button>
              <div className="text-right">
                <p className="text-sm text-gray-600 dark:text-gray-400">EiQ Score</p>
                <p className="text-xl font-bold text-purple-500">{userProfile.eiqScore}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User Skill Profile Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-5 w-5 mr-2" />
                Your Skill Profile
              </CardTitle>
              <CardDescription>Current skills and learning progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(userProfile.skillLevels).map(([skill, level]) => (
                  <div key={skill} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{skill}</span>
                      <span className="text-gray-600">{level}%</span>
                    </div>
                    <Progress value={level} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Learning Goals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {userProfile.learningGoals.map((goal, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{goal}</span>
                  </div>
                ))}
              </div>
              <Separator className="my-4" />
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Career Path:</span>
                  <span className="font-medium">{userProfile.careerPath}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time Available:</span>
                  <span className="font-medium">{userProfile.timeAvailability}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Learning Style:</span>
                  <span className="font-medium">{userProfile.preferredLearningStyle}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recommendations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="pathways">Learning Pathways</TabsTrigger>
            <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="space-y-6">
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                >
                  {category.name}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {category.count}
                  </Badge>
                </Button>
              ))}
            </div>

            {/* Skill Recommendations */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {skillRecommendations?.slice(0, 8).map((recommendation: SkillRecommendation) => (
                <Card key={recommendation.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{recommendation.skillName}</CardTitle>
                        <CardDescription>{recommendation.category}</CardDescription>
                      </div>
                      <div className="flex flex-col items-end space-y-2">
                        <Badge className={priorityColors[recommendation.priority]}>
                          {recommendation.priority.toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className={difficultyColors[recommendation.difficulty]}>
                          {recommendation.difficulty}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* AI Reasoning */}
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Brain className="h-4 w-4 text-blue-500 mr-2" />
                          <span className="text-sm font-medium">AI Recommendation</span>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          {recommendation.reasoning}
                        </p>
                      </div>

                      {/* Metrics */}
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-lg font-bold text-purple-500">
                            {Math.round(recommendation.confidence)}%
                          </div>
                          <div className="text-xs text-gray-600">Confidence</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-green-500">
                            {Math.round(recommendation.relevanceScore)}%
                          </div>
                          <div className="text-xs text-gray-600">Relevance</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-orange-500">
                            {Math.round(recommendation.careerImpact)}%
                          </div>
                          <div className="text-xs text-gray-600">Career Impact</div>
                        </div>
                      </div>

                      {/* Time Estimate */}
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-gray-500" />
                          <span>Estimated Time: {recommendation.estimatedTimeToComplete}</span>
                        </div>
                        <div className="flex items-center">
                          <TrendingUp className="h-4 w-4 mr-2 text-gray-500" />
                          <span>Demand: {recommendation.industryDemand}%</span>
                        </div>
                      </div>

                      {/* Prerequisites */}
                      {recommendation.prerequisites.length > 0 && (
                        <div>
                          <span className="text-sm font-medium">Prerequisites:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {recommendation.prerequisites.slice(0, 3).map((prereq, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {prereq}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex space-x-2">
                        <Button 
                          className="flex-1"
                          onClick={() => acceptRecommendationMutation.mutate(recommendation.id)}
                          disabled={acceptRecommendationMutation.isPending}
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Start Learning
                        </Button>
                        <Button variant="outline" size="sm">
                          <BookOpen className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <BookOpen className="h-8 w-8 text-blue-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Skills in Progress</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">8</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <CheckCircle className="h-8 w-8 text-green-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Skills Completed</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">15</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-purple-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Learning Velocity</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">92%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Award className="h-8 w-8 text-yellow-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Skill Mastery</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">78%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Learning Patterns */}
            <Card>
              <CardHeader>
                <CardTitle>Learning Patterns & Insights</CardTitle>
                <CardDescription>AI-analyzed learning behavior and recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h4 className="font-medium mb-2">Optimal Learning Time</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      You learn 40% faster during morning sessions (9-11 AM)
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h4 className="font-medium mb-2">Preferred Learning Style</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Interactive projects show 65% higher retention rates
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <h4 className="font-medium mb-2">Skill Acquisition Rate</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      You master new concepts 25% faster than average
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pathways" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personalized Learning Pathways</CardTitle>
                <CardDescription>AI-curated skill development routes based on your goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {userProfile.learningGoals.map((goal, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">{goal} Pathway</h3>
                        <Badge variant="outline">12 weeks</Badge>
                      </div>
                      <div className="flex items-center space-x-4 overflow-x-auto pb-2">
                        {['Foundation', 'Intermediate', 'Advanced', 'Specialization'].map((phase, phaseIndex) => (
                          <div key={phaseIndex} className="flex items-center">
                            <div className="flex flex-col items-center min-w-0">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                phaseIndex === 0 ? 'bg-purple-500 text-white' : 'bg-gray-200 text-gray-600'
                              }`}>
                                {phaseIndex + 1}
                              </div>
                              <span className="text-xs mt-1 text-center">{phase}</span>
                            </div>
                            {phaseIndex < 3 && <ChevronRight className="h-4 w-4 text-gray-400 mx-2" />}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Skill Development Progress</CardTitle>
                <CardDescription>Track your learning journey and milestones</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {Object.entries(userProfile.skillLevels).map(([skill, level]) => (
                    <div key={skill} className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{skill}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-600">{level}%</span>
                          <Button size="sm" variant="outline">
                            <Play className="h-3 w-3 mr-1" />
                            Continue
                          </Button>
                        </div>
                      </div>
                      <Progress value={level} className="h-3" />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Beginner</span>
                        <span>Intermediate</span>
                        <span>Advanced</span>
                        <span>Expert</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}