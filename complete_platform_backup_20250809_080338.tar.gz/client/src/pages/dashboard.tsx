import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/Navbar";
import Sidebar from "@/components/layout/Sidebar";
import AssessmentEngine from "@/components/assessment/AssessmentEngine";
import AdvancedAssessment from "@/components/assessment/AdvancedAssessment";
import AIAssistant from "@/components/ai/AIAssistant";
import DocumentUpload from "@/components/upload/DocumentUpload";
import LearningPathways from "@/components/learning/LearningPathways";
import Analytics from "@/components/analytics/Analytics";
import StudyGroup from "@/components/collaboration/StudyGroup";
import AITutor from "@/components/ai/AITutor";
import VRCompetitions from "@/components/vr/VRCompetitions";
import UniversityPortal from "@/components/university/UniversityPortal";
import TalentPortal from "@/components/career/TalentPortal";
import DegreePlanner from "@/components/degree/DegreePlanner";
import AchievementShowcase from "@/components/achievements/AchievementShowcase";
import MLInsightsDashboard from "@/components/analytics/MLInsightsDashboard";
import AITestPanel from "@/components/ai/AITestPanel";
import OAuthWizard from "@/components/admin/OAuthWizard";
import { Card, CardContent } from "@/components/ui/card";
import { Calculator, Brain, Flame, Rocket } from "lucide-react";

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);
  const [activeSection, setActiveSection] = useState("dashboard");

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const { data: userProfile } = useQuery({
    queryKey: ["/api/user/profile"],
    enabled: !!user
  });

  const currentUser = userProfile || user;

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={currentUser} />
      
      <div className="flex">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        
        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto p-6">
            
            {activeSection === "dashboard" && (
              <>
                {/* Welcome Header */}
                <div className="mb-8">
                  <h1 className="text-3xl font-bold mb-2">
                    Welcome back, <span className="text-primary">{currentUser.firstName}</span>
                  </h1>
                  <p className="text-muted-foreground">
                    Continue your educational journey with EiQ™ powered by SikatLab™ and IDFS Pathway™ - personalized learning experiences designed for your growth.
                  </p>
                </div>

                {/* Quick Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Assessment Progress</p>
                      <p className="text-2xl font-bold text-primary">
                        {currentUser.assessmentProgress || 0}%
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                      <Calculator className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="mt-4 progress-bar">
                    <div 
                      className="progress-fill bg-primary" 
                      style={{ width: `${currentUser.assessmentProgress || 0}%` }}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Learning Streak</p>
                      <p className="text-2xl font-bold">
                        {currentUser.learningStreak || 0} days
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                      <Flame className="h-6 w-6 text-orange-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">AI Interactions</p>
                      <p className="text-2xl font-bold">
                        {currentUser.aiInteractions || 0}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <Brain className="h-6 w-6 text-blue-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">Current Level</p>
                      <p className="text-2xl font-bold text-purple-400">
                        {currentUser.currentLevel || "Foundation"}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <Rocket className="h-6 w-6 text-purple-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
                  {/* Left Column - Assessment & Learning */}
                  <div className="lg:col-span-2 space-y-8">
                <AssessmentEngine userId={currentUser.id} />
                <DocumentUpload userId={currentUser.id} />
                <LearningPathways userId={currentUser.id} />
                  </div>

                  {/* Right Column - AI Assistant & Collaboration */}
                  <div className="space-y-8">
                <AIAssistant userId={currentUser.id} />
                <StudyGroup userId={currentUser.id} />
                  </div>
                </div>

                {/* Achievement Showcase */}
                <div className="mt-8">
                  <AchievementShowcase />
                </div>

                {/* Analytics Dashboard */}
                <div className="mt-8">
                  <Analytics userId={currentUser.id} />
                </div>
              </>
            )}
            
            {activeSection === "assessment" && <AdvancedAssessment />}
            {activeSection === "ai-tutor" && <AITutor />}
            {activeSection === "navigator" && <LearningPathways userId={currentUser.id} />}
            {activeSection === "talent-match" && <TalentPortal />}
            {activeSection === "apex-prep" && <UniversityPortal />}
            {activeSection === "core-intelligence" && <AdvancedAssessment />}
            {activeSection === "lifetime-advantage" && <StudyGroup userId={currentUser.id} />}
            {activeSection === "ml-insights" && <MLInsightsDashboard />}
            {activeSection === "ai-test" && <AITestPanel />}
            {activeSection === "ai-assistant" && <AIAssistant userId={currentUser.id} />}
            {activeSection === "upload" && <DocumentUpload userId={currentUser.id} />}
            {activeSection === "oauth-admin" && <OAuthWizard />}
          </div>
        </main>
      </div>
    </div>
  );
}
