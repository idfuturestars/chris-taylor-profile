import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Login from "@/pages/login";
import NotFound from "@/pages/not-found";
import OnboardingWizard from "@/components/onboarding/OnboardingWizard";
import PersonalizedWelcome from "@/components/onboarding/PersonalizedWelcome";
import K12Dashboard from "@/pages/K12Dashboard";
import HigherEducationDashboard from "@/pages/HigherEducationDashboard";
import EducationLevelSelector from "@/components/navigation/EducationLevelSelector";
import StudyCohorts from "@/pages/StudyGroups";
import AdaptiveAssessment from "@/pages/AdaptiveAssessment";
import AITutor from "@/pages/AITutor";
import SkillRecommendations from "@/pages/SkillRecommendations";
import SkillRecommendationEngine from "@/pages/SkillRecommendationEngine";
import VoiceAssessment from "@/pages/VoiceAssessment";
import IDFSAssessment from "@/pages/IDFSAssessment";
import MLAnalytics from "@/pages/MLAnalytics";
import RealTimeCollaboration from "@/pages/RealTimeCollaboration";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";

// Add error boundary for unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  event.preventDefault();
});

function AuthenticatedApp() {
  const { data: onboarding, isLoading: onboardingLoading } = useQuery({
    queryKey: ["/api/user/onboarding"],
    retry: false,
  });

  // Handle OAuth token from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    
    if (token) {
      localStorage.setItem('token', token);
      // Remove token from URL
      window.history.replaceState({}, document.title, '/');
      // Trigger auth state update without reload
      window.dispatchEvent(new Event('authchange'));
    }
  }, []);

  if (onboardingLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  // Show onboarding wizard if no onboarding data exists or not completed
  if (!onboarding || !(onboarding as any).completed) {
    return (
      <Switch>
        <Route path="/onboarding" component={OnboardingWizard} />
        <Route path="/welcome" component={PersonalizedWelcome} />
        <Route path="/" component={OnboardingWizard} />
        <Route component={OnboardingWizard} />
      </Switch>
    );
  }

  // Show personalized welcome if onboarding is complete but user hasn't seen it
  if (onboarding && !localStorage.getItem('welcomeShown')) {
    return (
      <Switch>
        <Route path="/onboarding" component={OnboardingWizard} />
        <Route path="/welcome" component={PersonalizedWelcome} />
        <Route path="/" component={PersonalizedWelcome} />
        <Route component={Dashboard} />
      </Switch>
    );
  }

  // Normal app flow for completed onboarding
  return (
    <Switch>
      <Route path="/onboarding" component={OnboardingWizard} />
      <Route path="/welcome" component={PersonalizedWelcome} />
      <Route path="/k12-dashboard" component={K12Dashboard} />
      <Route path="/higher-education" component={HigherEducationDashboard} />
      <Route path="/assessment" component={AdaptiveAssessment} />
      <Route path="/ai-tutor" component={AITutor} />
      <Route path="/skills" component={SkillRecommendations} />
      <Route path="/skill-engine" component={SkillRecommendationEngine} />
      <Route path="/voice-assessment" component={VoiceAssessment} />
      <Route path="/idfs-assessment" component={IDFSAssessment} />
      <Route path="/ml-analytics" component={MLAnalytics} />
      <Route path="/collaboration" component={RealTimeCollaboration} />
      <Route path="/study-cohorts" component={StudyCohorts} />
      <Route path="/choose-level" component={EducationLevelSelector} />
      <Route path="/" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function Router() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    console.log('[AUTH] Token check:', token ? 'Found' : 'Not found');
    
    // Validate token if it exists
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const isExpired = payload.exp * 1000 < Date.now();
        if (isExpired) {
          localStorage.removeItem('token');
          setIsAuthenticated(false);
          return;
        }
        setIsAuthenticated(true);
      } catch (error) {
        localStorage.removeItem('token');
        setIsAuthenticated(false);
      }
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  // Listen for storage changes (login/logout from other tabs)
  useEffect(() => {
    const handleStorageChange = () => {
      const token = localStorage.getItem('token');
      console.log('[AUTH] Storage change detected, token:', token ? 'Found' : 'Not found');
      setIsAuthenticated(!!token);
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Also listen for custom auth events
    const handleAuthChange = () => {
      const token = localStorage.getItem('token');
      console.log('[AUTH] Auth change event, token:', token ? 'Found' : 'Not found');
      setIsAuthenticated(!!token);
    };
    
    window.addEventListener('authchange', handleAuthChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('authchange', handleAuthChange);
    };
  }, []);

  // Show minimal loading screen
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={isAuthenticated ? AuthenticatedApp : Login} />
      <Route component={isAuthenticated ? AuthenticatedApp : Login} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark min-h-screen bg-background text-foreground">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
